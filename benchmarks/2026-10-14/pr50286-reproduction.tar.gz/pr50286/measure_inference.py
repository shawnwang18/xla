"""Fixed-window synchronized inference measurements; no framework patches."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, '/work/skill/assets/jax-run-scripts')
from inference_aot_runner import compile_engine, require_same_formats

WARMUP = 100
MEASURE = 200


def summarize(samples):
    values = [s['milliseconds'] for s in samples if s['step'] > WARMUP]
    mean = statistics.mean(values)
    half = len(values) // 2
    drift = abs(statistics.mean(values[:half]) - statistics.mean(values[half:])) / mean * 100
    cv = statistics.pstdev(values) / mean * 100
    return dict(mean_ms=mean, median_ms=statistics.median(values),
                p95_ms=sorted(values)[int(.95 * (len(values)-1))],
                cv_percent=cv, half_mean_drift_percent=drift,
                stable=drift <= 5 and cv <= 10,
                measured_steps=[WARMUP+1, WARMUP+MEASURE])


def run(config):
    import jax
    import numpy as np
    from maxtext.inference.maxengine import maxengine
    from maxtext.input_pipeline.packing import prefill_packing
    from maxtext.utils import max_utils

    rank = jax.process_index()
    out = Path('/result')
    report_path = out / f'stable-rank{rank}.json'
    samples_path = out / f'samples-rank{rank}.jsonl'
    report = dict(mode=os.environ['RECOMPUTE_MODE'], rank=rank, warmup_steps=WARMUP,
                  measurement_steps=MEASURE, timing='perf_counter_ns; each call block_until_ready',
                  xla_flags=os.environ.get('XLA_FLAGS'), framework_source_patches=[],
                  stable_runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  stages={}, status='initializing')
    def save():
        report_path.write_text(json.dumps(report, indent=2)+'\n')
    save()

    engine = maxengine.MaxEngine(config)
    processor = prefill_packing.PrefillProcessor(engine)
    rng = jax.random.PRNGKey(1234)
    rng, rng_params = jax.random.split(rng)
    params = engine.load_params(rng_params)
    tokenizer = engine.build_tokenizer(engine.get_tokenizer())
    rng, rng_init = jax.random.split(rng)
    rng_shape = jax.ShapeDtypeStruct([4], jax.numpy.dtype('uint32'))
    generate, params, initialize = compile_engine(engine, params, rng_shape)
    state = initialize(rng_init)
    jax.block_until_ready(state)
    num_params, model_size, _ = max_utils.summarize_pytree_data(params, name='Model')
    _, cache_size, _ = max_utils.summarize_pytree_data(state['cache'], name='Cache')
    report.update(model_params=num_params, model_bytes=model_size, cache_bytes=cache_size,
                  global_batch=engine.max_concurrent_decodes,
                  model_name=config.model_name, decoder_layers=config.num_decoder_layers, experts=config.num_experts,
                  dtype=str(config.dtype), weight_dtype=str(config.weight_dtype),
                  embedding_dim=config.emb_dim, query_heads=config.num_query_heads,
                  kv_heads=config.num_kv_heads, max_target_length=config.max_target_length,
                  status='compiling_prefill')
    assert config.model_name == os.environ['EXPECTED_MODEL']
    save()
    lengths = [int(v) for v in config.inference_microbenchmark_prefill_lengths.split(',')]
    assert len(lengths) == 1 and lengths[0] == int(config.max_prefill_predict_length), lengths
    length = lengths[0]
    tokens, true_length = tokenizer.encode(config.prompt, is_bos=tokenizer.bos_id is not None,
                                          prefill_lengths=[length])
    prefill = jax.jit(engine.prefill_aot,
                     in_shardings=(engine.param_layouts, None, None, None)).lower(
                         params, jax.ShapeDtypeStruct([length], jax.numpy.int32),
                         jax.ShapeDtypeStruct((), int), rng_shape).compile()
    insert = processor.aot_compile(params, length)
    require_same_formats(insert.output_formats[1], engine.decode_state_layouts, 'insert output')
    require_same_formats(insert.input_formats[0][4], engine.decode_state_layouts, 'insert input')
    report['compiled_memory'] = {}
    for name, executable in [('prefill', prefill), ('decode', generate), ('initialize', initialize), ('insert', insert)]:
        stats = executable.memory_analysis()
        report['compiled_memory'][name] = {key:getattr(stats,key) for key in ['argument_size_in_bytes','output_size_in_bytes','temp_size_in_bytes','alias_size_in_bytes','generated_code_size_in_bytes']}
    report.update(padded_prefill_tokens=length, true_prompt_tokens=int(true_length),
                  decode_input_output_formats_equal=True, status='measuring')
    save()

    def next_rng():
        nonlocal rng
        rng, key = jax.random.split(rng)
        # RNG dispatch/compilation are outside the timed model call.
        jax.block_until_ready((rng, key))
        return key

    def measure(stage, invoke):
        samples = []
        with samples_path.open('a', buffering=1) as log:
            for step in range(1, WARMUP + MEASURE + 1):
                key = next_rng()
                start = time.perf_counter_ns()
                output = invoke(key)
                jax.block_until_ready(output)
                elapsed = (time.perf_counter_ns() - start) / 1e6
                record = dict(stage=stage, step=step, milliseconds=elapsed,
                              warmup=step <= WARMUP)
                samples.append(record)
                # Retain normal overlapping output lifetime until the next call.
                log.write(json.dumps(record)+'\n')
                if rank == 0 and step in (1, WARMUP, WARMUP+MEASURE):
                    print('STABLE_STEP '+json.dumps(record), flush=True)
        report['stages'][stage] = summarize(samples)
        save()
        return output

    last = measure('prefill', lambda key: prefill(params, tokens, true_length, key))
    del last
    # Populate every slot identically across modes; insertion is outside timing.
    for slot in range(engine.max_concurrent_decodes):
        _, state = insert(params, tokens, slot, true_length, state, next_rng())
        jax.block_until_ready(state)
    require_same_formats(jax.tree.map(lambda x: x.format, state),
                         engine.decode_state_layouts, 'runtime decode input')
    def decode(key):
        nonlocal state
        state, result = generate(params, state, key)
        return state, result
    last = measure('decode', decode)
    finite = all(bool(np.isfinite(np.asarray(jax.device_get(shard.data))).all())
                 for shard in state['logits'].addressable_shards)
    report['memory_after_stages'] = [dict(device=str(d),stats=d.memory_stats()) for d in jax.local_devices()]
    # A directly measured model request: prefill/insert one active request into
    # slot zero, then 64 sequential decode calls on the configured batch shape.
    # Initialization and random-key preparation are outside timing; there is no
    # tokenization, checkpoint loading, or output detokenization in this metric.
    request_samples = []
    for request_index in range(25):
        del last
        del state
        state = initialize(next_rng())
        keys = [next_rng() for _ in range(65)]
        jax.block_until_ready((state,keys))
        start = time.perf_counter_ns()
        _, state = insert(params,tokens,0,true_length,state,keys[0])
        for key in keys[1:]:
            state, result = generate(params,state,key)
        jax.block_until_ready((state,result))
        elapsed = (time.perf_counter_ns()-start)/1e6
        last = (state,result)
        if request_index >= 5:
            request_samples.append(elapsed)
    report['model_request_e2e'] = dict(
        mean_ms=statistics.mean(request_samples),median_ms=statistics.median(request_samples),
        samples_ms=request_samples,output_tokens=64,padded_prefill_tokens=length,
        active_requests=1,compiled_batch=engine.max_concurrent_decodes,
        scope='prefill/insert plus 64 decode calls, host dispatch and final synchronization; excludes initialization, loading, tokenization and detokenization')
    report['memory_after_requests'] = [dict(device=str(d),stats=d.memory_stats()) for d in jax.local_devices()]
    finite = finite and all(bool(np.isfinite(np.asarray(jax.device_get(shard.data))).all())
                            for shard in state['logits'].addressable_shards)

    report['finite_final_local_logits'] = finite
    report['status'] = 'completed' if finite else 'failed_nonfinite_logits'
    report['stages']['decode']['tokens_per_second'] = engine.max_concurrent_decodes * 1000 / report['stages']['decode']['mean_ms']
    save()
    assert finite, 'Non-finite final logits'
    print('STABLE_RESULTS '+json.dumps(report), flush=True)


def main(argv):
    import jax
    from maxtext.configs import pyconfig
    jax.config.update('jax_default_prng_impl', 'unsafe_rbg')
    config = pyconfig.initialize(argv)
    run(config)


if __name__ == '__main__':
    from absl import app
    app.run(main)
