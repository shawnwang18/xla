"""Serialize all trials in a reserved allocation, preserving the holder job."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time
import threading
import sys
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path,data):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,indent=2)+'\n')
    tmp.replace(path)

def steps(allocation):
    raw=subprocess.check_output(['squeue','--steps','-j',allocation,'-h','-o','%i|%j'],text=True,timeout=30)
    return [l.split('|')[0] for l in raw.splitlines()
            if l.split('|')[0].split('.')[-1] not in {'batch','extern'}]

def require_idle(allocation):
    active=steps(allocation)
    if not active:return
    completed=set()
    for path in (ROOT/'results').rglob('run-status.json'):
        record=json.loads(path.read_text())
        if record.get('allocation_id')==allocation and record['state']=='COMPLETED':
            completed.add(record.get('step_id'))
    # A reaped successful srun can remain in Slurm briefly during step cleanup.
    # Wait only for this task's recorded successful steps, never another owner.
    for _ in range(12):
        if not active:return
        if any(step not in completed for step in active):
            raise RuntimeError('Unrecognized active workload steps: '+repr(active))
        time.sleep(10)
        active=steps(allocation)
    if active:raise RuntimeError('Completed steps still visible after120s: '+repr(active))

def one(case,trial,worker):
    allocation=worker['allocation_id']
    out=Path(trial['directory'])
    status=out/'run-status.json'
    if status.exists():
        record=json.loads(status.read_text())
        if record['state']=='COMPLETED':
            return record
        raise RuntimeError('Prior failed/unknown trial must be reconciled: '+str(status))
    if (out/'launch.json').exists():
        raise RuntimeError('Existing trial launch is unresolved: '+str(out))
    if (ROOT/'control.json').exists() and not json.loads((ROOT/'control.json').read_text()).get('enabled',True):
        raise RuntimeError('Suite disabled by control file')
    state=subprocess.check_output(['squeue','-h','-j',allocation,'-o','%T|%N|%u|%L'],text=True,timeout=30).strip()
    if not state.startswith('RUNNING|'+worker['node']+'|shawnw|'):
        raise RuntimeError('Unexpected allocation state: '+state)
    require_idle(allocation)
    env=os.environ.copy()
    env.update(json.loads((out/'env.json').read_text()))
    env.update(WORKLOAD=case['workload'],EXPECTED_MODEL=case['model'],RECOMPUTE_MODE=str(trial['mode']),EXPECTED_GPU_TYPE=worker['gpu_type'],
               ENROOT_CONFIG_PATH='/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/.enroot')
    mounts=[f'{ROOT}:/work',f'{out}:/result',f'{ROOT}/jaxlibs:/opt/pr-jaxlibs:ro']
    if env.get('CUSTOM_MOUNTS'):
        mounts.append(env['CUSTOM_MOUNTS'])
    image='oauth2@'+env['CONTAINER'].replace('gitlab-master.nvidia.com:5005/','gitlab-master.nvidia.com:5005#')
    cmd=['srun','--jobid='+allocation,'--nodelist='+worker['node'],'--nodes=1','--ntasks=4','--ntasks-per-node=4',
         '--cpus-per-task=16','--cpu-bind=none','--gres=gpu:'+worker['gpu_type']+':4','--time=01:00:00',
         '--kill-on-bad-exit=1','--job-name=pr50286-'+case['model']+'-'+str(trial['index']),
         '--container-image='+image,'--container-mounts='+','.join(mounts),
         '--container-name=pr50286-ten-workloads',
         '--container-remap-root','--container-writable','--container-workdir=/opt/maxtext',
         '--output='+str(out/'rank-%t.log'),'--error='+str(out/'rank-%t.log'),
         'bash','/work/rank-preallocated.sh' if json.loads((ROOT/'protocol.json').read_text())['memory'].get('per_workload_overrides',{}).get(case['workload'],{}).get('preallocate',False) else '/work/rank.sh']
    record=dict(trial=trial,command=cmd,state='RUNNING',started_at=now(),allocation_id=allocation,node=worker['node'],gpu_type=worker['gpu_type'])
    save(out/'launch.json',record)
    with (out/'launcher.log').open('w') as log:
        process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        while process.poll() is None:
            time.sleep(30)
            ranks=list(out.glob('step-rank*.json'))
            if ranks:
                record['step_id']=json.loads(ranks[0].read_text())['step_id']
                save(out/'launch.json',record)
        rc=process.returncode
    records=[json.loads(f.read_text()) for f in sorted(out.glob('runtime-rank*.json'))]
    valid=rc==0 and len(records)==4 and all(r['state']=='COMPLETED' for r in records)
    if case['type']=='inference':
        reports=[json.loads(f.read_text()) for f in out.glob('stable-rank*.json')]
        valid=valid and len(reports)==4 and all(r['status']=='completed' and r.get('model_request_e2e') for r in reports)
    else:
        reports=[json.loads(f.read_text()) for f in out.glob('training-summary-rank*.json')]
        metrics=list(out.glob('training-metrics-rank*.jsonl'))
        valid=valid and len(reports)==4 and (len(metrics)==4 or
            (trial['pilot'] and (out/'training-metrics.jsonl').is_file()))
    record.update(returncode=rc,state='COMPLETED' if valid else 'FAILED',finished_at=now())
    save(status,record)
    if not valid:
        raise RuntimeError('Trial failed or required output missing: '+str(out))
    return record

def main():
    job=sys.argv[1]
    primary=json.loads((ROOT/'suite-status.json').read_text())
    assert primary['workers'][job]['state']=='FAILED', 'Only a terminated failed worker can be recovered separately'
    plan=json.loads((ROOT/'parallel-plan.json').read_text())
    worker=next(w for w in plan['workers'] if w['allocation_id']==job)
    claim=json.loads((Path(worker['reuse_lock']).parent/'active-reuse.json').read_text())
    assert claim['active_task']==plan['thread_id'] and claim['active_root']==str(ROOT)
    lock=(ROOT/('worker-recovery-'+job+'.lock')).open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    shared_lock=Path(worker['reuse_lock']).open('a')
    acquired=False
    def verify_lease():
        nonlocal acquired
        if not acquired:
            try:
                fcntl.flock(shared_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
                acquired=True
            except BlockingIOError:
                # The original controller retains this allocation's lease, but
                # its failed worker has terminated and will not launch again.
                live=json.loads((ROOT/'suite-status.json').read_text())
                assert live['pid']==primary['pid'] and live['started_at']==primary['started_at']
                assert live['workers'][job]['state']=='FAILED'
                os.kill(primary['pid'],0)
        require_idle(job)
    verify_lease()
    status_path=ROOT/('worker-recovery-'+job+'.json')
    status=dict(state='RUNNING',pid=os.getpid(),host=os.uname().nodename,started_at=now(),
                primary_started_at=primary['started_at'],allocation_id=job,worker=worker,completed=[],current=None,
                instrumentation='Gemma training uses preallocated BFC pool in both modes to avoid fragmentation; other cases unchanged')
    save(status_path,status)
    try:
        cases={c['workload']:c for c in json.loads((ROOT/'cases.json').read_text())}
        for workload in worker['workloads']:
            case=cases[workload]
            for trial in case['trials']:
                p=Path(trial['directory'])/'run-status.json'
                if not p.exists() or json.loads(p.read_text())['state']!='COMPLETED':verify_lease()
                status.update(current=trial,checked_at=now())
                save(status_path,status)
                record=one(case,trial,worker)
                status['completed'].append(record)
                save(status_path,status)
        status.update(state='COMPLETED',current=None,finished_at=now())
    except BaseException as exc:
        status.update(state='FAILED',error=repr(exc),finished_at=now())
        raise
    finally:
        save(status_path,status)

if __name__=='__main__':main()
