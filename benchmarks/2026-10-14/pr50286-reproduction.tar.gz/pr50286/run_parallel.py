"""Serialize all trials in a reserved allocation, preserving the holder job."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time
import threading
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path,data):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,indent=2)+'\n')
    tmp.replace(path)

def steps(allocation):
    raw=subprocess.check_output(['squeue','--steps','-j',allocation,'-h','-o','%i|%j'],text=True,timeout=30)
    return [l.split('|')[0] for l in raw.splitlines()
            if l.split('|')[0].split('.')[-1] not in {'batch','extern'}]

def one(case,trial,worker):
    allocation=worker['allocation_id']
    out=Path(trial['directory'])
    status=out/'run-status.json'
    if status.exists():
        record=json.loads(status.read_text())
        if record['state']=='COMPLETED':
            return record
        raise RuntimeError('Prior failed/unknown trial must be reconciled: '+str(status))
    if (out/'launch.json').exists():
        raise RuntimeError('Existing trial launch is unresolved: '+str(out))
    if (ROOT/'control.json').exists() and not json.loads((ROOT/'control.json').read_text()).get('enabled',True):
        raise RuntimeError('Suite disabled by control file')
    state=subprocess.check_output(['squeue','-h','-j',allocation,'-o','%T|%N|%u|%L'],text=True,timeout=30).strip()
    if not state.startswith('RUNNING|'+worker['node']+'|shawnw|'):
        raise RuntimeError('Unexpected allocation state: '+state)
    if steps(allocation):
        raise RuntimeError('Allocation has another active workload step')
    env=os.environ.copy()
    env.update(json.loads((out/'env.json').read_text()))
    env.update(WORKLOAD=case['workload'],EXPECTED_MODEL=case['model'],RECOMPUTE_MODE=str(trial['mode']),EXPECTED_GPU_TYPE=worker['gpu_type'],
               ENROOT_CONFIG_PATH='/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/.enroot')
    mounts=[f'{ROOT}:/work',f'{out}:/result',f'{ROOT}/jaxlibs:/opt/pr-jaxlibs:ro']
    if env.get('CUSTOM_MOUNTS'):
        mounts.append(env['CUSTOM_MOUNTS'])
    image='oauth2@'+env['CONTAINER'].replace('gitlab-master.nvidia.com:5005/','gitlab-master.nvidia.com:5005#')
    cmd=['srun','--jobid='+allocation,'--nodelist='+worker['node'],'--nodes=1','--ntasks=4','--ntasks-per-node=4',
         '--cpus-per-task=16','--cpu-bind=none','--gres=gpu:'+worker['gpu_type']+':4','--time=01:00:00',
         '--kill-on-bad-exit=1','--job-name=pr50286-'+case['model']+'-'+str(trial['index']),
         '--container-image='+image,'--container-mounts='+','.join(mounts),
         '--container-name=pr50286-ten-workloads',
         '--container-remap-root','--container-writable','--container-workdir=/opt/maxtext',
         '--output='+str(out/'rank-%t.log'),'--error='+str(out/'rank-%t.log'),
         'bash','/work/rank.sh']
    record=dict(trial=trial,command=cmd,state='RUNNING',started_at=now(),allocation_id=allocation,node=worker['node'],gpu_type=worker['gpu_type'])
    save(out/'launch.json',record)
    with (out/'launcher.log').open('w') as log:
        process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        while process.poll() is None:
            time.sleep(30)
            ranks=list(out.glob('step-rank*.json'))
            if ranks:
                record['step_id']=json.loads(ranks[0].read_text())['step_id']
                save(out/'launch.json',record)
        rc=process.returncode
    records=[json.loads(f.read_text()) for f in sorted(out.glob('runtime-rank*.json'))]
    valid=rc==0 and len(records)==4 and all(r['state']=='COMPLETED' for r in records)
    if case['type']=='inference':
        reports=[json.loads(f.read_text()) for f in out.glob('stable-rank*.json')]
        valid=valid and len(reports)==4 and all(r['status']=='completed' and r.get('model_request_e2e') for r in reports)
    else:
        reports=[json.loads(f.read_text()) for f in out.glob('training-summary-rank*.json')]
        metrics=list(out.glob('training-metrics-rank*.jsonl'))
        valid=valid and len(reports)==4 and (len(metrics)==4 or
            (trial['pilot'] and (out/'training-metrics.jsonl').is_file()))
    record.update(returncode=rc,state='COMPLETED' if valid else 'FAILED',finished_at=now())
    save(status,record)
    if not valid:
        raise RuntimeError('Trial failed or required output missing: '+str(out))
    return record

def main():
    plan=json.loads((ROOT/'parallel-plan.json').read_text())
    cases=json.loads((ROOT/'cases.json').read_text())
    by_name={c['workload']:c for c in cases}
    assigned=[w for a in plan['workers'] for w in a['workloads']]
    assert len(assigned)==len(set(assigned))==len(cases) and set(assigned)==set(by_name)
    # Hold every existing allocation's shared reuse lock for the controller life.
    # If any reservation is busy, fail before launching any worker.
    locks=[]
    for worker in sorted(plan['workers'],key=lambda w:w['allocation_id']):
        handle=Path(worker['reuse_lock']).open('a')
        fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        locks.append(handle)
        if steps(worker['allocation_id']):
            raise RuntimeError('Active workload on reserved allocation '+worker['allocation_id'])
    with (ROOT/'control.json').open('w') as f:
        json.dump(dict(enabled=True),f)
    status=dict(state='RUNNING',pid=os.getpid(),host=os.uname().nodename,started_at=now(),
                execution='parallel_cases_serial_trials',current=None,completed=[],workers={})
    completed={}
    for case in cases:
        for trial in case['trials']:
            p=Path(trial['directory'])/'run-status.json'
            if p.exists():
                d=json.loads(p.read_text())
                if d['state']=='COMPLETED':completed[trial['directory']]=d
    mutex=threading.Lock()
    def persist():
        status['completed']=[completed[t['directory']] for c in cases for t in c['trials'] if t['directory'] in completed]
        status['checked_at']=now()
        save(ROOT/'suite-status.json',status)
    for worker in plan['workers']:
        status['workers'][worker['allocation_id']]=dict(**worker,state='STARTING',current=None)
        claim=dict(allocation_id=worker['allocation_id'],node=worker['node'],gpu_type=worker['gpu_type'],
                   active_task=plan['thread_id'],active_root=str(ROOT),reuse_state='BUSY_PR50286_TEN_WORKLOADS',
                   controller_pid=os.getpid(),controller_host=os.uname().nodename,updated_at=now(),
                   reuse_lock=worker['reuse_lock'],keep_allocation_open=True)
        save(Path(worker['reuse_lock']).parent/'active-reuse.json',claim)
    persist()
    def run_worker(worker):
        ws=status['workers'][worker['allocation_id']]
        try:
            for workload in worker['workloads']:
                case=by_name[workload]
                for trial in case['trials']:
                    if trial['directory'] in completed:continue
                    with mutex:
                        ws.update(state='RUNNING',current=trial)
                        persist()
                    record=one(case,trial,worker)
                    with mutex:
                        completed[trial['directory']]=record
                        persist()
            with mutex:
                ws.update(state='COMPLETED',current=None,finished_at=now())
                persist()
        except BaseException as exc:
            with mutex:
                ws.update(state='FAILED',error=repr(exc),finished_at=now())
                persist()
    with ThreadPoolExecutor(max_workers=len(plan['workers'])) as executor:
        futures=[executor.submit(run_worker,w) for w in plan['workers']]
        while not all(f.done() for f in futures):
            time.sleep(30)
            with mutex:persist()
        for f in futures:f.result()
    with mutex:
        status['state']='COMPLETED' if len(completed)==sum(len(c['trials']) for c in cases) else 'FAILED'
        if status['state']=='FAILED':status['error']='One or more workers failed; completed trials preserved'
        status['finished_at']=now()
        persist()
    for worker in plan['workers']:
        path=Path(worker['reuse_lock']).parent/'active-reuse.json'
        claim=json.loads(path.read_text())
        claim.update(reuse_state='IDLE_RETAINED',updated_at=now(),suite_state=status['state'])
        save(path,claim)

if __name__=='__main__':
    main()
