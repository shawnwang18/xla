"""Collect strict completed trials, retaining timings and memory as separate metrics."""
import csv
import json
import math
from pathlib import Path
import re
import statistics
import sys

ROOT=Path(__file__).resolve().parent

def summarize(out,kind):
    result=dict(directory=str(out))
    status=json.loads((out/'run-status.json').read_text())
    result.update(state=status['state'],step_id=status.get('step_id'),allocation_id=status.get('allocation_id'),node=status.get('node'),gpu_type=status.get('gpu_type'))
    if (out/'hardware.json').exists():result['hardware']=json.loads((out/'hardware.json').read_text())
    if result['state']!='COMPLETED':
        return result
    ranks=[json.loads(p.read_text()) for p in sorted(out.glob('runtime-rank*.json'))]
    assert len(ranks)==4 and all(r['returncode']==0 for r in ranks)
    result['process_wall_s']=max(r['process_wall_s'] for r in ranks)
    result['host_peak_rss_gib_max_rank']=max(r['host_peak_rss_kib'] for r in ranks)/1024**2
    device_stats=[d['stats'] for r in ranks for d in r.get('devices',[]) if d.get('stats')]
    for key in ('peak_bytes_in_use','peak_pool_bytes','bytes_in_use','pool_bytes'):
        values=[s[key]/2**30 for s in device_stats if key in s]
        result[key+'_gib_max_gpu']=max(values) if values else None
    if kind=='training':
        times=[json.loads(p.read_text()) for p in sorted(out.glob('training-summary-rank*.json'))]
        assert len(times)==4 and all(len(t['samples_ms'])==60 for t in times)
        # The slowest rank defines completion of each distributed iteration.
        values=[max(t['samples_ms'][i] for t in times) for i in range(60)]
        result['e2e_ms']=statistics.mean(values)
        result['e2e_median_ms']=statistics.median(values)
        result['e2e_p95_ms']=sorted(values)[int(.95*(len(values)-1))]
        result['e2e_cv_percent']=statistics.pstdev(values)/result['e2e_ms']*100
        for rank in range(4):
            samples=[json.loads(line) for line in (out/f'training-samples-rank{rank}.jsonl').read_text().splitlines()]
            assert [s['step'] for s in samples]==list(range(101)),(out,rank,'incomplete training iterations')
        metrics_path=out/'training-metrics-rank0.jsonl'
        if not metrics_path.exists():metrics_path=out/'training-metrics.jsonl'
        metrics=[json.loads(l) for l in metrics_path.read_text().splitlines() if l.strip()]
        losses=[]
        def find_losses(obj):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    if k.endswith('/loss') and isinstance(v,(int,float)):
                        losses.append(v)
                    elif isinstance(v,dict):find_losses(v)
        for row in metrics:find_losses(row)
        assert losses and all(math.isfinite(x) for x in losses),'Missing/nonfinite loss'
        result['losses']=losses
        result['loss_by_step']={str(int(row['step'])):row['learning/loss'] for row in metrics if 'step' in row and 'learning/loss' in row}
    else:
        times=[json.loads(p.read_text()) for p in sorted(out.glob('stable-rank*.json'))]
        assert len(times)==4 and all(t['status']=='completed' for t in times)
        for phase in ('prefill','decode'):
            result[phase+'_ms']=max(t['stages'][phase]['mean_ms'] for t in times)
        n=len(times[0]['model_request_e2e']['samples_ms'])
        assert n==20
        samples=[max(t['model_request_e2e']['samples_ms'][i] for t in times) for i in range(n)]
        result['e2e_ms']=statistics.mean(samples)
        result['e2e_cv_percent']=statistics.pstdev(samples)/result['e2e_ms']*100
        half=len(samples)//2
        result['e2e_half_mean_drift_percent']=abs(statistics.mean(samples[:half])-statistics.mean(samples[half:]))/result['e2e_ms']*100
        result['compiled_memory']=times[0]['compiled_memory']
        result['phase_stable']=all(t['stages'][p]['stable'] for t in times for p in ('prefill','decode'))
    physical=[]
    with (out/'gpu-memory.csv').open() as f:
        for row in csv.reader(f):
            try:physical.append((int(row[1]),float(row[2])/1024))
            except (ValueError,IndexError):pass
    result['sampled_physical_peak_gib_max_gpu']=max((v for _,v in physical),default=None)
    result['sampled_physical_peak_gib_by_gpu']={str(i):max(v for j,v in physical if i==j) for i in sorted({i for i,_ in physical})}
    compiled=[]
    for p in sorted((out/'hlo').glob('*memory-usage-report.txt')):
        m=re.search(r'Total bytes(?: used)?:\s*(\d+)',p.read_text())
        if m:compiled.append(dict(file=p.name,bytes=int(m[1]),gib=int(m[1])/2**30))
    result['hlo_memory_reports']=compiled
    result['max_compiled_module_gib']=max((r['gib'] for r in compiled),default=None)
    pairs=[]
    for before in sorted((out/'hlo').glob('*before_recompute-fusion-side-outputs.txt')):
        prefix=re.split(r'\.\d+\.fusion-recomputation\.',before.name)[0]
        candidates=list((out/'hlo').glob(prefix+'*after_recompute-fusion-side-outputs*'))
        if len(candidates)==1:
            pairs.append(dict(before=before.name,after=candidates[0].name,changed=before.read_bytes()!=candidates[0].read_bytes()))
    result['pass_hlo_pairs']=pairs
    log_text=(out/'rank-0.log').read_text(errors='replace')
    result['fusion_measurements']=[dict(eliminated_bytes=int(b),measured_before_ns=int(x),measured_after_ns=int(y),gain_ns=int(g)) for b,x,y,g in re.findall(r'Fusion recomputation: eliminated_bytes=(\d+)\nmeasured_before_ns=(\d+)\nmeasured_after_ns=(\d+)\ngain_ns=(-?\d+)',log_text)]
    result['pass_log_decisions']=[l for l in (out/'rank-0.log').read_text(errors='replace').splitlines()
                                  if ('recomputation' in l.lower() or 'recompute-fusion-side' in l.lower()) and not l.startswith('PERF_RUNTIME')][-100:]
    return result

def main():
    cases=[]
    protocol=json.loads((ROOT/'protocol.json').read_text())
    hardware_by_workload=protocol.get('hardware_by_workload',{})
    for case in json.loads((ROOT/'cases.json').read_text()):
        item=dict(workload=case['workload'],type=case['type'],hardware=hardware_by_workload.get(case['workload'],{}),trials=[])
        for trial in case['trials']:
            out=Path(trial['directory'])
            if not (out/'run-status.json').exists():continue
            try:
                data=summarize(out,case['type'])
                data.update(mode=trial['mode'],pilot=trial['pilot'],index=trial['index'])
                (out/'collected.json').write_text(json.dumps(data,indent=2)+'\n')
                item['trials'].append(data)
            except Exception as exc:
                item['trials'].append(dict(index=trial['index'],mode=trial['mode'],pilot=trial['pilot'],state='INVALID',error=repr(exc)))
        item['memory_policy']=protocol['memory'].get('per_workload_overrides',{}).get(case['workload'],dict(preallocate=False))
        item['inference_configuration_override']=protocol['inference'].get('per_workload_overrides',{}).get(case['workload'])
        if case['workload']=='gemma2-9b-fp8' and (ROOT/'gemma2-growing-pool-oom.json').exists():
            item['initial_policy_finding']=json.loads((ROOT/'gemma2-growing-pool-oom.json').read_text())
            original=json.loads((ROOT/'gemma2-original-policy-case.json').read_text())
            item['initial_policy_trials']=[]
            for trial in original['trials']:
                out=Path(trial['directory'])
                if not (out/'run-status.json').exists():continue
                data=summarize(out,case['type'])
                data.update(mode=trial['mode'],pilot=trial['pilot'],index=trial['index'])
                item['initial_policy_trials'].append(data)
        if case['workload']=='infer-gemma2-2b-bf16-1n4g' and (ROOT/'gemma2-2b-original-placement-case.json').exists():
            original=json.loads((ROOT/'gemma2-2b-original-placement-case.json').read_text())
            item['original_placement_trials']=[]
            for trial in original['trials']:
                out=Path(trial['directory'])
                if not (out/'run-status.json').exists():continue
                data=summarize(out,case['type'])
                data.update(mode=trial['mode'],pilot=trial['pilot'],index=trial['index'])
                item['original_placement_trials'].append(data)
            item['placement_note']='Original node2521172 completed pilot/OFF/ON/ON; final OFF launcher failed before model execution and left an orphan Slurm step. Full paired series repeated on idle reserved2521171; original outputs preserved.'
        modes={}
        for mode in (0,2):
            rows=[t for t in item['trials'] if t['mode']==mode and not t['pilot'] and t['state']=='COMPLETED']
            if len(rows)==2:
                modes[str(mode)]={k:statistics.mean(t[k] for t in rows)
                                 for k in ('e2e_ms','process_wall_s','peak_bytes_in_use_gib_max_gpu',
                                           'sampled_physical_peak_gib_max_gpu','max_compiled_module_gib',
                                           'prefill_ms','decode_ms') if all(isinstance(t.get(k),(int,float)) for t in rows)}
        item['modes']=modes
        item['repeat_e2e_ms']={str(mode):[t['e2e_ms'] for t in item['trials'] if t['mode']==mode and not t['pilot'] and t['state']=='COMPLETED'] for mode in (0,2)}
        if case['type']=='training' and len(modes)==2:
            measured=[t for t in item['trials'] if not t['pilot'] and t['state']=='COMPLETED']
            ref=measured[0]['loss_by_step']
            assert all(t['loss_by_step'].keys()==ref.keys() for t in measured)
            item['max_abs_loss_difference_across_measured_trials']=max(abs(v-t['loss_by_step'][step]) for t in measured for step,v in ref.items())
        if len(modes)==2:
            item['percent_change_on_vs_off']={k:(modes['2'][k]/v-1)*100 for k,v in modes['0'].items() if v and k in modes['2']}
        if case['workload']=='infer-qwen3-8b-bf16-1n4g' and (ROOT/'qwen3-diagnostic-case.json').exists():
            diagnostic=json.loads((ROOT/'qwen3-diagnostic-case.json').read_text())
            item['diagnostic_trials']=[]
            for trial in diagnostic['trials']:
                out=Path(trial['directory'])
                if not (out/'run-status.json').exists():continue
                try:
                    data=summarize(out,case['type'])
                    data.update(mode=trial['mode'],pilot=False,index=trial['index'],diagnostic=True)
                    item['diagnostic_trials'].append(data)
                except Exception as exc:
                    item['diagnostic_trials'].append(dict(index=trial['index'],mode=trial['mode'],state='INVALID',error=repr(exc)))
            item['diagnostic_reason']='Original repeats showed substantial variability; all15 optimized HLO modules were byte-identical across four original measured trials. One bounded ON/OFF/OFF/ON set with unchanged settings.'
            rows=[t for t in item['trials']+item['diagnostic_trials'] if not t.get('pilot') and t['state']=='COMPLETED']
            item['all_measured_repeat_e2e_ms']={str(mode):[t['e2e_ms'] for t in rows if t['mode']==mode] for mode in (0,2)}
            if len(item['diagnostic_trials'])==4 and all(t['state']=='COMPLETED' for t in item['diagnostic_trials']):
                keys=['e2e_ms','peak_bytes_in_use_gib_max_gpu','sampled_physical_peak_gib_max_gpu','max_compiled_module_gib','prefill_ms','decode_ms']
                item['all_measured_modes']={str(mode):{k:statistics.mean(t[k] for t in rows if t['mode']==mode) for k in keys} for mode in (0,2)}
                item['all_measured_percent_change_on_vs_off']={k:(item['all_measured_modes']['2'][k]/v-1)*100 for k,v in item['all_measured_modes']['0'].items() if v}
        cases.append(item)
    (ROOT/'summary.json').write_text(json.dumps(cases,indent=2)+'\n')
    print(json.dumps([dict(workload=c['workload'],modes=c['modes'],trials=len(c['trials'])) for c in cases],indent=2))

if __name__=='__main__':
    main()
