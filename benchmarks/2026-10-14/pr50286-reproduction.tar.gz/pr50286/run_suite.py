"""Serialize all trials in a reserved allocation, preserving the holder job."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time

ROOT=Path(__file__).resolve().parent
ALLOCATION='2521486'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path,data):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,indent=2)+'\n')
    tmp.replace(path)

def steps():
    raw=subprocess.check_output(['squeue','--steps','-j',ALLOCATION,'-h','-o','%i|%j'],text=True,timeout=30)
    return [l.split('|')[0] for l in raw.splitlines()
            if l.split('|')[0].split('.')[-1] not in {'batch','extern'}]

def one(case,trial):
    out=Path(trial['directory'])
    status=out/'run-status.json'
    if status.exists():
        record=json.loads(status.read_text())
        if record['state']=='COMPLETED':
            return record
        raise RuntimeError('Prior failed/unknown trial must be reconciled: '+str(status))
    if (out/'launch.json').exists():
        raise RuntimeError('Existing trial launch is unresolved: '+str(out))
    if (ROOT/'control.json').exists() and not json.loads((ROOT/'control.json').read_text()).get('enabled',True):
        raise RuntimeError('Suite disabled by control file')
    state=subprocess.check_output(['squeue','-h','-j',ALLOCATION,'-o','%T|%N|%u|%L'],text=True,timeout=30).strip()
    if not state.startswith('RUNNING|gb300-nvl-012-compute15|shawnw|'):
        raise RuntimeError('Unexpected allocation state: '+state)
    if steps():
        raise RuntimeError('Allocation has another active workload step')
    env=os.environ.copy()
    env.update(json.loads((out/'env.json').read_text()))
    env.update(WORKLOAD=case['workload'],EXPECTED_MODEL=case['model'],RECOMPUTE_MODE=str(trial['mode']),
               ENROOT_CONFIG_PATH='/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/.enroot')
    mounts=[f'{ROOT}:/work',f'{out}:/result',f'{ROOT}/jaxlibs:/opt/pr-jaxlibs:ro']
    if env.get('CUSTOM_MOUNTS'):
        mounts.append(env['CUSTOM_MOUNTS'])
    image='oauth2@'+env['CONTAINER'].replace('gitlab-master.nvidia.com:5005/','gitlab-master.nvidia.com:5005#')
    cmd=['srun','--jobid='+ALLOCATION,'--nodes=1','--ntasks=4','--ntasks-per-node=4',
         '--cpus-per-task=16','--cpu-bind=none','--gres=gpu:GB300:4','--time=01:00:00',
         '--kill-on-bad-exit=1','--job-name=pr50286-'+case['model']+'-'+str(trial['index']),
         '--container-image='+image,'--container-mounts='+','.join(mounts),
         '--container-name=pr50286-ten-workloads',
         '--container-remap-root','--container-writable','--container-workdir=/opt/maxtext',
         '--output='+str(out/'rank-%t.log'),'--error='+str(out/'rank-%t.log'),
         'bash','/work/rank.sh']
    record=dict(trial=trial,command=cmd,state='RUNNING',started_at=now(),allocation_id=ALLOCATION)
    save(out/'launch.json',record)
    with (out/'launcher.log').open('w') as log:
        process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        while process.poll() is None:
            time.sleep(30)
            ranks=list(out.glob('step-rank*.json'))
            if ranks:
                record['step_id']=json.loads(ranks[0].read_text())['step_id']
                save(out/'launch.json',record)
        rc=process.returncode
    records=[json.loads(f.read_text()) for f in sorted(out.glob('runtime-rank*.json'))]
    valid=rc==0 and len(records)==4 and all(r['state']=='COMPLETED' for r in records)
    if case['type']=='inference':
        reports=[json.loads(f.read_text()) for f in out.glob('stable-rank*.json')]
        valid=valid and len(reports)==4 and all(r['status']=='completed' and r.get('model_request_e2e') for r in reports)
    else:
        reports=[json.loads(f.read_text()) for f in out.glob('training-summary-rank*.json')]
        metrics=list(out.glob('training-metrics-rank*.jsonl'))
        valid=valid and len(reports)==4 and (len(metrics)==4 or
            (trial['pilot'] and (out/'training-metrics.jsonl').is_file()))
    record.update(returncode=rc,state='COMPLETED' if valid else 'FAILED',finished_at=now())
    save(status,record)
    if not valid:
        raise RuntimeError('Trial failed or required output missing: '+str(out))
    return record

def main():
    with (ROOT/'allocation-use.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        status=dict(state='RUNNING',pid=os.getpid(),host=os.uname().nodename,started_at=now(),completed=[])
        save(ROOT/'suite-status.json',status)
        try:
            for case in json.loads((ROOT/'cases.json').read_text()):
                for trial in case['trials']:
                    status.update(current=trial,checked_at=now())
                    save(ROOT/'suite-status.json',status)
                    record=one(case,trial)
                    status['completed'].append(record)
                    save(ROOT/'suite-status.json',status)
            status.update(state='COMPLETED',finished_at=now(),current=None)
        except BaseException as exc:
            status.update(state='FAILED',finished_at=now(),error=repr(exc))
            raise
        finally:
            save(ROOT/'suite-status.json',status)

if __name__=='__main__':
    main()
