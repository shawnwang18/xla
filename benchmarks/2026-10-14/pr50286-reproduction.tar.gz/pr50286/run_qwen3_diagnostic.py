"""One bounded repeat set for noisy Qwen inference; preserve original trials."""
import fcntl
import json
import os
from pathlib import Path
from run_recovery_worker import ROOT, now, save, steps, one

def main():
    plan=json.loads((ROOT/'parallel-plan.json').read_text())
    worker=next(w for w in plan['workers'] if w['allocation_id']=='2521076')
    primary=json.loads((ROOT/'suite-status.json').read_text())
    assert primary['workers']['2521076']['state']=='COMPLETED'
    lease=Path(worker['reuse_lock']).open('a')
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    claim_path=Path(worker['reuse_lock']).parent/'active-reuse.json'
    claim=json.loads(claim_path.read_text())
    assert claim['active_task']==plan['thread_id'] and claim['active_root']==str(ROOT)
    assert not steps('2521076')
    status_path=ROOT/'worker-diagnostic-qwen3.json'
    assert not status_path.exists(), 'Reconcile prior diagnostic before any restart'
    case=json.loads((ROOT/'qwen3-diagnostic-case.json').read_text())
    status=dict(state='RUNNING',pid=os.getpid(),host=os.uname().nodename,
                started_at=now(),allocation_id='2521076',worker=worker,
                primary_started_at=primary['started_at'],completed=[],current=None,
                reason='Original timings noisy despite identical optimized HLO; one additional ON/OFF/OFF/ON set, unchanged configuration')
    claim.update(reuse_state='RUNNING_DIAGNOSTIC',diagnostic_pid=os.getpid(),updated_at=now())
    save(claim_path,claim)
    save(status_path,status)
    try:
        for trial in case['trials']:
            status.update(current=trial,checked_at=now())
            save(status_path,status)
            status['completed'].append(one(case,trial,worker))
            save(status_path,status)
        status.update(state='COMPLETED',current=None,finished_at=now())
    except BaseException as exc:
        status.update(state='FAILED',error=repr(exc),finished_at=now())
        raise
    finally:
        save(status_path,status)
        claim.update(reuse_state='IDLE_RESERVED',updated_at=now(),diagnostic_state=status['state'])
        save(claim_path,claim)
if __name__=='__main__':main()
