#!/bin/bash
set -euo pipefail
python3 /tmp/step_start.py
bash /tmp/test.sh "$CB_OUTPUT_DIR/outputs"
touch "$CB_OUTPUT_DIR/done-$SLURM_PROCID"
