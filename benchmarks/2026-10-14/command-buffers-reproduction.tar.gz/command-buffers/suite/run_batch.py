"""Run one model's four modes sequentially in an exclusive allocation."""
from pathlib import Path
import datetime
import json
import os
import subprocess

ROOT = Path(__file__).resolve().parent
RESULT = Path(os.environ['BASE_RESULT_DIR'])
MODES = ['OFF', 'ALWAYS_UPDATE', 'SKIP_TEMP', 'SKIP_PROFILED']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(value):
    path = RESULT / 'run_status.json'
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def main():
    assert os.environ['SLURM_JOB_NODELIST'] == 'gb-nvl-053-compute09'
    status = dict(job_id=os.environ['SLURM_JOB_ID'], state='RUNNING', modes=[], started_at=now())
    save(status)
    rc = 1
    try:
        for mode in MODES:
            directory = RESULT / 'modes' / mode
            directory.mkdir(parents=True, exist_ok=False)
            env = os.environ.copy()
            env.update(CB_MODE=mode, CB_OUTPUT_DIR='/opt/workspace/modes/' + mode,
                       ENROOT_CONFIG_PATH='/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/.enroot')
            mounts = [f'{RESULT}:/opt/workspace']
            for name in ['test.sh', 'run_preflight.py', 'stable_inference.py',
                         'gc_observer.py', 'step_start.py', 'run_mode.sh']:
                mounts.append(f'{ROOT / name}:/tmp/{name}:ro')
            mounts += [f'{ROOT / "wheels"}:/tmp/workload-wheels:ro',
                       f'{ROOT / "skill/assets/jax-run-scripts/bindpcie"}:/tmp/bindpcie:ro',
                       env['CUSTOM_MOUNTS']]
            image = ('oauth2@' + env['CONTAINER']).replace('gitlab-master.nvidia.com:5005/',
                                                         'gitlab-master.nvidia.com:5005#')
            command = ['srun', '--nodes=1', '--ntasks=4', '--ntasks-per-node=4',
                       '--cpus-per-task=16', '--cpu-bind=none', '--gres=gpu:GB200:4',
                       '--kill-on-bad-exit=1', '--container-image=' + image,
                       '--container-mounts=' + ','.join(mounts), '--container-remap-root',
                       '--container-writable', '--container-workdir=/opt/maxtext', '--export=ALL',
                       '--output=' + str(directory / 'rank-%t.log'),
                       '--error=' + str(directory / 'rank-%t.log'), 'bash', '/tmp/run_mode.sh']
            record = dict(mode=mode, started_at=now(), command=command, state='RUNNING')
            status['modes'].append(record)
            save(status)
            rc = subprocess.run(command, env=env, check=False).returncode
            record.update(returncode=rc, finished_at=now(), state='COMPLETED' if rc == 0 else 'FAILED')
            save(status)
            if rc:
                break
    except Exception as exc:
        rc = 1
        status['error'] = str(exc)
    status.update(returncode=rc, finished_at=now(), state='COMPLETED' if rc == 0 else 'FAILED')
    save(status)
    return rc


if __name__ == '__main__':
    raise SystemExit(main())
