#!/bin/bash
set -euo pipefail
export ADDITIONAL_ARGS='num_slices=1 async_checkpointing=false max_prefill_predict_length=1024 max_target_length=2048 model_name=gemma3-27b per_device_batch_size=120 scan_layers=false tokenizer_path=/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.gemma3 dtype=bfloat16 weight_dtype=bfloat16 quantization= quantize_kvcache=false attention=dot_product inference_microbenchmark_prefill_lengths="1024" inference_microbenchmark_stages=prefill,generate inference_microbenchmark_loop_iters=300 gcs_metrics=false dcn_data_parallelism=1 dcn_fsdp_parallelism=1 dcn_fsdp_transpose_parallelism=1 dcn_pipeline_parallelism=1 dcn_expert_parallelism=1 ici_data_parallelism=1 ici_fsdp_parallelism=4 ici_fsdp_transpose_parallelism=1 ici_sequence_parallelism=1 ici_tensor_parallelism=1 ici_tensor_sequence_parallelism=1 ici_autoregressive_parallelism=1 ici_pipeline_parallelism=1 ici_expert_parallelism=1'
export BASE_RESULT_DIR=/home/scratch.shawnw_inf/workload-runs/inference-cb-suite-20261013/results/ci-infer-gemma3-27b-bf16-1n4g_4fd2a306d454
export BASE_XLA_FLAGS='--xla_gpu_enable_command_buffer= --xla_gpu_command_buffer_unroll_loops=false --xla_gpu_enable_cudnn_fmha=1 --xla_gpu_require_exclusive_lock=0 --xla_gpu_enable_latency_hiding_scheduler=1 --xla_gpu_command_buffer_scheduling_mode=LHS --xla_gpu_command_buffer_update_mode=ALWAYS_UPDATE --xla_disable_hlo_passes=rematerialization'
export BINDPCIE=0
export BUILD_JAX=0
export CLUSTER=dlcluster
export CONTAINER=gitlab-master.nvidia.com:5005/dl/dgx/jax:maxtext-2026-10-12
export CUDA_SCALE_LAUNCH_QUEUES=1x
export CUSTOM_MOUNTS=/home/scratch.shawnw_inf/workload-runs/inference-cb-suite-20261013/skill/assets/jax-run-scripts/inference_aot_runner.py:/tmp/jax-workloads/inference_aot_runner.py:ro
export ENABLE_CMD_BUFFER_DUMPS=0
export ENABLE_NCCL_DEBUG=0
export ENABLE_PGLE=0
export ENABLE_VALGRIND_DEBUG=0
export ENABLE_XLA_DUMPS=0
export EXPECTED_BATCH=480
export EXPECTED_LAYERS=62
export EXPECTED_MODEL=gemma3-27b
export GDB=0
export GPUS_PER_NODE=4
export INFERENCE_AOT_MODE=consistent
export MAXTEXT_CONFIG_PATH=/opt/maxtext/src/maxtext/configs/base.yml
export MAXTEXT_IMPL=container
export MAXTEXT_RUNNER=inference
export NCCL_DEBUG=VERSION
export NCCL_GRAPH_MIXING_SUPPORT=1
export NODES=1
export NVTE_FUSED_ATTN=1
export PREC=bfloat16
export PROFILE=''
export PYTHONUNBUFFERED=1
export RUN=maxText
export STEPS=1
export SUITE_ROOT=/home/scratch.shawnw_inf/workload-runs/inference-cb-suite-20261013
export TF_CPP_MAX_LOG_LEVEL=300
export TF_CPP_MIN_LOG_LEVEL=0
export TF_CPP_VMODULE=''
export TF_FORCE_GPU_ALLOW_GROWTH=true
export XLA_PYTHON_CLIENT_ALLOCATOR=bfc
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.97
sbatch --parsable --account=blackwell --partition=gb200nvl72_preprod --nodes=1 --nodelist=gb-nvl-053-compute09 --ntasks=4 --ntasks-per-node=4 --cpus-per-task=16 --gres=gpu:GB200:4 --exclusive --mem=0 --time=90 --dependency=afterok:2507930 --job-name=infer-cb-gemma3-27b --output=/home/scratch.shawnw_inf/workload-runs/inference-cb-suite-20261013/results/ci-infer-gemma3-27b-bf16-1n4g_4fd2a306d454/slurm-%j.log /home/scratch.shawnw_inf/workload-runs/inference-cb-suite-20261013/suite.sbatch
