"""Run the remaining suite as serialized steps, then retain the allocation."""
from pathlib import Path
import datetime
import fcntl
import json
import os
import shlex
import subprocess
import time

import sys
SCRIPT = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve()
BASE = SCRIPT.parent
REQUEST = json.loads((SCRIPT / 'plan.json').read_text())
CASE = json.loads((ROOT / 'case.json').read_text())
MODES = ['OFF', 'ALWAYS_UPDATE', 'SKIP_TEMP', 'SKIP_PROFILED']
ALLOCATION = json.loads((ROOT / 'submission.json').read_text())['allocation_id']
NODE = None


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, data):
    tmp = path.with_suffix('.holder.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)


def original_environment(directory):
    env = {}
    for line in (directory / 'launch_env.sh').read_text().splitlines():
        if line.startswith('export '):
            fields = shlex.split(line[7:])
            assert len(fields) == 1
            key, value = fields[0].split('=', 1)
            env[key] = value
    return env


def run_model(case, progress):
    model = case['model']
    original = Path(case['result_dir'])
    result = ROOT / 'results' / model
    result.mkdir(parents=True, exist_ok=False)
    resolved = json.loads((original / 'resolved.json').read_text())
    env = os.environ.copy()
    env.update(original_environment(original))
    env['BASE_RESULT_DIR'] = str(result)
    env['ENROOT_CONFIG_PATH'] = str(BASE.parent / 'deepseek4-cb-modes-20261013/.enroot')
    resolved.update(result_dir=str(result), superseded_pending_job_id=case['job_id'],
                    allocation_id=ALLOCATION, slurm_job_id=ALLOCATION, actual_node=NODE,
                    relocated_at=now(), launch_method='one model per retained allocation; four sequential modes on its fixed node',
                    original_slurm_command=resolved.pop('slurm_command'))
    resolved['slurm_command'] = ['srun', '--jobid=' + ALLOCATION, '--nodelist=' + NODE]
    resolved['settings'].update(partition=REQUEST['partition'], account=REQUEST['account'])
    save(result / 'resolved.json', resolved)
    status = dict(job_id=ALLOCATION, allocation_id=ALLOCATION, model=model, node=NODE,
                  superseded_pending_job_id=case['job_id'], state='RUNNING', started_at=now(), modes=[])
    progress['models'][model] = dict(state='RUNNING', result_dir=str(result), started_at=now())
    save(ROOT / 'suite_status.json', progress)
    save(result / 'run_status.json', status)
    rc = 1
    # Retain the original per-model time budget within the larger reservation.
    deadline = time.monotonic() + 60 * int(resolved['settings']['time'])
    try:
        for mode in MODES:
            directory = result / 'modes' / mode
            directory.mkdir(parents=True, exist_ok=False)
            env.update(CB_MODE=mode, CB_OUTPUT_DIR='/opt/workspace/modes/' + mode)
            mounts = [f'{result}:/opt/workspace']
            for name in ['test.sh', 'run_preflight.py', 'stable_inference.py', 'gc_observer.py', 'run_mode.sh']:
                mounts.append(f'{BASE / name}:/tmp/{name}:ro')
            mounts.append(f'{SCRIPT / "step_start.py"}:/tmp/step_start.py:ro')
            mounts += [f'{BASE / "wheels"}:/tmp/workload-wheels:ro',
                       f'{BASE / "skill/assets/jax-run-scripts/bindpcie"}:/tmp/bindpcie:ro', env['CUSTOM_MOUNTS']]
            image = ('oauth2@' + env['CONTAINER']).replace('gitlab-master.nvidia.com:5005/',
                                                         'gitlab-master.nvidia.com:5005#')
            remaining = max(1, int((deadline - time.monotonic()) / 60))
            command = ['srun', '--jobid=' + ALLOCATION, '--nodelist=' + NODE, '--nodes=1',
                       '--ntasks=4', '--ntasks-per-node=4', '--cpus-per-task=16', '--cpu-bind=none',
                       '--gres=gpu:GB200:4', '--kill-on-bad-exit=1', '--time=' + str(remaining),
                       '--container-image=' + image, '--container-mounts=' + ','.join(mounts),
                       '--container-remap-root', '--container-writable', '--container-workdir=/opt/maxtext',
                       '--export=ALL', '--output=' + str(directory / 'rank-%t.log'),
                       '--error=' + str(directory / 'rank-%t.log'), 'bash', '/tmp/run_mode.sh']
            record = dict(mode=mode, state='RUNNING', started_at=now(), command=command)
            status['modes'].append(record)
            save(result / 'run_status.json', status)
            with (directory / 'srun.log').open('a') as launch_log:
                rc = subprocess.run(command, env=env, check=False, stdout=launch_log, stderr=subprocess.STDOUT).returncode
            step_file = directory / 'step.json'
            if step_file.exists():
                step = json.loads(step_file.read_text())
                record['step_id'] = step['SLURM_JOB_ID'] + '.' + step['SLURM_STEP_ID']
            record.update(returncode=rc, state='COMPLETED' if rc == 0 else 'FAILED', finished_at=now())
            save(result / 'run_status.json', status)
            if rc:
                break
    except Exception as exc:
        rc = 1
        status['error'] = str(exc)
    status.update(returncode=rc, state='COMPLETED' if rc == 0 else 'FAILED', finished_at=now())
    save(result / 'run_status.json', status)
    progress['models'][model].update(state=status['state'], returncode=rc,
                                     step_ids=[m['step_id'] for m in status['modes'] if 'step_id' in m],
                                     finished_at=now())
    save(ROOT / 'suite_status.json', progress)
    return rc



def job_record():
    p = subprocess.run(['scontrol', 'show', 'job', ALLOCATION, '-o'], text=True,
                       capture_output=True, check=True, timeout=30)
    import re
    return dict(re.findall(r'(\w+)=([^ ]*)', p.stdout)), p.stdout.strip()


def main():
    global NODE
    with (ROOT / 'controller.lock').open('a') as controller_lock:
        fcntl.flock(controller_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if (ROOT / 'suite_status.json').exists():
            raise RuntimeError('Existing launch state: reconcile manually, never repeat the model automatically')
        (ROOT / 'controller.pid').write_text(str(os.getpid()) + '\n')
        errors = 0
        while True:
            try:
                record, scheduler = job_record()
                errors = 0
                save(ROOT / 'controller_status.json', dict(state='WAITING_FOR_ALLOCATION', time=now(), scheduler=scheduler))
                if record.get('JobState') == 'RUNNING':
                    break
                if record.get('JobState') != 'PENDING':
                    save(ROOT / 'controller_status.json', dict(state='STOPPED', reason='Allocation is not running/pending', time=now(), scheduler=scheduler))
                    return
            except (OSError, subprocess.SubprocessError) as exc:
                errors += 1
                save(ROOT / 'controller_status.json', dict(state='UNKNOWN', consecutive_errors=errors, time=now(), error=str(exc)))
            time.sleep(min(60 * (2 ** min(errors, 3)), 480))
        NODE = record['NodeList']
        assert record['UserId'].startswith('shawnw(') and record['Account'] == 'blackwell'
        assert record['NumNodes'] == '1' and 'gres/gpu:gb200=4' in record['AllocTRES']
        REQUEST['partition'] = record['Partition']
        end = datetime.datetime.fromisoformat(record['EndTime']).replace(tzinfo=datetime.timezone.utc)
        required = int(json.loads((Path(CASE['result_dir']) / 'resolved.json').read_text())['settings']['time']) * 60 + 600
        assert (end - datetime.datetime.now(datetime.timezone.utc)).total_seconds() >= required, 'Insufficient allocation time'
        submission = json.loads((ROOT / 'submission.json').read_text())
        lock_path = Path(submission.get('reuse_lock', str(ROOT / 'allocation-use.lock')))
        allocation_path = Path(submission.get('allocation_metadata', str(ROOT / 'allocation.json')))
        with lock_path.open('a') as allocation_lock:
            fcntl.flock(allocation_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            active = subprocess.run(['squeue', '--steps', '-j', ALLOCATION, '-h', '-o', '%i'],
                                    check=True, capture_output=True, text=True, timeout=30).stdout.split()
            assert not [s for s in active if s.rsplit('.', 1)[-1] not in {'batch', 'extern'}], active
            if ALLOCATION == '2521076':
                assert not (BASE / 'reservation-20261014/launch-authorized.json').exists()
            allocation = dict(allocation_id=ALLOCATION, node=NODE, cluster='dlcluster', owner='shawnw',
                              thread_id=REQUEST['thread_id'], gpu_type='GB200', gpus=4,
                              partition=record['Partition'], time_limit=record['TimeLimit'],
                              start_time=record['StartTime'], end_time=record['EndTime'],
                              reuse_lock=str(lock_path), state='RUNNING_MODEL', model=CASE['model'],
                              scheduler_record=scheduler, controller_pid=os.getpid(), updated_at=now())
            save(allocation_path, allocation)
            save(ROOT / 'allocation.json', allocation)
            progress = dict(allocation_id=ALLOCATION, node=NODE, state='RUNNING', started_at=now(), models={})
            save(ROOT / 'controller_status.json', dict(state='RUNNING_MODEL', time=now(), node=NODE))
            rc = run_model(CASE, progress)
            progress.update(state='COMPLETED' if rc == 0 else 'FAILED', finished_at=now())
            save(ROOT / 'suite_status.json', progress)
            allocation.update(state='IDLE_READY' if rc == 0 else 'IDLE_AFTER_FAILURE', model_state=progress['state'], updated_at=now())
            save(allocation_path, allocation)
            save(ROOT / 'allocation.json', allocation)
            save(ROOT / 'controller_status.json', dict(state=progress['state'], time=now(), node=NODE, returncode=rc))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        save(ROOT / 'controller_error.json', dict(time=now(), error=repr(exc), allocation_id=ALLOCATION))
        raise
