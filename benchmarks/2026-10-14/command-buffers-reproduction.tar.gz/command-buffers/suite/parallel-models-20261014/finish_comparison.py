"""Archive validated model results and consolidate the frozen five-model suite."""
from pathlib import Path
import datetime
import hashlib
import html
import json
import shutil

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
MODES=['OFF','ALWAYS_UPDATE','SKIP_TEMP','SKIP_PROFILED']
def save(path, data):path.write_text(json.dumps(data,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
common=ROOT/'gemma2-27b/results/gemma2-27b/runtime-source'
common_manifest=json.loads((common/'manifest.json').read_text())
for name in ['llama3-8b','qwen3-8b']:
 r=ROOT/name/'results'/name
 run=json.loads((r/'run_status.json').read_text());comparison=json.loads((r/'stable-comparison.json').read_text())
 assert run['state']=='COMPLETED' and run['returncode']==0
 assert all(m['status']=='stable' for m in comparison['modes'])
 p=json.loads((r/'modes/OFF/container_provenance.json').read_text())
 assert p['revisions']==common_manifest['revisions']
 snap=r/'runtime-source';snap.mkdir(exist_ok=True);files=[]
 for entry in common_manifest['files']:
  if entry.get('missing') or 'gemma2' in entry['path']:continue
  rel=Path(entry['path']).relative_to('/opt');src=common/rel
  assert hashlib.sha256(src.read_bytes()).hexdigest()==entry['sha256']
  dst=snap/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);files.append(entry)
 cfg=snap/'maxtext/src/maxtext/configs/models'/f'{name}.yml';cfg.parent.mkdir(parents=True,exist_ok=True);cfg.write_text(p['model_config'])
 save(snap/'manifest.json',dict(revisions=p['revisions'],files=files,model_config_source='Own container_provenance.json',common_source_origin=str(common/'manifest.json'),source_capture_step='2521171.1',reuse_reason='Shared pinned image and exact repository revisions; common source SHA256 verified. Each mode retains its own model YAML, XLA source snapshots, package versions and hardware records.'))
 skill=snap/'skill';skill.mkdir(exist_ok=True)
 for fname in ['stable_inference.py','gc_observer.py','test.sh','run_preflight.py','run_mode.sh','collect_stable.py']:
  shutil.copy2(BASE/fname,skill/fname)
 for fname in ['inference_aot_runner.py','inference_legacy_no_tensor_transpose.yml']:
  shutil.copy2(BASE/'skill/assets/jax-run-scripts'/fname,skill/fname)
 stats=[];hardware=[];total_samples=0
 for m in comparison['modes']:
  d=r/'modes'/m['mode'];mode_summary=dict(mode=m['mode'],rank_samples=[],gc=[],stability={})
  step=json.loads((d/'step.json').read_text());hw=json.loads((d/'hardware.json').read_text());hardware.append((step['SLURM_JOB_NODELIST'],hw['gpu_info']))
  for rank in range(4):
   samples=[json.loads(line) for line in (d/f'samples-rank{rank}.jsonl').read_text().splitlines()]
   assert len(samples)==600
   for stage in ['prefill','decode']:
    points=[s for s in samples if s['stage']==stage]
    assert [s['step'] for s in points]==list(range(1,301))
   total_samples+=len(samples);mode_summary['rank_samples'].append(len(samples))
   g=json.loads((d/f'gc-rank{rank}.json').read_text());assert g['policy_unchanged']
   events=g['events'];gen2=[e for e in events if e['generation']==2]
   mode_summary['gc'].append(dict(rank=rank,events=len(events),gen2_events=len(gen2),max_gen2_ms=max((e['duration_ms'] for e in gen2),default=0),timed_gen2_events=sum(e.get('stage') is not None for e in gen2),policy_unchanged=True))
  for stage,v in m['stages'].items():
   mode_summary['stability'][stage]=dict(global_cv=v['cv_percent'],global_half_drift=v['half_mean_drift_percent'],max_rank_cv=max(x['cv_percent'] for x in v['rank_statistics']),max_rank_half_drift=max(x['half_mean_drift_percent'] for x in v['rank_statistics']),stable=v['stable'])
  stats.append(mode_summary)
 assert len(set(hardware))==1 and total_samples==9600
 report=json.loads((r/'modes/OFF/stable-rank0.json').read_text())
 best=min(comparison['modes'],key=lambda m:m['stages']['decode']['mean_ms'])
 summary=dict(collected_at=now(),model=name,allocation_id=run['allocation_id'],node=run['node'],benchmark_step_ids=[m['step_id'] for m in run['modes']],supervisor_state=run['state'],supervisor_returncode=0,all_workload_steps_completed_zero=True,parent_kept_open=True,allocation_reuse_state='IDLE_READY',collector_exit_code=0,all_modes_stable=True,total_raw_samples=total_samples,measurement_window=[101,300],warmup_steps=100,global_batch=report['global_batch'],model_params=report['model_params'],decoder_layers=report['decoder_layers'],true_prompt_tokens=report['true_prompt_tokens'],padded_prefill_tokens=report['padded_prefill_tokens'],framework_source_patches=[],revisions=p['revisions'],versions=p['versions'],same_gpu_uuids_and_node_across_modes=True,stability_and_gc=stats,best_decode_mode=best['mode'],best_decode_speedup_vs_OFF=best['stages']['decode']['speedup_vs_OFF'],retry_submitted=False)
 save(r/'completion-summary.json',summary)
 (r/'collector.log').write_text((r/'comparison.md').read_text()+'\ncollect_stable.py exit code: 0; all four modes stable.\n')
 manifest={str(f.relative_to(r)):dict(bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(r.rglob('*')) if f.is_file() and f.name!='artifact-manifest.json'}
 save(r/'artifact-manifest.json',manifest)

cases=[('Gemma 2 2B',BASE/'results/infer-gemma2-2b-bf16-1n4g_c262f0966cb2','2507927','gb-nvl-053-compute09'),('Llama 3 8B',ROOT/'llama3-8b/results/llama3-8b','2521076','gb200-nvl4-ts2-79'),('Qwen 3 8B',ROOT/'qwen3-8b/results/qwen3-8b','2521170','gb200-nvl4-ts2-88'),('Gemma 2 27B',ROOT/'gemma2-27b/results/gemma2-27b','2521171','gb200-nvl4-ts2-82'),('Gemma 3 27B',ROOT/'gemma3-27b/results/gemma3-27b','2521172','gb200-nvl4-ts2-81')]
all_results=[]
for label,path,job,node in cases:
 data=json.loads((path/'stable-comparison.json').read_text());status=json.loads((path/'run_status.json').read_text())
 all_results.append(dict(label=label,allocation_or_job=job,node=node,result_dir=str(path),supervisor_state=status['state'],comparison=data))
result=dict(created_at=now(),suite='Five full-size random-weight inference models',image='gitlab-master.nvidia.com:5005/dl/dgx/jax:maxtext-2026-10-12',method='All steps 101–300 after 100 warmups; per-step slowest synchronized rank; CV <=10% and half-window mean drift <=5% globally and for every rank',same_node_per_model=True,models_run_in_parallel=True,command_types='Every image-supported type except WHILE and CONDITIONAL; OFF disables buffers',models=all_results)
save(ROOT/'suite-comparison.json',result)

def md_table(rows):
 widths=[max(len(row[i]) for row in rows) for i in range(len(rows[0]))]
 line=lambda row:'| '+' | '.join(x.ljust(w) for x,w in zip(row,widths))+' |'
 return '\n'.join([line(rows[0]),line(['-'*w for w in widths]),*[line(row) for row in rows[1:]]])+'\n'
def stage_rows(stage):
 rows=[['Model','Batch',*[mode+' (ms)' for mode in MODES]]]
 for case in all_results[:3]:
  comp=case['comparison'];rows.append([case['label'],str(comp['global_batch']),*[f"{m['stages'][stage]['mean_ms']:.3f}" for m in comp['modes']]])
 return rows
(ROOT/'prefill-comparison.txt').write_text(md_table(stage_rows('prefill')))
(ROOT/'decode-comparison.txt').write_text(md_table(stage_rows('decode')))
def table(rows):return '<table><thead><tr>'+''.join('<th>'+html.escape(v)+'</th>' for v in rows[0])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in row)+'</tr>' for row in rows[1:])+'</tbody></table>'
body=['<!doctype html><meta charset="utf-8"><title>Inference command-buffer comparison</title><style>body{font:16px/1.5 system-ui;max-width:1350px;margin:35px auto;padding:0 24px}table{border-collapse:collapse;margin:20px 0;width:100%}th,td{border:1px solid #ccc;padding:8px;text-align:right}th:first-child,td:first-child{text-align:left}th{background:#f1f4f8}code{background:#eee;padding:2px 4px}a{color:#175dc3}</style>', '<h1>Inference command-buffer comparison</h1>', '<p>Three models completed all four modes with stable measurements. Gemma 2 27B and Gemma 3 27B ran out of GPU memory during OFF initialization and produced no timing samples. These are full-size random-weight microbenchmarks; checkpoint accuracy was not tested.</p>', '<p>Fixed measurement window: <strong>all steps 101–300 after 100 warmups</strong>, without dropping stalls or selecting another window. Each step uses the slowest synchronized rank; global and every rank must satisfy CV ≤10% and half-window mean drift ≤5%. Each successful model has 9,600 raw samples (four modes × four ranks × two stages × 300 calls).</p>', '<h2>Prefill latency (ms)</h2>',table(stage_rows('prefill')), '<h2>Decode latency (ms)</h2>',table(stage_rows('decode'))]
throughput=[['Model','Batch',*[m+' (tokens/s)' for m in MODES]]]
for case in all_results[:3]:
 c=case['comparison'];throughput.append([case['label'],str(c['global_batch']),*[f"{m['stages']['decode']['tokens_per_second']:.3f}" for m in c['modes']]])
body += ['<h2>Decode throughput</h2>',table(throughput),'<p>Each speedup uses the same model and node. Gemma 2 2B: ALWAYS_UPDATE is 5.2% faster than OFF in decode. Llama 3 8B: SKIP_TEMP is 7.5% faster than OFF in decode. Qwen 3 8B: OFF is fastest; all enabled modes are slower. OFF gives the fastest prefill for all three successful models.</p>']
stability=[['Model','Mode','Prefill max CV (%)','Prefill max drift (%)','Decode max CV (%)','Decode max drift (%)','Result']]
for case in all_results[:3]:
 for m in case['comparison']['modes']:
  values=[]
  for stage in ['prefill','decode']:
   v=m['stages'][stage];values.extend([f"{max(v['cv_percent'],*[x['cv_percent'] for x in v['rank_statistics']]):.3f}",f"{max(v['half_mean_drift_percent'],*[x['half_mean_drift_percent'] for x in v['rank_statistics']]):.3f}"])
  stability.append([case['label'],m['mode'],*values,m['status']])
body += ['<h2>Stability checks</h2>','<p>Values below show the maximum across the global series and all four rank series. All samples, including pauses, remain in the calculations. GC policy was unchanged.</p>',table(stability),'<h2>Failed configurations</h2>',table([['Model','Batch','Step','Outcome'],['Gemma 2 27B','600','2521171.0','GPU OOM; 444.14 GiB I/O buffers vs 178.77 GiB device limit'],['Gemma 3 27B','480','2521172.0','GPU OOM; 477.81 GiB I/O buffers vs 178.77 GiB device limit']]),'<p>Both failures occurred in OFF initialization, with unsharded cache-batch rules on an FSDP-only four-GPU mesh. Supervisors returned 143 after worker errors caused Slurm step termination (CANCELLED, exit 0:15). Other modes were not started. No prefill/decode performance or speedup is available for either model. Configuration-only candidates are sharding cache_batch over FSDP or reducing batch uniformly; neither has been validated or relaunched.</p>','<h2>Run placement and provenance</h2>',table([['Model','Batch','Job/allocation','Node','State']]+[[c['label'],str(c['comparison']['global_batch']),c['allocation_or_job'],c['node'],c['supervisor_state']] for c in all_results]),'<p>Gemma 2 2B ran earlier on an NVL72 node. The remaining models ran concurrently on separate exclusive NVL4 nodes, with modes sequential within each model. All nodes used four GB200 GPUs; the GPU UUIDs and node were identical across all modes of each newly successful model. Speedups are measured within each model.</p>','<p>Image: <code>maxtext-2026-10-12</code>. BF16 weights and compute, no KV quantization, consistent-AOT skill runner. Enabled modes use all supported command types except WHILE and CONDITIONAL (10 types included); OFF disables command buffers. No MaxText/JAX source edits. Full model sizes and frozen model/mesh/batch settings were retained. True prompts: four tokens for Gemma 2 2B/Llama 3 8B and three for Qwen 3 8B, padded to 1024; maximum sequence length 2048.</p>','<p>All four reusable parent allocations remain open until their eight-hour limits expire (08:28–08:37 UTC on 2026-10-14). Workload completion is determined from exact steps and supervisors, separately from the parent RUNNING state.</p>','<h2>Collected artifacts</h2><ul>']
for case in all_results:
 path=case['result_dir'];body.append('<li>'+html.escape(case['label'])+': <code>'+html.escape(path)+'</code> (comparison, reports, raw samples where generated, rank logs, GC observations, hardware/provenance, scheduler snapshots).</li>')
body+=['</ul><p>Machine-readable consolidated results: suite-comparison.json. Each newly collected model has completion-summary.json and an artifact hash manifest. Common runtime sources reuse the exact matching image/revision snapshot with provenance recorded; per-mode XLA snapshots and model configurations are retained.</p>']
(ROOT/'suite-comparison.html').write_text('\n'.join(body))
print(md_table(stage_rows('prefill')))
print(md_table(stage_rows('decode')))
print('Saved consolidated suite-comparison.html and suite-comparison.json')
