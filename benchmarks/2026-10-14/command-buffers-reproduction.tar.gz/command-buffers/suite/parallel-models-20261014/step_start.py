"""Persist the exact Slurm step and verify the requested GPU allocation."""
from pathlib import Path
import json
import os
import subprocess

if os.environ["SLURM_NTASKS"] != "4":
    raise RuntimeError("Expected four GPU worker tasks")
if os.environ["SLURM_PROCID"] == "0":
    record = {key: os.environ.get(key) for key in [
        "SLURM_JOB_ID", "SLURM_STEP_ID", "SLURM_JOB_NODELIST", "SLURM_NTASKS"]}
    gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total",
                          "--format=csv,noheader"], check=True, capture_output=True, text=True)
    lines = gpu.stdout.strip().splitlines()
    if len(lines) != 4 or any("GB200" not in line for line in lines):
        raise RuntimeError("Expected exactly four GB200 GPUs: " + gpu.stdout)
    record["gpus"] = lines
    (Path(os.environ["CB_OUTPUT_DIR"]) / "step.json").write_text(json.dumps(record, indent=2) + "\n")
    print("WORKLOAD_STEP " + json.dumps(record), flush=True)

if os.environ["SLURM_PROCID"] == "0":
    topology = {}
    for key, command in {
        'gpu_info': ['nvidia-smi', '--query-gpu=name,uuid,memory.total,driver_version', '--format=csv,noheader'],
        'nvlink_topology': ['nvidia-smi', 'topo', '-m'],
        'architecture': ['uname', '-m'],
    }.items():
        proc = subprocess.run(command, text=True, capture_output=True, check=True)
        topology[key] = proc.stdout
    (Path(os.environ['CB_OUTPUT_DIR']) / 'hardware.json').write_text(json.dumps(topology, indent=2) + '\n')
