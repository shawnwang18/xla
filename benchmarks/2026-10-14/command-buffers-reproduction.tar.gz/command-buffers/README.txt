Original full-size random-weight BF16 command-buffer comparison.
The suite-comparison.json and deepseek/off-retry-01/comparison-updated/stable-comparison.json
identify the accepted measurements. Preserve every sample in steps101–300 after100 warmups.
The original/retry OFF decode failure evidence is retained. Failed Gemma27B attempts have no timings.
The environment JSON records each model, mode, launch settings, exact flags and image revisions.
Recorded launcher perf_steps40–60 is inherited metadata; stable-runner100+200 controls these measurements.
Original Slurm IDs and absolute paths are historical; adapt them to a new allocation before replay.

Reproduction archive recorded on 2026-10-14.

Contents: frozen harness/runner code, resolved per-trial settings, mode flags,
per-workload environment records, available runtime argv, hardware/driver observations,
build/library hashes, software revisions, results and measurement protocols.
Historical failed and superseded attempts may be present; results-summary.json and
the environment index identify the exact final trials used for the comparison.

Reproduction procedure:
1. Use environments/<workload>.json to select the campaign and exact final variant.
2. Obtain the recorded internal container image; registry access is required.
   A dated image tag is not an immutable digest. Use a recorded digest where available;
   otherwise check the saved source revisions/library hashes before accepting a rerun.
3. For PR experiments, restore/rebuild the recorded PR XLA/JAX binaries and verify
   the build-manifest hashes. These binaries override the container's bundled jaxlib;
   using the base image alone does not reproduce a PR experiment.
4. Stage the frozen harness and configs on shared storage. Preserve the /work,
   /result and /opt/pr-jaxlibs container mount contracts in rank.sh and launch.json.
   Adapt original absolute paths, node constraints and Slurm IDs to your new setup.
5. Reuse or acquire matching GPU resources. All dlcluster node access goes through
   the dlcluster head node. Launch compute as scheduler steps, never on the login node.
6. Run one configuration at a time on the same node/GPU set for a workload. Preserve
   batch, precision, parallelism, allocator policy, flag order, warmups and sample window.
7. Use the archived collectors and protocol to evaluate full windows and failed runs.
   A successful process exit alone does not establish stable timing or model accuracy.

Scope: this saves configurations and code, not a bootable container or binary backup.
Large wheels, CUDA libraries, full HLO dumps, Nsight captures and model checkpoints are
not included. Available hashes and original artifact paths identify those dependencies.
Inference uses random weights. Historical commands are evidence, not an automatically
validated portable launcher. This documentation/archive task did not launch new GPU tests.
No credentials or authentication files are included.
