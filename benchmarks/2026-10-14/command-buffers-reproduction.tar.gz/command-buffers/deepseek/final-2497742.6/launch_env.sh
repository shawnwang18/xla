#!/bin/bash
set -euo pipefail
export ADDITIONAL_ARGS='num_slices=1 model_name=deepseek4-284b tokenizer_type=sentencepiece tokenizer_path=/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.default max_prefill_predict_length=4096 max_target_length=8192 per_device_batch_size=1 attention=dot_product scan_layers=false dtype=bfloat16 weight_dtype=bfloat16 quantization= quantize_kvcache=false sparse_matmul=false capacity_factor=-1.0 async_checkpointing=false inference_microbenchmark_prefill_lengths="4096" inference_microbenchmark_stages=prefill,generate inference_microbenchmark_loop_iters=32 gcs_metrics=false dcn_data_parallelism=1 dcn_fsdp_parallelism=1 dcn_fsdp_transpose_parallelism=1 dcn_pipeline_parallelism=1 dcn_expert_parallelism=1 ici_data_parallelism=1 ici_fsdp_parallelism=1 ici_fsdp_transpose_parallelism=1 ici_sequence_parallelism=1 ici_tensor_parallelism=1 ici_tensor_sequence_parallelism=1 ici_autoregressive_parallelism=1 ici_pipeline_parallelism=1 ici_expert_parallelism=4'
export BASE_RESULT_DIR=/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/results/infer-deepseek4-flash-284b-bf16-1n4g_93b9701a0cdb
export BASE_XLA_FLAGS='--xla_gpu_enable_command_buffer=FUSION,CUBLAS,CUDNN,COLLECTIVES,CUSTOM_CALL,CUBLASLT,DYNAMIC_SLICE_FUSION,CONVOLUTION,HOST_EXECUTE,COLLECTIVES_KERNEL --xla_gpu_command_buffer_unroll_loops=false --xla_gpu_enable_cudnn_fmha=1 --xla_gpu_require_exclusive_lock=0 --xla_gpu_enable_latency_hiding_scheduler=1 --xla_gpu_command_buffer_scheduling_mode=LHS --xla_disable_hlo_passes=rematerialization'
export BINDPCIE=0
export BUILD_JAX=0
export CLUSTER=dlcluster
export CONTAINER=gitlab-master.nvidia.com:5005/dl/dgx/jax:maxtext-2026-10-12
export CUDA_SCALE_LAUNCH_QUEUES=1x
export CUSTOM_MOUNTS=/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/skill/assets/jax-run-scripts/inference_aot_runner.py:/tmp/jax-workloads/inference_aot_runner.py:ro,/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/run_preflight.py:/tmp/run_preflight.py:ro,/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/wheels:/tmp/workload-wheels:ro,/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/stable_inference.py:/tmp/stable_inference.py:ro
export DLCLUSTER_STEP_NAME=deepseek4-cb-modes
export ENABLE_CMD_BUFFER_DUMPS=0
export ENABLE_NCCL_DEBUG=0
export ENABLE_PGLE=0
export ENABLE_VALGRIND_DEBUG=0
export ENABLE_XLA_DUMPS=0
export GDB=0
export GPUS_PER_NODE=4
export INFERENCE_AOT_MODE=consistent
export MAXTEXT_CONFIG_PATH=/opt/maxtext/src/maxtext/configs/base.yml
export MAXTEXT_IMPL=container
export MAXTEXT_RUNNER=inference
export NCCL_DEBUG=VERSION
export NCCL_GRAPH_MIXING_SUPPORT=1
export NODES=1
export NVTE_FUSED_ATTN=1
export PREC=bfloat16
export PROFILE=''
export PYTHONUNBUFFERED=1
export RUN=maxText
export STEPS=1
export TF_CPP_MAX_LOG_LEVEL=300
export TF_CPP_MIN_LOG_LEVEL=0
export TF_CPP_VMODULE=''
export TF_FORCE_GPU_ALLOW_GROWTH=true
export XLA_PYTHON_CLIENT_ALLOCATOR=bfc
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.9
/usr/bin/python3 /home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/launch_existing.py /home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/results/infer-deepseek4-flash-284b-bf16-1n4g_93b9701a0cdb
