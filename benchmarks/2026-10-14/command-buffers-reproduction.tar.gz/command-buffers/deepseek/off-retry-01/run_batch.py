"""Supervise one OFF retry inside its own exclusive Slurm allocation."""
import datetime
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent
result = ROOT/'result'
result.mkdir(exist_ok=True)
(result/'logs').mkdir(exist_ok=True)
job = os.environ['SLURM_JOB_ID']
assert os.environ['SLURM_JOB_NODELIST'] == 'gb-nvl-053-compute09'
env = os.environ.copy()
env['ENROOT_CONFIG_PATH'] = str(ORIGINAL/'.enroot')
mounts = [f'{result}:/opt/workspace', f'{ROOT / "test.sh"}:/tmp/test.sh:ro',
          f'{ORIGINAL / "skill/assets/jax-run-scripts/bindpcie"}:/tmp/bindpcie:ro',
          f'{ROOT / "step_start.py"}:/tmp/step_start.py:ro',
          f'{ROOT / "mode_sweep.sh"}:/tmp/mode_sweep.sh:ro',
          f'{ROOT / "retry_observer.py"}:/tmp/retry_observer.py:ro', env['CUSTOM_MOUNTS']]
command = ['srun', '--nodes=1', '--ntasks=4', '--ntasks-per-node=4', '--cpus-per-task=16',
           '--cpu-bind=none', '--gres=gpu:GB200:4', '--kill-on-bad-exit=1',
           '--container-image='+('oauth2@'+env['CONTAINER']).replace('gitlab-master.nvidia.com:5005/', 'gitlab-master.nvidia.com:5005#'),
           '--container-mounts='+','.join(mounts), '--container-remap-root', '--container-writable',
           '--container-workdir=/opt/maxtext', '--export=ALL',
           '--output='+str(result/'logs/output-%j-%n-%t.txt'),
           '--error='+str(result/'logs/output-%j-%n-%t.txt'),
           'bash', '-e', '-c',
           'python3 /tmp/step_start.py; nvidia-smi; nvidia-smi topo -m; bash /tmp/mode_sweep.sh']
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
(result/'launch.json').write_text(json.dumps(dict(job_id=job, node=os.environ['SLURM_JOB_NODELIST'],
                                                  started_at=now(), command=command),indent=2)+'\n')
try:
    rc = subprocess.run(command, env=env, check=False).returncode
    status = dict(state='COMPLETED' if rc == 0 else 'FAILED', returncode=rc)
except Exception as exc:
    rc = 1
    status = dict(state='FAILED', returncode=rc, error=str(exc))
status.update(job_id=job, finished_at=now())
(result/'run_status.json').write_text(json.dumps(status,indent=2)+'\n')
raise SystemExit(rc)
