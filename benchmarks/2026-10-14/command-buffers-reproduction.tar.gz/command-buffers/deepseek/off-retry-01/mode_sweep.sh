#!/bin/bash
set -euo pipefail
original_flags=$BASE_XLA_FLAGS
for CB_MODE in OFF; do
  export CB_MODE
  export BASE_XLA_FLAGS=$original_flags
  export CB_OUTPUT_DIR=/opt/workspace/modes/$CB_MODE
  mkdir -p "$CB_OUTPUT_DIR"
  echo "MODE_START $CB_MODE rank=$SLURM_PROCID"
  bash /tmp/test.sh "$CB_OUTPUT_DIR/outputs" > >(tee "$CB_OUTPUT_DIR/rank-$SLURM_PROCID.log") 2>&1
  touch "$CB_OUTPUT_DIR/done-$SLURM_PROCID"
  deadline=$((SECONDS + 300))
  while [ "$(find "$CB_OUTPUT_DIR" -maxdepth 1 -name 'done-*' | wc -l)" -lt 4 ]; do
    if [ "$SECONDS" -gt "$deadline" ]; then
      echo "Mode completion barrier timed out: $CB_MODE" >&2
      exit 1
    fi
    sleep 2
  done
  echo "MODE_COMPLETED $CB_MODE rank=$SLURM_PROCID"
done
