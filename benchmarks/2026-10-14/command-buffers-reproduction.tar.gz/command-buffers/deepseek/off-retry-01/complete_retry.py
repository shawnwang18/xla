"""Validate the OFF retry, preserve original evidence, and update the HTML report."""
import argparse
import datetime
import hashlib
import html
import importlib.util
import json
from pathlib import Path
import re
import shutil
import statistics

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
MODES = ['OFF', 'ALWAYS_UPDATE', 'SKIP_TEMP', 'SKIP_PROFILED']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def table(headers, rows):
    def cells(tag, values):
        return ''.join(f'<{tag}>'+html.escape(str(v))+f'</{tag}>' for v in values)
    return '<table><thead><tr>'+cells('th', headers)+'</tr></thead><tbody>'+''.join(
        '<tr>'+cells('td', row)+'</tr>' for row in rows)+'</tbody></table>'


def finish(result_dir, scheduler_file):
    request = json.loads((ROOT/'request.json').read_text())
    job = request['job_id']
    scheduler = [line.split('|') for line in scheduler_file.read_text().splitlines() if line.strip()]
    relevant = [row for row in scheduler if row[0] == job or row[0].startswith(job+'.')]
    assert any(row[0] == job for row in relevant), 'Missing final parent scheduler record'
    assert len(relevant) >= 3, 'Collect parent and all steps before updating the report'
    assert all(len(row) >= 8 and row[2] == 'COMPLETED' and row[3] == '0:0' for row in relevant), relevant
    parent = next(row for row in relevant if row[0] == job)
    supervisor = json.loads((result_dir/'run_status.json').read_text())
    assert supervisor['state'] == 'COMPLETED' and supervisor['returncode'] == 0
    assert supervisor['job_id'] == job
    placement = json.loads((result_dir/'step.json').read_text())
    assert placement['SLURM_JOB_NODELIST'] == request['requested_node']
    assert len(placement['gpus']) == 4 and all('GB200' in g for g in placement['gpus'])

    receipt = ROOT/'completion-summary.json'
    if receipt.exists():
        previous = json.loads(receipt.read_text())
        assert previous['job_id'] == job
        if all(digest(BASE/'confluence'/name) == value for name,value in previous['updated_report_sha256'].items()):
            print('Retry already collected and report already updated:', receipt)
            return previous['collector_returncode']
        raise RuntimeError('Report changed after the previous update; reconcile manually')

    # Do not replace user edits that arrived while the job ran.
    for name, expected in request['report_initial_sha256'].items():
        assert digest(BASE/'confluence'/name) == expected, f'Report changed during retry: {name}'
    backup = ROOT/'report-before-retry'
    backup.mkdir(exist_ok=True)
    for name in request['report_initial_sha256']:
        destination = backup/name
        if not destination.exists():
            shutil.copy2(BASE/'confluence'/name, destination)

    merged = ROOT/'comparison-updated'
    (merged/'modes').mkdir(parents=True, exist_ok=True)
    sources = {}
    for mode in MODES:
        source = result_dir/'modes'/mode if mode == 'OFF' else BASE/'final-2497742.6/modes'/mode
        shutil.copytree(source, merged/'modes'/mode, dirs_exist_ok=True)
        sources[mode] = dict(job_id=job if mode == 'OFF' else '2497742.6', artifact_directory=str(source))
    (merged/'source-runs.json').write_text(json.dumps(sources,indent=2)+'\n')
    spec = importlib.util.spec_from_file_location('collect_stable', BASE/'collect_stable.py')
    collector = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(collector)
    rc = collector.collect(merged)
    comparison = json.loads((merged/'stable-comparison.json').read_text())
    assert all(row['status'] in {'stable','unstable'} for row in comparison['modes']), 'Missing or invalid measurements; report unchanged'
    by_mode = {row['mode']:row for row in comparison['modes']}
    off = by_mode['OFF']

    observations = []
    for rank in range(4):
        gc = json.loads((result_dir/f'modes/OFF/gc-rank{rank}.json').read_text())
        assert gc['policy_unchanged'] and gc['before']['enabled'] == gc['after']['enabled']
        assert gc['before']['thresholds'] == gc['after']['thresholds']
        measurements = [json.loads(line) for line in (result_dir/f'modes/OFF/samples-rank{rank}.jsonl').read_text().splitlines()]
        measured = [sample for sample in measurements if sample['stage'] == 'decode' and not sample['warmup']]
        median = statistics.median(sample['milliseconds'] for sample in measured)
        slow = [sample for sample in measured if sample['milliseconds'] > 2*median]
        for sample in slow:
            matching = [event for event in gc['events'] if event['stage'] == 'decode' and event['step'] == sample['step']]
            observations.append(dict(rank=rank, step=sample['step'], step_ms=sample['milliseconds'],
                                     observed_gc_ms=sum(event['duration_ms'] for event in matching), gc_events=matching))
    (merged/'gc-stall-correlation.json').write_text(json.dumps(observations,indent=2)+'\n')

    original_storage = (BASE/'confluence/page-storage.html').read_text()
    blocks = re.findall(r'<table>.*?</table>', original_storage, re.S)
    assert len(blocks) == 4
    rows = []
    for mode in MODES:
        row = by_mode[mode]
        p, d = row['stages']['prefill'], row['stages']['decode']
        def number(values, key, suffix=''):
            return f"{values[key]:.3f}{suffix}" if values['stable'] and key in values else '—'
        rows.append([mode, number(p,'mean_ms'), number(d,'mean_ms') if d['stable'] else 'Unstable — excluded',
                     number(d,'tokens_per_second'), number(d,'speedup_vs_OFF','×'), number(d,'speedup_vs_ALWAYS_UPDATE','×')])
    results_table = table(['Mode','Prefill latency (ms)','Decode latency (ms)','Decode throughput (tokens/s)',
                           'Decode speedup vs OFF','Decode speedup vs ALWAYS_UPDATE'], rows)
    rows = []
    for mode in MODES:
        for stage in ['prefill','decode']:
            value = by_mode[mode]['stages'][stage]
            rows.append([mode,stage,f"{value['cv_percent']:.3f}",f"{value['half_mean_drift_percent']:.3f}",
                         'Pass' if value['stable'] else 'Fail'])
    stability_table = table(['Mode','Stage','Variation / CV (%)','Half-window drift (%)','Stability'], rows)
    body = original_storage.replace(blocks[0], results_table, 1).replace(blocks[1], stability_table, 1)
    accepted = [row for row in comparison['modes'] if row['stages']['decode']['stable']]
    winner = max(accepted, key=lambda row: row['stages']['decode']['tokens_per_second'])
    lead = ('<p><strong>'+winner['mode']+' had the highest accepted decode throughput in the updated comparison.</strong> '
            f'OFF was rerun as job {job} on the same four GB200 GPUs with the same model, image, benchmark source, '
            'and steps 101–300. The table uses this retry for OFF and retains the other three modes from step 2497742.6. '
            +('All selected prefill and decode windows passed the predefined stability checks.' if rc == 0 else
              'The retry still has a window that fails stability checks; rejected measurements are excluded from speedups.')+'</p>')
    body, count = re.subn(r'(<h1>.*?</h1>\s*)<p>.*?</p>', lambda m:m.group(1)+lead, body, count=1, flags=re.S)
    assert count == 1
    old_interpretation = '<p>SKIP_TEMP delivered 5.5% lower decode throughput than ALWAYS_UPDATE. OFF decode cannot be ranked reliably from this run. This is one sequential sweep; no across-run confidence interval was measured.</p>'
    new_interpretation = '<p>SKIP_PROFILED delivers 12.9% higher and SKIP_TEMP 5.5% lower decode throughput than ALWAYS_UPDATE. OFF is a separate retry on the same node; the other modes are unchanged original measurements. No across-run confidence interval was measured.</p>'
    assert old_interpretation in body
    body = body.replace(old_interpretation,new_interpretation,1)
    body = body.replace('<h2>Stability checks and OFF decode caveat</h2>','<h2>Stability checks and OFF retry</h2>',1)
    explanation = ('<p>The original OFF decode window in step 2497742.6 failed stability checks: '
                   'CV 59.628%, half-window drift 14.309%, with stalls at steps 116, 196, and 200 '
                   '(708.328, 760.503, and 738.061 ms). That original window remains archived and is not used in this updated comparison. '
                   f'The OFF retry in job {job} has decode CV {off["stages"]["decode"]["cv_percent"]:.3f}% and '
                   f'half-window drift {off["stages"]["decode"]["half_mean_drift_percent"]:.3f}%. '
                   +('It passed the same thresholds without dropping any samples.' if off['stages']['decode']['stable'] else
                     'It also failed the predefined thresholds, so OFF decode remains excluded from speedup comparisons.')+
                   '</p><p>The retry recorded Python garbage-collection events without forcing or disabling collection. '
                   f'{len(observations)} rank/step observations exceeded twice that rank’s measured decode median; '
                   'the per-rank GC logs and correlation file retain the diagnostic evidence. Coincidence alone does not establish causation.</p>')
    body, count = re.subn(r'<p>OFF decode contained synchronized stalls.*?</p>',lambda m:explanation,body,count=1,flags=re.S)
    assert count == 1
    retry_details = (f'<p><strong>OFF retry:</strong> Slurm job {job}, COMPLETED, exit 0:0; supervisor return code 0. '
                     f'Scheduler interval {html.escape(parent[5])}–{html.escape(parent[6])} UTC; elapsed {html.escape(parent[4])}. '
                     'The original interactive allocation expired naturally before this retry; the retry used a dedicated exclusive batch allocation on the same node.</p>')
    body = body.replace('<h2>Command buffers and compatibility</h2>',retry_details+'\n<h2>Command buffers and compatibility</h2>',1)
    body = body.replace('OFF → ALWAYS_UPDATE → SKIP_TEMP → SKIP_PROFILED on the same GPUs',
                        'Original sweep: OFF → ALWAYS_UPDATE → SKIP_TEMP → SKIP_PROFILED. Later: OFF-only retry on the same node.',1)
    body += ('<h2>OFF retry artifacts</h2><p>The original 9,600 raw samples are preserved. The retry adds '
             '2,400 raw samples (4 ranks × 2 stages × 300 calls). The updated comparison selects the retry OFF samples '
             'and the unchanged original samples for the other modes.</p><pre>'+html.escape(str(result_dir))+'</pre>'
             '<p>Updated comparison and source-run mapping:</p><pre>'+html.escape(str(merged))+'</pre>'
             '<p>Prior HTML report retained at:</p><pre>'+html.escape(str(backup))+'</pre>\n')
    html_path = BASE/'confluence/deepseek4-command-buffer-comparison.html'
    document = html_path.read_text()
    document, count = re.subn(r'(<body>).*?(</body>)',lambda m:m.group(1)+body+m.group(2),document,count=1,flags=re.S)
    assert count == 1
    for path, text in [(BASE/'confluence/page-storage.html',body),(html_path,document)]:
        temporary = path.with_suffix('.update.tmp')
        temporary.write_text(text)
        temporary.replace(path)
    (merged/'report-storage.html').write_text(body)
    summary = dict(job_id=job, completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   scheduler=relevant, supervisor=supervisor, collector_returncode=rc,
                   selected_sources=sources, off_stable=off['status']=='stable',
                   off_retry_statistics=off, gc_stall_observations=observations,
                   updated_report_sha256={name:digest(BASE/'confluence'/name) for name in request['report_initial_sha256']},
                   report_backup=str(backup), comparison_directory=str(merged))
    receipt.write_text(json.dumps(summary,indent=2)+'\n')
    publication = BASE/'confluence/publication-draft.json'
    state = json.loads(publication.read_text())
    state.update(results_updated_at=summary['completed_at'], off_retry_job_id=job,
                 off_retry_stable=summary['off_stable'], confluence_page_created=False)
    publication.write_text(json.dumps(state,indent=2)+'\n')
    print('Updated existing HTML report:', html_path)
    print('Original report preserved:', backup)
    return rc


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result-dir', required=True, type=Path)
    parser.add_argument('--scheduler-file', required=True, type=Path,
                        help='sacct -n -P -o JobIDRaw,JobName,State,ExitCode,Elapsed,Start,End,NodeList')
    args = parser.parse_args()
    raise SystemExit(finish(args.result_dir,args.scheduler_file))
