"""Validate exact per-mode/per-rank samples and compare fixed steady windows."""
import argparse
import json
import math
from pathlib import Path
import statistics

MODES = ['OFF', 'ALWAYS_UPDATE', 'SKIP_TEMP', 'SKIP_PROFILED']


def stats(values):
    mean = statistics.mean(values)
    drift = abs(statistics.mean(values[:100])-statistics.mean(values[100:]))/mean*100
    cv = statistics.pstdev(values)/mean*100
    return dict(mean_ms=mean, median_ms=statistics.median(values),
                p95_ms=sorted(values)[189], half_mean_drift_percent=drift,
                cv_percent=cv, stable=drift <= 5 and cv <= 10)


def collect(root):
    rows = []
    provenance = None
    for mode in MODES:
        directory = root / 'modes' / mode
        row = dict(mode=mode, status='unavailable', stages={})
        rows.append(row)
        try:
            reports = [json.loads((directory/f'stable-rank{rank}.json').read_text()) for rank in range(4)]
            assert all((directory/f'done-{rank}').is_file() for rank in range(4)), 'Mode lacks four successful rank exit markers'
            for rank, report in enumerate(reports):
                assert report['status'] == 'completed', report['status']
                assert report['mode'] == mode and report['rank'] == rank
                assert report['decoder_layers'] == 43 and report['experts'] == 256, 'Not the full model'
                assert report['global_batch'] == 4
                assert report['decode_input_output_formats_equal']
                assert report['finite_final_local_logits']
                assert report['warmup_steps'] == 100 and report['measurement_steps'] == 200
            p = json.loads((directory/'container_provenance.json').read_text())
            assert p['mode'] == mode
            commands = p['command_buffer_commands']
            assert not {'WHILE','CONDITIONAL'} & set(commands)
            if mode == 'OFF':
                assert commands == []
            else:
                assert set(commands) == {'FUSION','CUBLAS','CUDNN','COLLECTIVES','CUSTOM_CALL','CUBLASLT',
                                         'DYNAMIC_SLICE_FUSION','CONVOLUTION','HOST_EXECUTE','COLLECTIVES_KERNEL'}
            identity = (p['revisions'], p['versions'], reports[0]['model_params'],
                        reports[0]['true_prompt_tokens'], reports[0]['stable_runner_sha256'])
            if provenance is None:
                provenance = identity
            assert identity == provenance, 'Image/model/prompt/runner changed between modes'
            ranks = []
            for rank in range(4):
                samples = [json.loads(line) for line in (directory/f'samples-rank{rank}.jsonl').read_text().splitlines()]
                stages = {}
                for stage in ['prefill', 'decode']:
                    points = [s for s in samples if s['stage'] == stage]
                    assert [s['step'] for s in points] == list(range(1,301)), f'Incomplete or duplicate {stage} samples'
                    assert all(math.isfinite(s['milliseconds']) and s['milliseconds'] > 0 for s in points)
                    assert all(s['warmup'] == (s['step'] <= 100) for s in points)
                    stages[stage] = [s['milliseconds'] for s in points[100:]]
                ranks.append(stages)
            for stage in ['prefill', 'decode']:
                # All ranks execute the same recurrent steps. Use the slowest
                # rank at each step, and preserve rank-specific stability too.
                values = [max(r[stage][step] for r in ranks) for step in range(200)]
                result = stats(values)
                result['rank_statistics'] = [stats(r[stage]) for r in ranks]
                result['stable'] &= all(s['stable'] for s in result['rank_statistics'])
                result['global_step_ms'] = values
                if stage == 'decode':
                    result['tokens_per_second'] = 4000/result['mean_ms']
                row['stages'][stage] = result
            row['status'] = 'stable' if all(s['stable'] for s in row['stages'].values()) else 'unstable'
            row['model_params'] = reports[0]['model_params']
            row['true_prompt_tokens'] = reports[0]['true_prompt_tokens']
            benchmark = {'prefill': {'4096': {'time_in_ms': row['stages']['prefill']['mean_ms']}},
                         'autoregressive': {'step_in_ms': row['stages']['decode']['mean_ms'],
                                            'global_batch_size': 4,
                                            'total_throughput_tokens_per_second': row['stages']['decode']['tokens_per_second']},
                         'method': 'mean of per-step maximum rank latency; synchronized calls; steps 101-300',
                         'stability_status': row['status']}
            (directory/'benchmark.json').write_text(json.dumps(benchmark,indent=2)+'\n')
        except (OSError, ValueError, KeyError, AssertionError) as exc:
            row['status'] = 'invalid_or_incomplete'
            row['detail'] = str(exc)
    by_mode = {r['mode']:r for r in rows}
    for row in rows:
        for baseline in ['OFF','ALWAYS_UPDATE']:
            base = by_mode[baseline]
            for stage, result in row['stages'].items():
                if result['stable'] and base.get('stages',{}).get(stage,{}).get('stable'):
                    result['speedup_vs_'+baseline] = base['stages'][stage]['mean_ms']/result['mean_ms']
    result = dict(measured_steps=[101,300], warmup_steps=100,
                  stable_criteria={'half_mean_drift_percent_max':5,'step_cv_percent_max':10},
                  rank_aggregation='maximum synchronized call latency across four ranks at each step',
                  modes=rows)
    (root/'stable-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    table = [['Mode','Prefill status','Prefill (ms)','Decode status','Decode (ms)','Decode (tokens/s)','Decode vs OFF','Decode vs ALWAYS_UPDATE']]
    for row in rows:
        p, d = row['stages'].get('prefill',{}), row['stages'].get('decode',{})
        def fmt(values,key,suffix=''):
            return f"{values[key]:.3f}{suffix}" if key in values and values.get('stable') else '—'
        def status(values):
            return ('stable' if values['stable'] else 'unstable') if values else 'unavailable'
        table.append([row['mode'],status(p),fmt(p,'mean_ms'),status(d),fmt(d,'mean_ms'),fmt(d,'tokens_per_second'),
                      fmt(d,'speedup_vs_OFF','×'),fmt(d,'speedup_vs_ALWAYS_UPDATE','×')])
    widths = [max(len(row[i]) for row in table) for i in range(len(table[0]))]
    def line(row):
        return '| '+' | '.join(cell.ljust(w) for cell,w in zip(row,widths))+' |'
    markdown = '\n'.join([line(table[0]),line(['-'*w for w in widths]),*[line(row) for row in table[1:]]])+'\n'
    (root/'comparison.md').write_text(markdown)
    print(markdown)
    return 0 if all(r['status']=='stable' for r in rows) else 1


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('result_dir',type=Path)
    raise SystemExit(collect(parser.parse_args().result_dir))
