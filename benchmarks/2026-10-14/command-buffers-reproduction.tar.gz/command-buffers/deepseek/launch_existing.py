"""Launch and supervise one benchmark step inside an existing allocation."""
from pathlib import Path
import datetime
import fcntl
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
ALLOCATION = "2497742"
NODE = "gb-nvl-053-compute09"
STEP_NAME = os.environ.get("DLCLUSTER_STEP_NAME", "deepseek4-cb-modes-20261013")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, indent=2) + "\n")
    tmp.replace(path)


def find_step():
    proc = subprocess.run(
        ["sacct", "-j", ALLOCATION, "--noheader", "--parsable2",
         "--format=JobIDRaw,JobName%100,State,ExitCode,NodeList"],
        capture_output=True, text=True, timeout=15,
    )
    matches = [line.split("|")[0] for line in proc.stdout.splitlines()
               if len(line.split("|")) >= 5 and line.split("|")[1] == STEP_NAME]
    if len(matches) > 1:
        raise RuntimeError("Multiple benchmark steps found; reconcile before continuing")
    return matches[0] if matches else None


def supervise(result):
    env = os.environ.copy()
    env["ENROOT_CONFIG_PATH"] = str(ROOT / ".enroot")
    mounts = [f"{result}:/opt/workspace",
              f"{ROOT / 'skill/assets/jax-run-scripts/test.sh'}:/tmp/test.sh:ro",
              f"{ROOT / 'skill/assets/jax-run-scripts/bindpcie'}:/tmp/bindpcie:ro",
              f"{ROOT / 'step_start.py'}:/tmp/step_start.py:ro",
              f"{ROOT / 'mode_sweep.sh'}:/tmp/mode_sweep.sh:ro",
              env["CUSTOM_MOUNTS"]]
    logs = result / "logs"
    logs.mkdir(exist_ok=True)
    command = [
        "srun", "--jobid=" + ALLOCATION, "--overlap", "--nodes=1",
        "--ntasks=4", "--ntasks-per-node=4", "--cpus-per-task=16",
        "--cpu-bind=none", "--gres=gpu:GB200:4", "--time=04:00:00",
        "--job-name=" + STEP_NAME, "--kill-on-bad-exit=1",
        "--container-image=" + ("oauth2@" + env["CONTAINER"]).replace("gitlab-master.nvidia.com:5005/", "gitlab-master.nvidia.com:5005#"),
        "--container-mounts=" + ",".join(mounts),
        "--container-remap-root", "--container-writable",
        "--container-workdir=/opt/maxtext", "--export=ALL",
        "--output=" + str(logs / "output-%j-%n-%t.txt"),
        "--error=" + str(logs / "output-%j-%n-%t.txt"),
        "bash", "-e", "-c",
        "python3 /tmp/step_start.py; nvidia-smi; nvidia-smi topo -m; "
        "bash /tmp/mode_sweep.sh",
    ]
    save(result / "step_launch.json", {"allocation_id": ALLOCATION, "node": NODE,
         "step_name": STEP_NAME, "command": command, "started_at": now(),
         "supervisor_pid": os.getpid()})
    try:
        proc = subprocess.run(command, env=env, check=False)
        code = proc.returncode
        record = {"state": "COMPLETED" if code == 0 else "FAILED", "returncode": code}
    except Exception as exc:
        record = {"state": "FAILED", "returncode": 1, "error": str(exc)}
    record.update(finished_at=now(), allocation_id=ALLOCATION)
    try:
        record["step_id"] = find_step()
    except Exception as exc:
        record["accounting_error"] = str(exc)
    save(result / "run_status.json", record)
    return record["returncode"]


def submit(result):
    result.mkdir(parents=True, exist_ok=True)
    lock = (result / ".submission.lock").open("w")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    receipt = result / "submission.json"
    if receipt.exists():
        record = json.loads(receipt.read_text())
        print(record.get("step_id") or ALLOCATION)
        return 0
    state = subprocess.run(["squeue", "-h", "-j", ALLOCATION, "-o", "%T|%N|%u"],
                           capture_output=True, text=True, check=True, timeout=15).stdout.strip()
    if state != f"RUNNING|{NODE}|shawnw":
        raise RuntimeError("Allocation changed; reconcile before launch: " + state)
    active = subprocess.run(['squeue', '--steps', '-h', '-j', ALLOCATION, '-o', '%i|%j'],
                            capture_output=True, text=True, check=True, timeout=15).stdout.splitlines()
    unexpected = [line for line in active if line.split('|')[0].strip() not in {ALLOCATION+'.0', ALLOCATION+'.extern'}]
    if unexpected:
        raise RuntimeError('Allocation already has active workload steps: '+str(unexpected))
    if find_step():
        raise RuntimeError("A benchmark step already exists; reconcile before launching")
    save(receipt, {"allocation_id": ALLOCATION, "state": "launch_started", "time": now()})
    with (result / "launcher.log").open("a") as log:
        proc = subprocess.Popen([sys.executable, str(Path(__file__).resolve()),
                                 "--supervise", str(result)], stdin=subprocess.DEVNULL,
                                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    record = {"allocation_id": ALLOCATION, "supervisor_pid": proc.pid,
              "state": "supervisor_started", "time": now()}
    save(receipt, record)
    for _ in range(10):
        step = find_step()
        if step:
            record["step_id"] = step
            save(receipt, record)
            print(step)
            return 0
        if (result / "run_status.json").exists():
            print((result / "run_status.json").read_text(), file=sys.stderr)
            return 1
        time.sleep(1)
    # Accounting lag does not authorize another submission.
    print(ALLOCATION)
    return 0


if __name__ == "__main__":
    if sys.argv[1] == "--supervise":
        raise SystemExit(supervise(Path(sys.argv[2])))
    raise SystemExit(submit(Path(sys.argv[1])))
