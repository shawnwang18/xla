"""Run the bundled BF16 model on one dlcluster four-GB200 node."""
from pathlib import Path
import copy
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "skill/scripts"))
import jax_workloads as api

api.CLUSTER_DEFAULTS["dlcluster"] = {"partition": "gb200nvl72_preprod", "tpn": 4}
cfg = api.load_config_module(api.BUNDLED_REPO, api.DEFAULT_MODULE)
name = "infer-deepseek4-flash-284b-bf16-4n4g"
row = copy.deepcopy(next(r for r in cfg.CONFIGS["inference"]["param_dicts"]
                         if r["cluster"] == "ptyche" and r["model"] == name))
assert row["inference_aot_mode"] == "consistent"
row.update(cluster="dlcluster", partition="gb200nvl72_preprod", account="blackwell", nodes=1, segment=1, ici_expert=4, dcn_expert=1, validation="unqualified")
row["model"] = "infer-deepseek4-flash-284b-bf16-1n4g"
cfg.MAXTEXT_WORKLOAD_CONFIG[row["model"]] = copy.deepcopy(cfg.MAXTEXT_WORKLOAD_CONFIG[name])
row["workload_aliases"] = ["infer-deepseek4-flash-284b-bf16-2n8g", name]
row["custom_mounts"] = (f"{ROOT / 'run_preflight.py'}:/tmp/run_preflight.py:ro,"
                        f"{ROOT / 'wheels'}:/tmp/workload-wheels:ro,"
                        f"{ROOT / 'stable_inference.py'}:/tmp/stable_inference.py:ro")
row["env_vars"]["PYTHONUNBUFFERED"] = "1"
row["env_vars"]["DLCLUSTER_STEP_NAME"] = "deepseek4-cb-modes"
row["framework_source_patches"] = []
row["runtime_dependency_overrides"] = "typeguard==2.13.3"
row["_notes"].append("dlcluster GB200: 1 node x 4 GB200 GPUs; expert parallelism 4; total decode batch 4.")
cfg.CONFIGS["inference"]["param_dicts"].append(row)

# run_preflight.py refreshes this list from the selected container's enum.
commands = "FUSION,CUBLAS,CUDNN,COLLECTIVES,CUSTOM_CALL,CUBLASLT,DYNAMIC_SLICE_FUSION,CONVOLUTION,HOST_EXECUTE,COLLECTIVES_KERNEL"
api.CUDA_GRAPH_CONFIGS["AllExceptWhileConditional"] = (commands, "LHS", False, "AllExceptWhileConditional")
def slurm_command(repo, job, result_dir):
    return [sys.executable, str(ROOT / "launch_existing.py"), str(result_dir)]


api.slurm_command = slurm_command

if __name__ == "__main__":
    raise SystemExit(api.main())
