# coding=utf-8
# Copyright 2022 The Pax Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#! /bin/bash
# Assumes you are using a SLURM cluster. Edit flags under --multiprocess_gpu below to suit your setup
set -euo pipefail
set -x

OUTPUT_DIR=${1:-"test_logdir"}

# Add default values for environment variables
export SLURM_PROCID=${SLURM_PROCID:-0}
export SLURM_NODEID=${SLURM_NODEID:-0}
export SLURM_LOCALID=${SLURM_LOCALID:-0}
export SLURM_JOB_NUM_NODES=${SLURM_JOB_NUM_NODES:-0}
export SLURM_JOB_ID=${SLURM_JOB_ID:-0}
export SLURM_NTASKS=${SLURM_NTASKS:-0}
export SLURM_NTASKS_PER_NODE=${SLURM_NTASKS_PER_NODE:-1}
export LOCAL_RUN=${LOCAL_RUN:-0}
export DEBUG=1

export NSYS_CONFIG_DIRECTIVES='OsrtBacktraceOfflineUnwinding=false'
export XLA_PYTHON_CLIENT_MEM_FRACTION=${XLA_PYTHON_CLIENT_MEM_FRACTION:-0.85}

PAXML_DIR=${PAXML_DIR:-/opt/paxml}
GROK_DIR=${GROK_DIR:-/opt/mini-grok-train}
SAXML_DIR=${SAXML_DIR:-/opt/saxml-gptmoe-int-4}
MAXTEXT_DIR=${MAXTEXT_DIR:-/opt/maxtext}
ENABLE_TE=${ENABLE_TE:-1}
ENABLE_FP8=${ENABLE_FP8:-0}
XLA_FLAGS=${XLA_FLAGS:-""}

export NNODES=${SLURM_NTASKS}
export NODE_RANK=${SLURM_PROCID}

if [ "${SLURM_PROCID}" -eq 0 ]; then
    mkdir -p ${OUTPUT_DIR}
    mkdir -p ${OUTPUT_DIR}/nccl_debug
    mkdir -p ${OUTPUT_DIR}/xla_dumps
    mkdir -p ${OUTPUT_DIR}/nsys_dump
    mkdir -p ${OUTPUT_DIR}/valgrind_debug
    mkdir -p ${OUTPUT_DIR}/compute_sanitizer
    mkdir -p ${OUTPUT_DIR}/cuda_err
    mkdir -p ${OUTPUT_DIR}/gdb
fi

# Global synchronization barrier function using shared filesystem
# Usage: global_barrier <barrier_name>
global_barrier() {
    local BARRIER_NAME=${1:-"default"}
    local BARRIER_DIR=${OUTPUT_DIR}/.barrier_${SLURM_JOB_ID}_${BARRIER_NAME}
    mkdir -p ${BARRIER_DIR}

    # Each process signals it has reached the barrier
    touch ${BARRIER_DIR}/rank_${SLURM_PROCID}

    # Wait for all ranks to arrive
    local EXPECTED_RANKS=${SLURM_NTASKS}
    local TIMEOUT=300
    local ELAPSED=0
    while [ $(ls ${BARRIER_DIR}/rank_* 2>/dev/null | wc -l) -lt ${EXPECTED_RANKS} ]; do
        sleep 1
        ELAPSED=$((ELAPSED + 1))
        if [ "$ELAPSED" -ge "$TIMEOUT" ]; then
            echo "RANK ${SLURM_PROCID}: Barrier '${BARRIER_NAME}' timeout after ${TIMEOUT}s"
            exit 1
        fi
    done

    # Cleanup (only rank 0, after a small delay to ensure others passed)
    if [ "${SLURM_PROCID}" -eq 0 ]; then
        sleep 2
        rm -rf ${BARRIER_DIR}
    fi

    echo "RANK ${SLURM_PROCID}: Passed global barrier '${BARRIER_NAME}'"
}

if [ "${SLURM_LOCALID}" -eq 0 ] && [ "${BUILD_JAX:-0}" -eq 1 ]; then
    /usr/local/bin/build-jax.sh
fi

if [ "${SLURM_LOCALID}" -eq 0 ]; then
  if [ "${GDB}" = "1" ] || [ "${GDB}" = "2" ] || [ "${GDB}" = "5" ]; then
    apt-get update && apt-get install -y gdb
  fi
fi

if [ -e /opt/nsight-systems/bin/nsys ] && [ "${SLURM_LOCALID}" -eq 0 ]; then
    rm -f /usr/local/bin/nsys
    ln -s /opt/nsight-systems/bin/nsys /usr/local/bin/nsys
    ls -lh /usr/local/bin/nsys
fi

if [ "${SLURM_LOCALID}" -eq 0 ]; then
    python3 -m pip install --no-deps --no-index --find-links=/tmp/workload-wheels typeguard==2.13.3
fi
global_barrier "init"
BASE_XLA_FLAGS="$(python3 /tmp/run_preflight.py)"
export BASE_XLA_FLAGS

XLA_DUMP_FLAGS=" "
if [[ $SLURM_PROCID -eq 0 && ${ENABLE_XLA_DUMPS:-} == "1" ]]; then
    XLA_DUMP_FLAGS=" --xla_dump_to=${OUTPUT_DIR}/xla_dumps/${SLURM_JOB_NUM_NODES}_hostid${SLURM_NODEID}_procid${SLURM_PROCID} "
fi

if [[ $SLURM_PROCID -eq 0 && ${ENABLE_CMD_BUFFER_DUMPS:-} == "1" ]]; then
  export TF_CPP_MIN_LOG_LEVEL=0
  export TF_CPP_MAX_LOG_LEVEL=10
  export TF_CPP_VMODULE=gpu_command_buffer=9
fi

if [ "${ENABLE_NCCL_DEBUG}" = "1" ]; then
    export NCCL_DEBUG_FILE=${OUTPUT_DIR}/nccl_debug/nccl_debug_${SLURM_JOB_NUM_NODES}_hostid${SLURM_NODEID}_procid${SLURM_PROCID}.log
    export NCCL_DEBUG=INFO
    export NCCL_DEBUG_SUBSYS=ALL
    echo "NCCL_DEBUG_FILE:"${NCCL_DEBUG_FILE}
fi

NSYS=""
echo "PROFILE: "${PROFILE:-""}
if [[ $SLURM_PROCID -eq 0 && ${PROFILE:-} == "nsys" ]]; then
    echo "nsys version: "
    nsys --version
    NSYS="nsys profile --cpuctxsw=system-wide  --stats=true -o ${OUTPUT_DIR}/nsys_dump/nsys_n${SLURM_JOB_NUM_NODES}_job${SLURM_JOB_ID}_${CLUSTER:-""} \
          --force-overwrite true --cuda-graph-trace=graph --capture-range=cudaProfilerApi --capture-range-end=stop"
    echo "NSYS cmd: " ${NSYS}
fi

NSYS_PGLE=""
echo "ENABLE_PGLE: "${ENABLE_PGLE}
NSYS_PGLE_FILE=${OUTPUT_DIR}/nsys_dump/nsys_pgle_${CLUSTER:-""}
if [[ $SLURM_PROCID -eq 0 && ${PROFILE:-} == "nsys" ]]; then
    echo "nsys version: "
    nsys --version
    NSYS_PGLE="nsys profile --cpuctxsw=system-wide --stats=true -o ${NSYS_PGLE_FILE} \
          --force-overwrite true --cuda-graph-trace=graph --capture-range=cudaProfilerApi --capture-range-end=stop"
    echo "NSYS_PGLE cmd: " ${NSYS_PGLE}
fi

VALGRIND=""
if [ "${ENABLE_VALGRIND_DEBUG}" = "1" ]; then
    VALGRIND="valgrind --log-file=${OUTPUT_DIR}/valgrind_debug/valgrind_${SLURM_JOB_NUM_NODES}_hostid${SLURM_NODEID}_procid${SLURM_PROCID}.log "
fi

COMPUTE_SANITIZER=""
if [ "$SLURM_NODEID" -eq 0 ] && [ "$SLURM_PROCID" -eq 0 ] && [ "${ENABLE_COMPUTE_SANITIZER:-0}" = "1" ]; then
    COMPUTE_SANITIZER="compute-sanitizer --tool=memcheck --log-file=${OUTPUT_DIR}/compute_sanitizer/compute_sanitizer_${SLURM_JOB_NUM_NODES:-}_hostid${SLURM_NODEID:-}_procid${SLURM_PROCID:-}.log "
fi

export LD_LIBRARY_PATH=/usr/local/cuda/compat:$LD_LIBRARY_PATH
export CUDA_FILE_LEVEL=30
export CUDA_ERROR_FILE=${OUTPUT_DIR}/cuda_err/cuda.err-${SLURM_JOB_NUM_NODES}_hostid${SLURM_NODEID}_procid${SLURM_PROCID}.log

GDB_CMD=""
if [[ "${GDB}" = "1" ]]; then
    cat >${OUTPUT_DIR}/gdb/gdb_launch_${SLURM_PROCID}.txt <<EOL
        set logging file ${OUTPUT_DIR}/gdb/gdb_hang_debug_pid${SLURM_PROCID}.txt
        set logging on
        run
        where
        info thread
        thread apply all bt
        set logging off
EOL

    GDB_CMD="gdb -x ${OUTPUT_DIR}/gdb/gdb_launch_${SLURM_PROCID}.txt --args "
fi

if [[ "${GDB}" = "3" ]]; then
    cat >${OUTPUT_DIR}/gdb/gdb_launch_${SLURM_PROCID}.txt <<EOL
        set debug cuda trace all
        set logging file ${OUTPUT_DIR}/gdb/gdb_hang_debug_pid${SLURM_PROCID}.txt
        set logging on
        run
        info thread
        thread apply all bt
        set logging off
EOL

    GDB_CMD="cuda-gdb -x ${OUTPUT_DIR}/gdb/gdb_launch_${SLURM_PROCID}.txt --args "
fi

#export CUDA_ENABLE_TMEM_LEAK_DETECTION=1
cat >~/.cuda-gdbinit <<EOL
    set debug cuda trace all
EOL

BIND_CMD=""
if [ "${BINDPCIE}" = "1" ]; then
    BIND_CMD="./bindpcie "
fi

echo "===============================ENV========================================"
env | awk '
    BEGIN { IGNORECASE=1 }
    !/(^|_)(TOKEN|PASSWORD|SECRET|CREDENTIALS?)=/ &&
    !/(glpat-|ghp_|nvapi-)/
'
echo "=========================================================================="

if [ "$RUN" = "paxml" ]; then
    export TFDS_DATA_DIR=/opt/dataset
    export VOCAB_PATH=/opt/paxml/vocab
    TEST_CMD="python3 -u -m paxml.main \
            --job_log_dir=$OUTPUT_DIR \
            --tfds_data_dir=/opt/dataset \
            --fdl_config=paxml.contrib.gpu.scripts_gpu.configs.${MODEL} \
            --fdl.FPROP_DTYPE=\"${PREC}\" \
            --num_hosts=$SLURM_NTASKS \
            --host_idx=$SLURM_PROCID \
            --fdl.EVAL_INTERVAL_STEPS=0 \
            --fdl.PROFILER_NUM_STEPS=5 \
            --fdl.PROFILER_CAPTURE_STEP=30 \
            --enable_checkpoint_saving=False \
            --enable_summary_writer=True \
            --fdl.ICI_MESH_SHAPE=[${ICI_R},${ICI_D},${ICI_M}] \
            --fdl.DCN_MESH_SHAPE=[${DCN_R},${DCN_D},${DCN_M}] \
            ${CUSTOM_MAIN_PARAMS:-} \
            --alsologtostderr "
elif [ "$RUN" = "grok" ]; then
    TEST_CMD="python3 /usr/local/bin/xtrain2 run \
            --driver local pp_bench.${MODEL} \
            fp8_gemm=${ENABLE_FP8} \
            enable_profiling=True \
            ep=${EP} \
            fsdp=${FSDP} \
            dp=${DP} \
            tp=${TP} \
            num_devices_per_process=1 \
            num_layers=${LAYERS} \
            ${CUSTOM_MAIN_PARAMS:-} \
            use_triton=${TRITON}"
elif [ "$RUN" = "maxText" ]; then
    export PYTHONPATH=${MAXTEXT_DIR}
    MAXTEXT_RUNNER=${MAXTEXT_RUNNER:-train}
    if [ "${MAXTEXT_RUNNER}" = "inference" ]; then
        MAXTEXT_CONFIG_PATH=${MAXTEXT_CONFIG_PATH:-${MAXTEXT_DIR}/src/maxtext/configs/base.yml}
        case "${INFERENCE_AOT_MODE:-native}" in
            native) INFERENCE_ENTRYPOINT="-m maxtext.inference.inference_microbenchmark" ;;
            consistent) INFERENCE_ENTRYPOINT="/tmp/stable_inference.py" ;;
            *) echo "Unsupported INFERENCE_AOT_MODE: ${INFERENCE_AOT_MODE}" >&2; exit 1 ;;
        esac
        TEST_CMD="python3 ${INFERENCE_ENTRYPOINT} ${MAXTEXT_CONFIG_PATH} \
            run_name=demo \
            hardware=$(if [ "$LOCAL_RUN" -eq 1 ]; then echo "gpu"; else echo "gpu_multiprocess"; fi) \
            base_output_directory=${OUTPUT_DIR}"
    elif [ "${MAXTEXT_IMPL}" = "deepseek" ]; then
        TEST_CMD="python3 /opt/maxtext/src/MaxText/train.py /opt/maxtext/src/MaxText/configs/base.yml \
            run_name=demo \
            hardware=$(if [ "$LOCAL_RUN" -eq 1 ]; then echo "gpu"; else echo "gpu_multiprocess"; fi) \
            enable_checkpointing=false \
            enable_checkpoint_cloud_logger=false \
            dataset_type=synthetic \
            skip_first_n_steps_for_profiler=9 \
            profiler_steps=3 \
            enable_goodput_recording=false \
            base_output_directory=${OUTPUT_DIR} \
            monitor_goodput=false"
    else
        TEST_CMD="python3 -m maxtext.trainers.pre_train.train ${MAXTEXT_DIR}/src/maxtext/configs/base.yml \
            run_name=demo \
            hardware=$(if [ "$LOCAL_RUN" -eq 1 ]; then echo "gpu"; else echo "gpu_multiprocess"; fi) \
            enable_checkpointing=false \
            enable_checkpoint_cloud_logger=false \
            dataset_type=synthetic \
            skip_first_n_steps_for_profiler=9 \
            profiler_steps=3 \
            enable_goodput_recording=false \
            base_output_directory=${OUTPUT_DIR} \
            monitor_goodput=false"
            #dataset_path=local \
    fi
    add_param() {
        local var_name=$1
        local param_name=${2:-$1}
        if [ -v "$var_name" ]; then
            TEST_CMD="$TEST_CMD ${param_name}=${!var_name}"
        fi
    }
    # Add all configuration parameters
    add_param "TOKENIZER_PATH" "tokenizer_path"
    add_param "MAX_TARGET_LENGTH" "max_target_length"
    add_param "BATCH_SIZE" "per_device_batch_size"
    add_param "MODEL" "model_name"

    TEST_CMD="$TEST_CMD ${ADDITIONAL_ARGS:-}"
    if [ "${MAXTEXT_RUNNER}" = "inference" ]; then
        TEST_PGLE_CMD=${TEST_CMD}
        TEST_RUN_CMD=${TEST_CMD}
    else
        TEST_PGLE_CMD=${TEST_CMD}" steps=14 profiler=nsys"
        TEST_RUN_CMD=${TEST_CMD}" steps=${STEPS:-15} profiler=${PROFILE:-''}"
    fi
fi

#PGLE profile run
if [ "${ENABLE_PGLE}" = "1" ]; then

    #export JAX_COMPILATION_CACHE_DIR=${OUTPUT_DIR}/jax_cache
    #export JAX_ENABLE_COMPILATION_CACHE=yes
    #mkdir -p ${JAX_COMPILATION_CACHE_DIR}
    #export JAX_ENABLE_PGLE=yes
    #${TEST_PGLE_CMD}

    nsys --version
    export XLA_FLAGS=${BASE_XLA_FLAGS}" --xla_gpu_enable_latency_hiding_scheduler=false --xla_gpu_disable_async_collectives=allreduce,allgather,reducescatter,collectivebroadcast,alltoall,collectivepermute"
    echo ${TEST_PGLE_CMD}

    ${NSYS_PGLE} \
    ${BIND_CMD} \
    ${TEST_PGLE_CMD}

    if [ "${SLURM_PROCID}" == "0" ] && [ ! -e "${NSYS_PGLE_FILE}.nsys-rep" ] ; then
        echo "nsys profiling failed."
        exit 1
    fi

    test "${SLURM_PROCID}" == 0 && python3 /opt/jax/jax/tools/pgo_nsys_converter.py --profile_path ${NSYS_PGLE_FILE}.nsys-rep --post_process --pgle_output_path ${NSYS_PGLE_FILE}.pbtxt
    if [ "${SLURM_PROCID}" == 0 ] && [ ! -e "${NSYS_PGLE_FILE}.pbtxt" ]; then
    echo "pgle converting failed."
    exit 1
    fi

    ELAPSED=0
    TIMEOUT=180
    while [ ! -f "${NSYS_PGLE_FILE}.pbtxt" ]; do
        echo "RANK $SLURM_PROCID waiting for the ${NSYS_PGLE_FILE}.pbtxt file to be created"
        sleep 1
        ELAPSED=$((ELAPSED + 1))
        if [ "$ELAPSED" -ge "$TIMEOUT" ]; then
            echo "Timeout waiting for RANK 0 ${NSYS_PGLE_FILE}.pbtxt file."
            exit 1
        fi
    done
    export XLA_FLAGS=${BASE_XLA_FLAGS}${XLA_DUMP_FLAGS}" --xla_gpu_pgle_profile_file_or_directory_path=${NSYS_PGLE_FILE}.pbtxt"
else
    export XLA_FLAGS=${BASE_XLA_FLAGS}${XLA_DUMP_FLAGS}
fi

echo "XLA_FLAGS: "${XLA_FLAGS}

#echo "ENABLE_PGLE: "${ENABLE_PGLE}
#if [ "${ENABLE_PGLE}" = "1" ]; then
#    export JAX_COMPILATION_CACHE_EXPECT_PGLE=yes
#fi

if [[ "${GDB:-0}" = "2" ]] || [[ "${GDB:-0}" = "4" ]] || [[ "${GDB:-0}" = "5" ]] || [[ "${GDB:-0}" = "6" ]]; then
    ${TEST_RUN_CMD} &

    CUDA_PROCESS_PID=$!

    cat >gdb_attach_${SLURM_LOCALID} <<EOL
        set logging file ${OUTPUT_DIR}/gdb/gdb_hang_debug_pid${SLURM_PROCID}.txt
        set logging on
	info sharedlibrary
        info thread
        thread apply all bt
        set logging off
        continue
EOL

    cat >cuda_gdb_attach_${SLURM_LOCALID} <<EOL
        set debug cuda trace all
        set logging file ${OUTPUT_DIR}/gdb/gdb_hang_debug_pid${SLURM_PROCID}.txt
        set logging on
	info sharedlibrary
        info thread
        info cuda kernels
        thread apply all bt
        set logging off
        continue
EOL

    sleep 300

    if [[ "${GDB:-0}" = "2" ]]; then
        gdb --pid=${CUDA_PROCESS_PID} -x gdb_attach_${SLURM_LOCALID}
    elif [[ "${GDB:-0}" = "4" ]]; then
        cuda-gdb --pid=${CUDA_PROCESS_PID} -x cuda_gdb_attach_${SLURM_LOCALID}
    elif [[ "${GDB:-0}" = "5" ]]; then
        if [ "$SLURM_NODEID" -eq 0 ] && [ "$SLURM_PROCID" -eq 0 ]; then
            gdb --pid=${CUDA_PROCESS_PID} -x cuda_gdb_attach_${SLURM_LOCALID}
        fi
    elif [[ "${GDB:-0}" = "6" ]]; then
        if [ "$SLURM_NODEID" -eq 0 ] && [ "$SLURM_PROCID" -eq 0 ]; then
            cuda-gdb --pid=${CUDA_PROCESS_PID} -x cuda_gdb_attach_${SLURM_LOCALID}
        fi
    fi
else
    ${GDB_CMD} \
    ${NSYS} \
    ${VALGRIND} \
    ${COMPUTE_SANITIZER} \
    ${BIND_CMD} \
    ${TEST_RUN_CMD}
fi
set +x
