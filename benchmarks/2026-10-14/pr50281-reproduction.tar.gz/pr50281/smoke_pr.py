import hashlib
import json
import os
from pathlib import Path
import jax
import jaxlib
import jax.numpy as jnp
import jax_plugins.xla_cuda13 as plugin

root=Path('/opt/pr-jaxlibs')
manifest=json.loads((root/'build-manifest.json').read_text())
assert manifest['pr_commit']=='f94df3539d9c655a86b5324264aaf01a0b5ce593'
assert str(root) in jaxlib.__file__ and str(root) in plugin.__file__
for name,expected in manifest['libraries'].items():
    with (root/name).open('rb') as f:
        assert hashlib.file_digest(f,'sha256').hexdigest()==expected,name
assert len(jax.devices())==4 and all(d.platform=='gpu' for d in jax.devices())
for mode in (False,True):
    value=jax.jit(lambda x:x@x+1,compiler_options={
        'xla_gpu_enable_heap_simulator_packing_search':mode})(jnp.ones((32,32))).block_until_ready()
    assert float(value[0,0])==33
record=dict(state='COMPLETED',pr_head=manifest['pr_commit'],libraries=len(manifest['libraries']),
            jax=jax.__version__,jaxlib=jaxlib.__version__,
            step_id=os.environ['SLURM_JOB_ID']+'.'+os.environ['SLURM_STEP_ID'])
Path('/work/smoke-pr.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
