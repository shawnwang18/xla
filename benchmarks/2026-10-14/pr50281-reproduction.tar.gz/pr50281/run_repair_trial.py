"""Serialize all trials in a reserved allocation, preserving the holder job."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import time
import threading
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path,data):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,indent=2)+'\n')
    tmp.replace(path)

ORPHANS={'gb300-nvl-022-compute04':'2521414.13','gb300-nvl-022-compute01':'2521414.17',
 'gb300-nvl-022-compute08':'2521414.19','gb300-nvl-022-compute10':'2521414.15',
 'gb300-nvl-022-compute11':'2521414.16','gb300-nvl-022-compute14':'2521414.18'}

def steps(allocation,node=None):
    raw=subprocess.check_output(['squeue','--steps','-j',allocation,'-h','-o','%i|%j|%N'],text=True,timeout=30)
    active=[]
    for line in raw.splitlines():
        ident,_,host=line.split('|')
        if ident.split('.')[-1] in {'batch','extern'} or (node is not None and host!=node):continue
        if ORPHANS.get(host)==ident:
            info=subprocess.check_output(['scontrol','show','step',ident],text=True,timeout=30)
            assert 'State=TIMEOUT ' in info,(ident,info)
        else:active.append(ident)
    return active

def verify_idle(node,out):
    import shlex
    orphan=ORPHANS[node]
    program=("import json,socket,subprocess;"
      f"s=subprocess.run(['scontrol','listpids',{orphan!r}],capture_output=True,text=True,timeout=12);"
      "g=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader'],capture_output=True,text=True,timeout=12);"
      "print(json.dumps(dict(host=socket.gethostname(),step_stdout=s.stdout,step_stderr=s.stderr,step_rc=s.returncode,gpu_stdout=g.stdout,gpu_stderr=g.stderr,gpu_rc=g.returncode)))")
    proc=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15',
        '-o','StrictHostKeyChecking=yes','-o','UserKnownHostsFile='+str(ROOT/'recovery_known_hosts'),
        node,'python3 -c '+shlex.quote(program)],capture_output=True,text=True,timeout=35)
    assert proc.returncode==0,(node,proc.returncode,proc.stderr)
    info=json.loads(proc.stdout)
    assert info['host']==node,info
    assert f'StepId={orphan} does not exist on node' in info['step_stdout']+info['step_stderr'],info
    assert info['gpu_rc']==0 and not info['gpu_stdout'].strip(),info
    save(out/'idle-check.json',dict(checked_at=now(),node=node,orphan_step=orphan,
         details=info,reason='Confirmed failed launcher; no step daemon or GPU processes'))

def one(case,trial,worker):
    allocation=worker['allocation_id']
    out=Path(trial['directory'])
    status=out/'run-status.json'
    if status.exists():
        record=json.loads(status.read_text())
        if record['state']=='COMPLETED':
            return record
        raise RuntimeError('Prior failed/unknown trial must be reconciled: '+str(status))
    if (out/'launch.json').exists():
        raise RuntimeError('Existing trial launch is unresolved: '+str(out))
    if (ROOT/'control.json').exists() and not json.loads((ROOT/'control.json').read_text()).get('enabled',True):
        raise RuntimeError('Suite disabled by control file')
    state=subprocess.check_output(['squeue','-h','-j',allocation,'-o','%T|%N|%u|%L'],text=True,timeout=30).strip()
    if not (state.startswith('RUNNING|') and '|shawnw|' in state):
        raise RuntimeError('Unexpected allocation state: '+state)
    if steps(allocation, worker['node']):
        raise RuntimeError('Allocation has another active workload step')
    verify_idle(worker['node'],out)
    env=os.environ.copy()
    env.update(json.loads((out/'env.json').read_text()))
    env.update(WORKLOAD=case['workload'],EXPECTED_MODEL=case['model'],PACKING_MODE=str(trial['mode']),EXPECTED_GPU_TYPE=worker['gpu_type'],
               ENROOT_CONFIG_PATH='/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/.enroot')
    mounts=[f'{ROOT}:/work',f'{out}:/result',f'{ROOT}/jaxlibs:/opt/pr-jaxlibs:ro', '/home/scratch.shawnw_inf/workload-runs/bug6811592-pr50286-dlcluster-20261014/imex-view:/dev/nvidia-caps-imex-channels:ro']
    if env.get('CUSTOM_MOUNTS'):
        mounts.append(env['CUSTOM_MOUNTS'])
    image='oauth2@'+env['CONTAINER'].replace('gitlab-master.nvidia.com:5005/','gitlab-master.nvidia.com:5005#')
    cmd=['srun','--jobid='+allocation,'--nodelist='+worker['node'],'--nodes=1','--exact','--overlap','--ntasks=4','--ntasks-per-node=4',
         '--cpus-per-task=16','--cpu-bind=none','--gres=gpu:'+worker['gpu_type']+':4','--time=01:00:00',
         '--kill-on-bad-exit=1','--job-name=pr50281-'+case['model']+'-'+str(trial['index']),
         '--container-image='+image,'--container-mounts='+','.join(mounts),
         '--container-name=pr50281-ten-workloads',
         '--container-remap-root','--container-writable','--container-workdir=/opt/maxtext',
         '--output='+str(out/'rank-%t.log'),'--error='+str(out/'rank-%t.log'),
         'bash','/work/rank.sh']
    record=dict(trial=trial,command=cmd,state='RUNNING',started_at=now(),allocation_id=allocation,node=worker['node'],gpu_type=worker['gpu_type'])
    save(out/'launch.json',record)
    with (out/'launcher.log').open('w') as log:
        process=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        while process.poll() is None:
            time.sleep(30)
            ranks=list(out.glob('step-rank*.json'))
            if ranks:
                record['step_id']=json.loads(ranks[0].read_text())['step_id']
                save(out/'launch.json',record)
        rc=process.returncode
    records=[json.loads(f.read_text()) for f in sorted(out.glob('runtime-rank*.json'))]
    valid=rc==0 and len(records)==4 and all(r['state']=='COMPLETED' for r in records)
    if case['type']=='inference':
        reports=[json.loads(f.read_text()) for f in out.glob('stable-rank*.json')]
        valid=valid and len(reports)==4 and all(r['status']=='completed' and r.get('model_request_e2e') for r in reports)
    else:
        reports=[json.loads(f.read_text()) for f in out.glob('training-summary-rank*.json')]
        metrics=list(out.glob('training-metrics-rank*.jsonl'))
        valid=valid and len(reports)==4 and (len(metrics)==4 or
            (trial['pilot'] and (out/'training-metrics.jsonl').is_file()))
    record.update(returncode=rc,state='COMPLETED' if valid else 'FAILED',finished_at=now())
    save(status,record)
    if not valid:
        raise RuntimeError('Trial failed or required output missing: '+str(out))
    return record

def main():
    plan=json.loads((ROOT/'parallel-plan.json').read_text())
    cases=json.loads((ROOT/'cases.json').read_text())
    by_name={c['workload']:c for c in cases}
    assigned=[w for a in plan['workers'] for w in a['workloads']]
    assert len(assigned)==len(set(assigned))==len(cases) and set(assigned)==set(by_name)
    # The parent claim.py owns the shared reservation reuse lock.
    claim=json.loads((ROOT/'claim.json').read_text())
    assert claim['active_task']==plan['thread_id']
    os.kill(claim['controller_pid'],0)
    assert not steps('2521414'), 'Reservation has an unexpected active step'
    status=dict(state='RUNNING',pid=os.getpid(),host=os.uname().nodename,started_at=now(),
                execution='parallel_cases_serial_trials',current=None,completed=[],workers={})
    completed={}
    for case in cases:
        for trial in case['trials']:
            p=Path(trial['directory'])/'run-status.json'
            if p.exists():
                d=json.loads(p.read_text())
                if d['state']=='COMPLETED':completed[trial['directory']]=d
    mutex=threading.Lock()
    def persist():
        status['completed']=[completed[t['directory']] for c in cases for t in c['trials'] if t['directory'] in completed]
        status['checked_at']=now()
        save(ROOT/'suite-status.json',status)
    for worker in plan['workers']:
        status['workers'][worker['node']]=dict(**worker,state='STARTING',current=None)
    persist()
    def run_worker(worker):
        ws=status['workers'][worker['node']]
        try:
            for workload in worker['workloads']:
                case=by_name[workload]
                for trial in case['trials']:
                    if trial['directory'] in completed:continue
                    with mutex:
                        ws.update(state='RUNNING',current=trial)
                        persist()
                    record=one(case,trial,worker)
                    with mutex:
                        completed[trial['directory']]=record
                        persist()
            with mutex:
                ws.update(state='COMPLETED',current=None,finished_at=now())
                persist()
        except BaseException as exc:
            with mutex:
                ws.update(state='FAILED',error=repr(exc),finished_at=now())
                persist()
    with ThreadPoolExecutor(max_workers=len(plan['workers'])) as executor:
        futures=[executor.submit(run_worker,w) for w in plan['workers']]
        while not all(f.done() for f in futures):
            time.sleep(30)
            with mutex:persist()
        for f in futures:f.result()
    with mutex:
        status['state']='COMPLETED' if len(completed)==sum(len(c['trials']) for c in cases) else 'FAILED'
        if status['state']=='FAILED':status['error']='One or more workers failed; completed trials preserved'
        status['finished_at']=now()
        persist()
    if status['state']=='FAILED': raise SystemExit(1)

if __name__=='__main__':
    main()
