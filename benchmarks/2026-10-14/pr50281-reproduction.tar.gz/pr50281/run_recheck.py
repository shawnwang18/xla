"""Finish the remaining OFF and perform one bounded ON recheck under the task lease."""
import fcntl,json,os,threading,time
from pathlib import Path
from run_repair_trial import one,now,save,steps
ROOT=Path(__file__).resolve().parent

def main():
 guard=(ROOT/'recheck-controller.lock').open('a');fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (ROOT/'recheck-status.json').exists(),'Reconcile prior recheck controller'
 assert os.uname().nodename=='dlcluster-login-02'
 plan=json.loads((ROOT/'recheck-plan.json').read_text());w=plan['worker']
 case=next(c for c in json.loads((ROOT/'cases.json').read_text()) if c['workload']==w['workloads'][0])
 status=dict(state='WAITING_FOR_LEASE',pid=os.getpid(),host=os.uname().nodename,started_at=now(),
   workers={w['node']:dict(**w,state='WAITING_FOR_LEASE',current=None)},completed=[])
 mutex=threading.RLock();done=threading.Event()
 def persist():
  with mutex:status['checked_at']=now();save(ROOT/'recheck-status.json',status)
 def heartbeat():
  while not done.wait(30):persist()
 persist();threading.Thread(target=heartbeat,daemon=True).start()
 claim=json.loads((ROOT/'claim.json').read_text());lock_path=Path(claim['reuse_lock']);ws=status['workers'][w['node']]
 try:
  with lock_path.open('a') as lease:
   while True:
    try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB);break
    except BlockingIOError:
     if (ROOT/'control.json').exists():assert json.loads((ROOT/'control.json').read_text()).get('enabled',True),'Suite disabled'
     time.sleep(15)
   active=json.loads((lock_path.parent/'active-reuse.json').read_text());assert active['active_task']==plan['thread_id'],active
   assert json.loads((ROOT/'repair-status.json').read_text())['state'] in ('FAILED','COMPLETED'),'Repair controller still active'
   assert not steps('2521414',w['node'])
   claim.update(controller_pid=os.getpid(),controller_host=os.uname().nodename,reuse_state='BUSY_PR50281_RECHECK',updated_at=now())
   save(lock_path.parent/'active-reuse.json',claim);save(ROOT/'recheck-lease.json',claim)
   try:
    with mutex:status['state']='RUNNING';persist()
    for trial in plan['trials']:
     with mutex:ws.update(state='RUNNING',current=trial);persist()
     record=one(case,trial,w)
     with mutex:status['completed'].append(record);persist()
    with mutex:ws.update(state='COMPLETED',current=None,finished_at=now());status.update(state='COMPLETED',finished_at=now());persist()
   finally:
    claim.update(reuse_state='IDLE_RETAINED',updated_at=now());save(lock_path.parent/'active-reuse.json',claim);save(ROOT/'recheck-lease.json',claim)
 except BaseException as exc:
  with mutex:ws.update(state='FAILED',error=repr(exc),finished_at=now());status.update(state='FAILED',error=repr(exc),finished_at=now());persist()
 finally:done.set()
 if status['state']=='FAILED':raise SystemExit(1)
if __name__=='__main__':main()
