"""Validate all eight reserved nodes and record the unmodified base image."""
import json
import os
from pathlib import Path
import subprocess
import importlib.util

rank = int(os.environ['SLURM_PROCID'])
out = Path('/work/preflight')
record = dict(host=os.uname().nodename, rank=rank,
              step_id=os.environ['SLURM_JOB_ID']+'.'+os.environ['SLURM_STEP_ID'])
record['hardware'] = subprocess.check_output(
    ['nvidia-smi','--query-gpu=name,uuid,memory.total,driver_version','--format=csv,noheader'], text=True)
assert len(record['hardware'].splitlines()) == 4
assert all('GB300' in line for line in record['hardware'].splitlines())
record['sources'] = {}
for name in ['jax', 'xla', 'maxtext']:
    record['sources'][name] = subprocess.check_output(
        ['git','-C','/opt/'+name,'rev-parse','HEAD'], text=True).strip()
import jax
import jaxlib
import jax.numpy as jnp
assert len(jax.devices()) == 4 and all(d.platform == 'gpu' for d in jax.devices())
y = jax.jit(lambda x: x @ x + 1)(jnp.ones((32,32))).block_until_ready()
assert float(y[0,0]) == 33
record.update(jax=jax.__version__, jaxlib=jaxlib.__version__, state='COMPLETED')
(out/f'node-{rank}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record), flush=True)
