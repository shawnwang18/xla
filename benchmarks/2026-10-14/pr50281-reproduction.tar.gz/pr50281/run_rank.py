"""Strict model runner, compiler provenance, process time and allocator stats."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import resource
import runpy
import shlex
import statistics
import subprocess
import sys
import time

OUT = Path('/result')
rank = int(os.environ['SLURM_PROCID'])
trial = json.loads((OUT/'trial.json').read_text())
record = dict(trial=trial, rank=rank, step_id=os.environ['SLURM_JOB_ID']+'.'+os.environ['SLURM_STEP_ID'],
              state='STARTING', xla_flags=os.environ['XLA_FLAGS'])
(OUT/f'step-rank{rank}.json').write_text(json.dumps(record,indent=2)+'\n')
manifest = json.loads(Path('/opt/pr-jaxlibs/build-manifest.json').read_text())
assert manifest['pr_commit'] == 'f94df3539d9c655a86b5324264aaf01a0b5ce593'
import jax
import jaxlib
plugin = importlib.import_module('jax_plugins.xla_cuda13')
assert '/opt/pr-jaxlibs/' in jaxlib.__file__, jaxlib.__file__
assert '/opt/pr-jaxlibs/' in plugin.__file__, plugin.__file__
if rank == 0:
    hardware = subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,memory.total,driver_version','--format=csv,noheader'],text=True)
    expected_gpu=os.environ.get('EXPECTED_GPU_TYPE')
    assert not expected_gpu or all(expected_gpu in line for line in hardware.splitlines()), hardware
    (OUT/'hardware.json').write_text(json.dumps(dict(host=os.uname().nodename,allocation=os.environ['SLURM_JOB_ID'],gpu_query=hardware),indent=2)+'\n')
    for name, expected in manifest['libraries'].items():
        with (Path('/opt/pr-jaxlibs')/name).open('rb') as f:
            assert hashlib.file_digest(f,'sha256').hexdigest() == expected, name
    versions = dict(jax=jax.__version__,jaxlib=jaxlib.__version__,jaxlib_path=jaxlib.__file__,plugin_path=plugin.__file__)
    source = subprocess.run(['git','-C','/opt/maxtext','rev-parse','HEAD'],capture_output=True,text=True)
    (OUT/'provenance.json').write_text(json.dumps(dict(manifest=manifest,versions=versions,maxtext_commit=source.stdout.strip()),indent=2)+'\n')
    print('PR_BUILD_VERIFIED',manifest['pr_commit'],versions,flush=True)

config = os.environ.get('MAXTEXT_CONFIG_PATH','/opt/maxtext/src/maxtext/configs/base.yml')
args = ['run_name=pr50281', 'hardware=gpu_multiprocess', 'base_output_directory=/result/outputs']
if trial['type'] == 'training':
    args += ['enable_checkpointing=false','enable_checkpoint_cloud_logger=false',
             'dataset_type=synthetic','enable_goodput_recording=false','monitor_goodput=false']
args += shlex.split(os.environ['ADDITIONAL_ARGS'])
if trial['type'] == 'training':
    args += ['steps=101', 'profiler=""', f'metrics_file=/result/training-metrics-rank{rank}.jsonl']
    if rank == 0 and not (OUT/'training-metrics.jsonl').exists():
        (OUT/'training-metrics.jsonl').symlink_to('training-metrics-rank0.jsonl')
else:
    args = ['inference_microbenchmark_prefill_lengths="1024"'
            if a.startswith('inference_microbenchmark_prefill_lengths=') else a for a in args]
sys.argv = ['run_rank.py',config] + args
record['argv'] = sys.argv
start = time.perf_counter()
try:
    if trial['type'] == 'training':
        from absl import app
        from maxtext.trainers.pre_train import train
        # Wrap the application iteration only; the model, optimizer and JIT
        # functions remain unchanged. Synchronize to measure completed work.
        original_iteration = train.training_loop_iteration
        samples = []
        def timed_iteration(device_state, python_vars, immutable_data):
            step = int(python_vars['step'])
            jax.block_until_ready(device_state['state'])
            begin = time.perf_counter_ns()
            result = original_iteration(device_state, python_vars, immutable_data)
            jax.block_until_ready(device_state['state'])
            milliseconds = (time.perf_counter_ns()-begin)/1e6
            sample = dict(step=step,milliseconds=milliseconds,warmup=step<40)
            samples.append(sample)
            with (OUT/f'training-samples-rank{rank}.jsonl').open('a') as f:
                f.write(json.dumps(sample)+'\n')
            if step == 99:
                values=[s['milliseconds'] for s in samples if 40 <= s['step'] <= 99]
                stats=dict(mean_ms=statistics.mean(values),median_ms=statistics.median(values),
                           samples_ms=values,steps=[40,99],
                           scope='MaxText application training iteration, including synthetic data fetch, forward/backward/update, metrics and synchronization',
                           devices=[dict(device=str(d),stats=d.memory_stats()) for d in jax.local_devices()])
                (OUT/f'training-summary-rank{rank}.json').write_text(json.dumps(stats,indent=2)+'\n')
            return result
        train.training_loop_iteration = timed_iteration
        app.run(train.main)
    else:
        runpy.run_path('/work/measure_inference.py',run_name='__main__')
    record.update(state='COMPLETED',returncode=0)
except SystemExit as exc:
    if exc.code not in (None,0):
        record.update(state='FAILED',returncode=exc.code)
        raise
    record.update(state='COMPLETED',returncode=0)
except BaseException as exc:
    record.update(state='FAILED',returncode=1,error=repr(exc))
    raise
finally:
    record['process_wall_s'] = time.perf_counter()-start
    record['host_peak_rss_kib'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if jax.distributed.is_initialized():
        try:
            record['devices'] = [dict(device=str(d),stats=d.memory_stats()) for d in jax.local_devices()]
        except Exception as exc:
            record['memory_error'] = repr(exc)
    (OUT/f'runtime-rank{rank}.json').write_text(json.dumps(record,indent=2,default=str)+'\n')
    print('PERF_RUNTIME',json.dumps(record,default=str),flush=True)
