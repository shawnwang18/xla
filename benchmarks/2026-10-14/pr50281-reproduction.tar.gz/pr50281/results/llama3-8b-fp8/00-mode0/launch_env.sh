#!/bin/bash
set -euo pipefail
export ADDITIONAL_ARGS='num_slices=-1 model_name=llama3-8b max_target_length=8192 quantization=fp8 per_device_batch_size=2 scan_layers=False learning_rate=1e-7 abort_on_nan_loss=false abort_on_inf_loss=false dcn_data_parallelism=1 dcn_fsdp_parallelism=-1 dcn_fsdp_transpose_parallelism=1 dcn_pipeline_parallelism=1 dcn_expert_parallelism=1 ici_data_parallelism=1 ici_fsdp_parallelism=-1 ici_fsdp_transpose_parallelism=1 ici_sequence_parallelism=1 ici_tensor_parallelism=1 ici_tensor_sequence_parallelism=1 ici_autoregressive_parallelism=1 ici_pipeline_parallelism=1 ici_expert_parallelism=1'
export BASE_RESULT_DIR=/home/shawnw/workload-runs/pr50281-ten-workloads-20261014/results/llama3-8b-fp8/00-mode0
export BASE_XLA_FLAGS='--xla_gpu_enable_command_buffer= --xla_gpu_command_buffer_unroll_loops=false --xla_gpu_enable_cudnn_fmha=1 --xla_gpu_require_exclusive_lock=0 --xla_gpu_enable_latency_hiding_scheduler=1 --xla_gpu_command_buffer_scheduling_mode=LHS --xla_gpu_command_buffer_update_mode=ALWAYS_UPDATE --xla_gpu_nccl_termination_timeout_seconds=120000000 --xla_disable_hlo_passes=hlo-verifier --xla_gpu_enable_triton_gemm=false --xla_gpu_enable_highest_priority_async_stream=true --xla_gpu_all_reduce_combine_threshold_bytes=33554432 --xla_gpu_all_gather_combine_threshold_bytes=33554432 --xla_gpu_reduce_scatter_combine_threshold_bytes=33554432 --xla_gpu_enable_pipelined_all_gather=true --xla_gpu_enable_pipelined_reduce_scatter=true --xla_gpu_enable_pipelined_all_reduce=true --xla_gpu_enable_while_loop_double_buffering=true --xla_gpu_enable_all_gather_combine_by_dim=false --xla_gpu_enable_reduce_scatter_combine_by_dim=false --xla_disable_hlo_passes=rematerialization --xla_gpu_experimental_parallel_collective_overlap_limit=9 --xla_gpu_shard_autotuning=false --xla_gpu_enable_heap_simulator_packing_search=false'
export BINDPCIE=0
export BUILD_JAX=0
export CLUSTER=dlcluster
export CONTAINER=gitlab-master.nvidia.com:5005/dl/dgx/jax:maxtext-2026-10-13
export CUDA_SCALE_LAUNCH_QUEUES=1x
export CUSTOM_MOUNTS=''
export ENABLE_CMD_BUFFER_DUMPS=0
export ENABLE_NCCL_DEBUG=0
export ENABLE_PGLE=0
export ENABLE_VALGRIND_DEBUG=0
export ENABLE_XLA_DUMPS=1
export GDB=0
export GPUS_PER_NODE=4
export INFERENCE_AOT_MODE=native
export MAXTEXT_IMPL=container
export MAXTEXT_RUNNER=train
export NCCL_DEBUG=VERSION
export NCCL_GRAPH_MIXING_SUPPORT=1
export NODES=1
export NVTE_FUSED_ATTN=1
export PREC=bfloat16
export PROFILE=''
export RUN=maxText
export STEPS=101
export TF_CPP_MAX_LOG_LEVEL=300
export TF_CPP_MIN_LOG_LEVEL=0
export TF_CPP_VMODULE=fusion_emitter=0,mlir_fusion_emitter=0,gpu_compiler=1,command_buffer_cmd=0
export XLA_PYTHON_CLIENT_ALLOCATOR=bfc
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.85
true
