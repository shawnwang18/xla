#!/bin/bash
set -euo pipefail
export ADDITIONAL_ARGS='num_slices=1 async_checkpointing=false max_prefill_predict_length=1024 max_target_length=2048 model_name=gemma2-27b per_device_batch_size=150 scan_layers=false tokenizer_path=/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.gemma dtype=bfloat16 weight_dtype=bfloat16 quantization= quantize_kvcache=false attention=dot_product inference_microbenchmark_prefill_lengths="1024" inference_microbenchmark_stages=prefill,generate inference_microbenchmark_loop_iters=300 gcs_metrics=false dcn_data_parallelism=1 dcn_fsdp_parallelism=1 dcn_fsdp_transpose_parallelism=1 dcn_pipeline_parallelism=1 dcn_expert_parallelism=1 ici_data_parallelism=1 ici_fsdp_parallelism=4 ici_fsdp_transpose_parallelism=1 ici_sequence_parallelism=1 ici_tensor_parallelism=1 ici_tensor_sequence_parallelism=1 ici_autoregressive_parallelism=1 ici_pipeline_parallelism=1 ici_expert_parallelism=1'
export BASE_RESULT_DIR=/home/shawnw/workload-runs/pr50281-ten-workloads-20261014/results/ci-infer-gemma2-27b-bf16-1n4g/03-mode1
export BASE_XLA_FLAGS='--xla_gpu_enable_command_buffer= --xla_gpu_command_buffer_unroll_loops=false --xla_gpu_enable_cudnn_fmha=1 --xla_gpu_require_exclusive_lock=0 --xla_gpu_enable_latency_hiding_scheduler=1 --xla_gpu_command_buffer_scheduling_mode=LHS --xla_gpu_command_buffer_update_mode=ALWAYS_UPDATE --xla_disable_hlo_passes=rematerialization --xla_gpu_enable_heap_simulator_packing_search=true'
export BINDPCIE=0
export BUILD_JAX=0
export CLUSTER=dlcluster
export CONTAINER=gitlab-master.nvidia.com:5005/dl/dgx/jax:maxtext-2026-10-13
export CUDA_SCALE_LAUNCH_QUEUES=1x
export CUSTOM_MOUNTS=/home/shawnw/workload-runs/pr50281-ten-workloads-20261014/skill/assets/jax-run-scripts/inference_aot_runner.py:/tmp/jax-workloads/inference_aot_runner.py:ro
export ENABLE_CMD_BUFFER_DUMPS=0
export ENABLE_NCCL_DEBUG=0
export ENABLE_PGLE=0
export ENABLE_VALGRIND_DEBUG=0
export ENABLE_XLA_DUMPS=1
export GDB=0
export GPUS_PER_NODE=4
export INFERENCE_AOT_MODE=consistent
export MAXTEXT_CONFIG_PATH=/opt/maxtext/src/maxtext/configs/base.yml
export MAXTEXT_IMPL=container
export MAXTEXT_RUNNER=inference
export NCCL_DEBUG=VERSION
export NCCL_GRAPH_MIXING_SUPPORT=1
export NODES=1
export NVTE_FUSED_ATTN=1
export PREC=bfloat16
export PROFILE=''
export RUN=maxText
export STEPS=101
export TF_CPP_MAX_LOG_LEVEL=300
export TF_CPP_MIN_LOG_LEVEL=0
export TF_CPP_VMODULE=fusion_emitter=0,mlir_fusion_emitter=0,gpu_compiler=1,command_buffer_cmd=0
export XLA_PYTHON_CLIENT_ALLOCATOR=bfc
export XLA_PYTHON_CLIENT_MEM_FRACTION=0.85
true
