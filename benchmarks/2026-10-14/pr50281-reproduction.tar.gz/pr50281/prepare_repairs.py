"""Create new trials only for three confirmed failed baseline configurations."""
import fcntl,json,re,shlex,subprocess
from pathlib import Path
from run_parallel import now,save
ROOT=Path(__file__).resolve().parent
ADJUSTMENTS={
 'qwen3-8b-fp8':dict(variant='no-pipelining',failed_step='2521414.13',expected_state='TIMEOUT',node='gb300-nvl-022-compute04',reason='Original OFF pilot timed out before any iteration, with GPU activity after compilation; bounded diagnostic rerun with catalog no_pipelining flags.'),
 'ci-infer-gemma2-27b-bf16-1n4g':dict(variant='batch1',failed_step='2521414.49',expected_state='CANCELLED',node='gb300-nvl-022-compute10',original_batch=150,per_device_batch_size=1,reason='Original OFF pilot exhausted GPU memory during decode-state initialization before measurements.'),
 'ci-infer-gemma3-27b-bf16-1n4g':dict(variant='batch1',failed_step='2521414.54',expected_state='CANCELLED',node='gb300-nvl-022-compute11',original_batch=120,per_device_batch_size=1,reason='Original OFF pilot exhausted GPU memory during decode-state initialization before measurements.')}

def main():
 with (ROOT/'repair-prepare.lock').open('a') as guard:
  fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not (ROOT/'repair-plan.json').exists(),'Repair already prepared; reconcile'
  cases=json.loads((ROOT/'cases.json').read_text())
  accounting=subprocess.check_output(['sacct','-j','2521414.13,2521414.49,2521414.54','-nP','-o','JobID,State,ExitCode'],text=True)
  rows={line.split('|')[0]:line.split('|')[1:] for line in accounting.splitlines()}
  for case in cases:
   if case['workload'] not in ADJUSTMENTS:continue
   a=ADJUSTMENTS[case['workload']];pilot=Path(case['trials'][0]['directory']);st=json.loads((pilot/'run-status.json').read_text())
   assert st['state']=='FAILED' and st['step_id']==a['failed_step']
   assert rows[a['failed_step']][0].startswith(a['expected_state']),rows
   if 'gemma' in case['workload']:
    errors=[json.loads(p.read_text()).get('error','') for p in pilot.glob('runtime-rank*.json')]
    assert len(errors)==4 and all('RESOURCE_EXHAUSTED' in e for e in errors)
   for t in case['trials'][1:]:assert not (Path(t['directory'])/'launch.json').exists()
   assert not (pilot.parent/a['variant']).exists()
  save(ROOT/'cases-before-repair.json',cases)
  workers=[]
  for case in cases:
   if case['workload'] not in ADJUSTMENTS:continue
   a=ADJUSTMENTS[case['workload']];a['confirmed_accounting']=rows[a['failed_step']]
   for trial in case['trials']:
    old=Path(trial['directory']);new=old.parent/a['variant']/old.name;new.mkdir(parents=True)
    env=json.loads((old/'env.json').read_text());resolved=json.loads((old/'resolved.json').read_text())
    if a['variant']=='batch1':
     env['ADDITIONAL_ARGS'],count=re.subn(r'per_device_batch_size=\S+','per_device_batch_size=1',env['ADDITIONAL_ARGS']);assert count==1
    else:
     for flag in ['all_gather','reduce_scatter','all_reduce']:
      key='--xla_gpu_enable_pipelined_'+flag+'=true';assert key in env['BASE_XLA_FLAGS'];env['BASE_XLA_FLAGS']=env['BASE_XLA_FLAGS'].replace(key,key.replace('=true','=false'))
     env['BASE_XLA_FLAGS']=env['BASE_XLA_FLAGS'].replace('--xla_gpu_enable_while_loop_double_buffering=true','--xla_gpu_enable_while_loop_double_buffering=false').replace('--xla_gpu_experimental_parallel_collective_overlap_limit=9','--xla_gpu_experimental_parallel_collective_overlap_limit=1')
     env['NCCL_DEBUG']='INFO';resolved['job']['xla_config']='no_pipelining'
    env['BASE_RESULT_DIR']=str(new);trial['directory']=str(new);trial['variant']=a['variant']
    resolved.update(env=env,trial=trial,benchmark_adjustment=a,original_trial_directory=str(old))
    save(new/'env.json',env);save(new/'trial.json',trial);save(new/'resolved.json',resolved)
    (new/'launch_env.sh').write_text('#!/bin/bash\n'+''.join('export '+k+'='+shlex.quote(str(v))+'\n' for k,v in sorted(env.items())))
   case['adjustment']=a
   workers.append(dict(node=a['node'],allocation_id='2521414',gpu_type='GB300',workloads=[case['workload']]))
  save(ROOT/'cases.json',cases)
  protocol=json.loads((ROOT/'protocol.json').read_text());protocol['adjustments_after_baseline_failures']=ADJUSTMENTS;save(ROOT/'protocol.json',protocol)
  plan=dict(prepared_at=now(),workers=workers,adjustments=ADJUSTMENTS,accounting=accounting,thread_id='01a13851-3ca3-7d63-b40e-6c48720efd90')
  save(ROOT/'repair-plan.json',plan);print(json.dumps(plan,indent=2))
if __name__=='__main__':main()
