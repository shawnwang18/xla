"""Preserve the confirmed CUDA failure and prepare exactly one diagnostic repeat."""
import copy,fcntl,json,shlex,subprocess
from pathlib import Path
from run_repair_trial import now,save
ROOT=Path(__file__).resolve().parent

def main():
 with (ROOT/'recheck-prepare.lock').open('a') as guard:
  fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not (ROOT/'recheck-plan.json').exists(),'Already prepared; reconcile'
  cases=json.loads((ROOT/'cases.json').read_text())
  case=next(c for c in cases if c['workload']=='ci-infer-gemma2-27b-bf16-1n4g')
  old_trial=copy.deepcopy(case['trials'][3]);old=Path(old_trial['directory']);new=old.with_name('03-mode1-recheck')
  status=json.loads((old/'run-status.json').read_text())
  assert status['state']=='FAILED' and status['step_id']=='2521414.65',status
  repair=json.loads((ROOT/'repair-status.json').read_text())
  assert repair['workers']['gb300-nvl-022-compute10']['state']=='FAILED'
  accounting=subprocess.check_output(['sacct','-j','2521414.65','-nP','-o','JobIDRaw,State,ExitCode,Elapsed,NodeList'],text=True,timeout=30)
  assert accounting.startswith('2521414.65|CANCELLED|0:15|'),accounting
  error=json.loads((old/'runtime-rank3.json').read_text())['error']
  assert 'CUDA_ERROR_ILLEGAL_ADDRESS' in error,error
  assert not (Path(case['trials'][4]['directory'])/'launch.json').exists()
  assert not new.exists()
  save(ROOT/'cases-before-recheck.json',cases)
  trial=copy.deepcopy(old_trial);trial.update(directory=str(new),replaces_failed_directory=str(old),diagnostic_repeat=True)
  new.mkdir()
  env=json.loads((old/'env.json').read_text());env['BASE_RESULT_DIR']=str(new)
  resolved=json.loads((old/'resolved.json').read_text());resolved.update(env=env,trial=trial,original_failed_trial_directory=str(old))
  save(new/'env.json',env);save(new/'trial.json',trial);save(new/'resolved.json',resolved)
  (new/'launch_env.sh').write_text('#!/bin/bash\n'+''.join('export '+k+'='+shlex.quote(str(v))+'\n' for k,v in sorted(env.items())))
  failure=dict(step_id='2521414.65',directory=str(old),trial=old_trial,accounting=accounting,error=error,
    evidence='Zero phase samples on every rank; CUDA illegal address at first prefill. Successful ON02 and failed ON03 have identical rank0 optimized HLO, buffer assignment and memory report hashes.',
    reporting='Always report this ON failure; successful recheck does not establish PR correctness or erase the failure.')
  case['trials'][3]=trial;case['diagnostic_failures']=[failure]
  save(ROOT/'cases.json',cases)
  protocol=json.loads((ROOT/'protocol.json').read_text());protocol['diagnostic_failures']=[failure]
  protocol['diagnostic_recheck']=dict(workload=case['workload'],order=['remaining OFF index4','one ON index3 diagnostic repeat'],max_repeats=1,
    unchanged='Same node, binary, environment, batch, compiler flags except OFF/ON flag; no workload edits.',
    performance_scope='Passing trials only; Gemma2-27B comparison is conditional because an earlier measured ON attempt crashed.')
  save(ROOT/'protocol.json',protocol)
  worker=dict(node='gb300-nvl-022-compute10',allocation_id='2521414',gpu_type='GB300',workloads=[case['workload']])
  plan=dict(prepared_at=now(),thread_id='01a13851-3ca3-7d63-b40e-6c48720efd90',worker=worker,trials=[case['trials'][4],trial],failure=failure)
  save(ROOT/'recheck-plan.json',plan);print(json.dumps(plan,indent=2))
if __name__=='__main__':main()
