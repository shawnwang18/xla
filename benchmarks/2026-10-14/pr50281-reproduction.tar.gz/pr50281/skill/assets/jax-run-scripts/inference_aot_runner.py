"""Skill-owned prefill/decode runner with a consistent recurrent state format.

Uses the installed MaxText model and timing routines without modifying their
source or replacing their functions. Compilation and parameter placement happen
before warmup/timing. This runner supports the prefill and generate stages only.
"""

import hashlib
import json
from pathlib import Path


def require_same_formats(actual, expected, label):
    """Reject incompatible trees before an AOT invocation or recurrent loop."""
    import jax

    actual_leaves, actual_tree = jax.tree.flatten(actual)
    expected_leaves, expected_tree = jax.tree.flatten(expected)
    if actual_tree != expected_tree:
        raise RuntimeError(f"{label}: format tree structures differ")
    mismatches = [
        (index, str(a), str(e))
        for index, (a, e) in enumerate(zip(actual_leaves, expected_leaves))
        if a != e
    ]
    if mismatches:
        raise RuntimeError(f"{label}: {len(mismatches)} format mismatches; first: {mismatches[:3]}")


def compile_recurrent(function, params, state, rng, compiler_options=None):
    """Find a recurrent format, allowing bounded compiler layout feedback."""
    import jax
    from jax.experimental.layout import Format, Layout

    probe = jax.jit(
        function,
        in_shardings=(Format(Layout.AUTO), Format(Layout.AUTO), None),
        out_shardings=(Format(Layout.AUTO), Format(Layout.AUTO)),
        donate_argnums=(1,),
        keep_unused=True,
    ).lower(params, state, rng).compile(compiler_options=compiler_options)
    inputs, _ = probe.input_formats
    state_formats = inputs[1]
    for attempt in range(3):
        compiled = jax.jit(
            function,
            in_shardings=(inputs[0], state_formats, None),
            out_shardings=(state_formats, Format(Layout.AUTO)),
            donate_argnums=(1,),
            # Keep the complete state contract, including old logits/log-probs
            # that generate replaces without reading. Otherwise their input
            # formats become Format(None, None) and cannot initialize the state.
            keep_unused=True,
        ).lower(params, state, rng).compile(compiler_options=compiler_options)
        final_inputs, _ = compiled.input_formats
        try:
            require_same_formats(compiled.output_formats[0], final_inputs[1], "decode recurrence")
        except RuntimeError:
            if attempt == 2:
                raise
            # Singleton cache dimensions can acquire a different output layout.
            # Feed that concrete layout back to BOTH boundaries, retaining the
            # requested state sharding. This happens only before timing.
            state_formats = jax.tree.map(
                lambda output, requested: Format(output.layout, requested.sharding),
                compiled.output_formats[0], state_formats,
            )
            inputs = final_inputs
            print(f"JAX_WORKLOADS_RUNNER decode layout feedback {attempt + 1}/2", flush=True)
        else:
            return compiled


def place_parameters(params, formats):
    """Place one parameter at a time to limit temporary device memory use."""
    import jax

    def place(array, target):
        if array.format == target:
            return array
        result = jax.device_put(array, target)
        jax.block_until_ready(result)
        if result is not array:
            array.delete()
        return result

    return jax.tree.map(place, params, formats)


def compile_engine(engine, params, rng_shape):
    """Populate the format metadata consumed by MaxText's prefill processor."""
    import jax

    engine.decode_state_shapes = jax.eval_shape(engine.init_decode_state, rng_shape)
    generate = compile_recurrent(
        engine.generate_aot, engine.abstract_params, engine.decode_state_shapes, rng_shape
    )
    inputs, _ = generate.input_formats
    engine.param_layouts, engine.decode_state_layouts = inputs[:2]
    params = place_parameters(params, engine.param_layouts)
    initialize = jax.jit(
        engine.init_decode_state,
        in_shardings=None,
        out_shardings=engine.decode_state_layouts,
    ).lower(rng_shape).compile()
    require_same_formats(initialize.output_formats, inputs[1], "decode initialization")
    return generate, params, initialize


def run_benchmarks(config):
    """Use MaxText's existing timing loops around the skill's AOT setup."""
    import jax
    from maxtext.inference import inference_microbenchmark as benchmark
    from maxtext.inference.maxengine import maxengine
    from maxtext.input_pipeline.packing import prefill_packing
    from maxtext.utils import max_utils

    stages = config.inference_microbenchmark_stages.split(",")
    if not stages or set(stages) - {"prefill", "generate"}:
        raise ValueError("inference_aot_mode=consistent supports only prefill,generate stages")
    engine = maxengine.MaxEngine(config)
    processor = prefill_packing.PrefillProcessor(engine)
    rng = jax.random.PRNGKey(1234)
    rng, rng_params = jax.random.split(rng)
    params = engine.load_params(rng_params)
    tokenizer = engine.build_tokenizer(engine.get_tokenizer())
    rng, rng_init = jax.random.split(rng)
    rng_shape = jax.ShapeDtypeStruct([4], jax.numpy.dtype("uint32"))
    generate, params, initialize = compile_engine(engine, params, rng_shape)
    decode_state = initialize(rng_init)
    _, cache_size, _ = max_utils.summarize_pytree_data(decode_state["cache"], name="Cache")
    num_params, model_size, _ = max_utils.summarize_pytree_data(params, name="Model")
    iters = config.inference_microbenchmark_loop_iters
    results = {}

    if "prefill" in stages:
        lengths = [int(value) for value in config.inference_microbenchmark_prefill_lengths.split(",")]
        programs = {}
        results.update({"prefill-result-sizes": {}, "prefill": {}, "insert": {}})
        for length in lengths:
            tokens, true_length = tokenizer.encode(
                config.prompt, is_bos=tokenizer.bos_id is not None, prefill_lengths=[length]
            )
            prefill = jax.jit(
                engine.prefill_aot, in_shardings=(engine.param_layouts, None, None, None)
            ).lower(
                params, jax.ShapeDtypeStruct([length], jax.numpy.int32),
                jax.ShapeDtypeStruct((), int), rng_shape,
            ).compile()
            insert = processor.aot_compile(params, length)
            require_same_formats(insert.output_formats[1], engine.decode_state_layouts, "prefill/insert output")
            require_same_formats(insert.input_formats[0][4], engine.decode_state_layouts, "prefill/insert input")
            programs[length] = (tokens, true_length, prefill, insert)
            results["prefill-result-sizes"][length] = benchmark.summarize_prefill_result(
                prefill, params, tokens, true_length
            )
        for length, (tokens, true_length, prefill, insert) in programs.items():
            results["prefill"][length] = benchmark.prefill_benchmark(
                config, prefill, params, tokens, true_length, num_params, iters
            )
            insert_time, decode_state = benchmark.prefill_insert_benchmark(
                config, insert, decode_state, params, engine.max_concurrent_decodes,
                tokens, true_length, iters,
            )
            results["insert"][length] = {
                "time_in_ms": insert_time["time_in_ms"] - results["prefill"][length]["time_in_ms"]
            }

    if "generate" in stages:
        require_same_formats(
            jax.tree.map(lambda x: x.format, decode_state),
            engine.decode_state_layouts, "runtime decode input",
        )
        results["autoregressive"], decode_state = benchmark.ar_benchmark(
            config, generate, params, decode_state, engine.max_concurrent_decodes,
            cache_size, model_size, iters,
        )

    results = benchmark.collate_results(config, results, model_size, cache_size, num_params)
    results["workload_runner"] = {
        "inference_aot_mode": "consistent",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_patches": [],
        "decode_input_output_formats_equal": True,
    }
    benchmark.print_results_for_analyze(results)
    if config.inference_microbenchmark_log_file_path:
        benchmark.write_results(results, config.inference_microbenchmark_log_file_path, False)
    if config.gcs_metrics:
        import os
        filename = f"{config.run_name}_results.txt"
        benchmark.write_results(results, filename, False)
        benchmark.upload_results_to_gcs(filename, os.path.join(config.base_output_directory, filename))
    return results


def main(argv):
    import jax
    from maxtext.configs import pyconfig

    jax.config.update("jax_default_prng_impl", "unsafe_rbg")
    config = pyconfig.initialize(argv)
    print("JAX_WORKLOADS_RUNNER inference_aot_mode=consistent source_patches=none", flush=True)
    print(json.dumps(run_benchmarks(config)), flush=True)


if __name__ == "__main__":
    from absl import app
    app.run(main)
