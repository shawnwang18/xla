"""
MaxText Test Configuration Profiles

This file contains different parameter configurations for MaxText tests.
You can select a configuration profile using the MAXTEXT_CONFIG environment variable.

Example:
    export MAXTEXT_CONFIG=small
    export MAXTEXT_CONFIG=large
    export MAXTEXT_CONFIG=debug
"""

import copy
import json
import os
import re
from datetime import datetime
from pathlib import Path

# Tensor name mapping for tensor offloading/saving
TENSOR_NAME_MAP = {
    "mlpwi": "mlpwi,mlpwi_0,mlpwi_1",
    "mlpwo": "mlpwo",
    "qwa": "mla_q",       # was query_wa_proj, renamed in maxtext-2026-03-02+
    "kvwa": "mla_kv",     # was kv_wa_proj, renamed in maxtext-2026-03-02+
    "qwb": "query_proj",
    "kwb": "key_proj",
    "vwb": "value_proj",
    "out": "out_proj",
    "context": "context",
}

def map_tensors(input_tensors):
    """
    Map tensor names to their expanded names based on TENSOR_NAME_MAP.

    Args:
        input_tensors: Comma-separated string of tensor names (e.g., "qwa,kvwa,mlpwi")

    Returns:
        List of expanded tensor names
    """
    if not input_tensors:
        return []

    offload_list = [t.strip() for t in input_tensors.split(",") if t.strip()]

    out_list = []
    for olt in offload_list:
        if olt in TENSOR_NAME_MAP:
            # Split the mapped value by comma and extend the list
            mapped_tensors = [
                t.strip() for t in TENSOR_NAME_MAP[olt].split(",") if t.strip()
            ]
            out_list.extend(mapped_tensors)
        else:
            # If not found in map, use the original name
            out_list.append(olt)

    return out_list


# Map tensors from environment variables
save_list = map_tensors(os.getenv("SAVE_TENSORS", ""))
offload_list = map_tensors(os.getenv("OFFLOAD_TENSORS", ""))

# Setup remat policy
TENSORS = [
    "mlpwi",
    "mlpwi_0",
    "mlpwi_1",
    "mlpwo",
    "query_proj",
    "key_proj",
    "value_proj",
    "mla_q",      # was query_wa_proj
    "mla_kv",     # was kv_wa_proj
    "out_proj",
    "context",
]

def get_remat_mapping(save_list_tensors, offload_list_tensors):
    """
    Generate REMAT_MAPPING string based on save_list and offload_list.

    Args:
        save_list_tensors: List of tensors to save
        offload_list_tensors: List of tensors to offload

    Returns:
        String representing the remat mapping
    """
    remat_mapping = []
    for tensor in TENSORS:
        value = "remat"
        if tensor in save_list_tensors:
            value = "device"
        elif tensor in offload_list_tensors:
            value = "offload"
        remat_mapping.append([tensor, value])
    return remat_mapping

# Shared base parameters for DeepSeek MoE models
_DEEPSEEK_BASE = {
    # Current MaxText defaults to pure NNX, but the FP8 MoE/AQT path still
    # requires the qualified Linen implementation in the July 22 image.
    "enable_nnx": "false",
    "pure_nnx": "false",
    "pure_nnx_decoder": "false",
    "scan_layers": "true",
    "per_device_batch_size": 2,
    "logits_dot_in_fp32": "false",
    "dataset_path": "local",
    "dataset_type": "synthetic",
    "n_routing_groups": -1,
    "topk_routing_group": -1,
    "capacity_factor": 1.0,
    "enable_goodput_recording": "false",
    "monitor_goodput": "false",
    "max_target_length": 4096,
    "attention": "dot_product",
    "megablox": "false",
    "quantization": "fp8",
    "sparse_matmul": "false",
    "weight_dtype": "bfloat16",
    "mu_dtype": "bfloat16",
    "use_iota_embed": "false",
}

MAXTEXT_LAUNCHER_DEEPSEEK_ENV_VARS = {
    "XLA_PJRT_GPU_HOST_MEMORY_PREALLOCATE": "false",
    "MAXTEXT_NVTE_UNSAFE_GROUPED_GEMM_USAGE_WITHOUT_TE_PERMUTE": "1",
}

# MaxText workload configurations
MAXTEXT_WORKLOAD_CONFIG = {
    # -------------------------------------------------------------------------
    # Llama2 family
    # -------------------------------------------------------------------------
    "llama2-7b-fp8": {
        "model_name": "llama2-7b",
        "max_target_length": 4096,
        "quantization": "fp8",
        "per_device_batch_size": 4,
        "scan_layers": "True",
    },
    "llama2-7b-fp16": {
        "model_name": "llama2-7b",
        "max_target_length": 4096,
        "per_device_batch_size": 4,
        "scan_layers": "False",
    },
    "llama2-7b-fp8-scanoff": {
        "model_name": "llama2-7b",
        "quantization": "fp8",
        "scan_layers": "False",
    },
    "llama2-13b-fp8": {
        "model_name": "llama2-13b",
        "quantization": "fp8",
        "scan_layers": "False",
    },
    "llama2-70b-fp8": {
        "model_name": "llama2-70b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
    },
    "llama2-7b-fp8-scan": {
        "model_name": "llama2-7b",
        "max_target_length": 4096,
        "quantization": "fp8",
        "per_device_batch_size": 4,
        "scan_layers": "True",
    },
    "llama2-7b-scan": {
        "model_name": "llama2-7b",
        "max_target_length": 4096,
        "per_device_batch_size": 4,
        "scan_layers": "True",
    },

    # -------------------------------------------------------------------------
    # Llama3 / Llama3.1 / Llama3.3 family
    # -------------------------------------------------------------------------
    "llama3-8b-fp8": {
        "model_name": "llama3-8b",
        "max_target_length": 8192,
        "quantization": "fp8",
        "per_device_batch_size": 2,
        "scan_layers": "False",
    },
    "llama3-8b-fp16": {
        "model_name": "llama3-8b",
        "max_target_length": 8192,
        "per_device_batch_size": 2,
        "scan_layers": "False",
    },
    "llama3-8b-fp8-scanoff": {
        "model_name": "llama3-8b",
        "quantization": "fp8",
        "scan_layers": "False",
    },
    "llama3-8b-fp8-scan": {
        "model_name": "llama3-8b",
        "max_target_length": 8192,
        "quantization": "fp8",
        "per_device_batch_size": 2,
        "scan_layers": "True",
    },
    "llama3-8b-fp16-scan": {
        "model_name": "llama3-8b",
        "max_target_length": 8192,
        "per_device_batch_size": 2,
        "scan_layers": "True",
    },
    "llama3-70b-fp8": {
        "model_name": "llama3-70b",
        "quantization": "fp8",
        "scan_layers": "False",
    },
    "llama3-70b-fp16": {
        "model_name": "llama3-70b",
        "max_target_length": 4096,
        "quantization": "fp8",
        "per_device_batch_size": 4,
        "scan_layers": "True",
        "remat_policy": "full",
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "llama3.1-8b-fp8": {
        "model_name": "llama3.1-8b",
        "quantization": "fp8",
        "scan_layers": "False",
    },
    "llama3.1-8b-fp16": {
        "model_name": "llama3.1-8b",
        "max_target_length": 4096,
        "quantization": "fp8",
        "per_device_batch_size": 8,
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "llama3.1-70b-fp8": {
        "model_name": "llama3.1-70b",
        "quantization": "fp8",
        "scan_layers": "False",
    },
    "llama3.1-70b-fp16": {
        "model_name": "llama3.1-70b",
        "max_target_length": 4096,  # 8192 causes 220GB OOM with dot_product attention
        "quantization": "fp8",
        "per_device_batch_size": 4,
        "scan_layers": "True",
        "remat_policy": "full",
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "llama3.1-405b-fp8": {
        "model_name": "llama3.1-405b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,  # 8192 causes 138 GiB OOM with dot_product+remat=full
        "dataset_type": "synthetic",
        "attention": "dot_product",
        "logits_dot_in_fp32": "false",
    },
    "llama3.1-405b": {
        "model_name": "llama3.1-405b",
        "use_iota_embed": "true",
        "per_device_batch_size": 1,
        "remat_policy": "save_qkv_proj",
        "enable_checkpointing": "false",
        "logits_dot_in_fp32": "false",
        "dataset_path": "local",
        "dataset_type": "synthetic",
        "attention": "dot_product",
        "max_target_length": 4096,  # 8192 causes 138 GiB OOM
        "enable_goodput_recording": "false",
        "monitor_goodput": "false",
    },
    "llama3.3-70b-fp8": {
        "model_name": "llama3.3-70b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
    },

    # -------------------------------------------------------------------------
    # Llama4 family (MoE)
    # -------------------------------------------------------------------------
    "llama4-17b-16e": {
        "model_name": "llama4-17b-16e",
        "quantization": "",  # fp8+sparse_matmul hits quant_dg bug
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 2,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "megablox": "False",  # megablox=True (default) uses qwix pallas which isn't supported in container
        "sparse_matmul": "False",
        # xla_config="no_double_buffer" needed: xla_gpu_enable_while_loop_double_buffering=true OOMs ~192GiB
        # with 48-layer scan by double-buffering all attention weight matrices simultaneously
    },
    "llama4-17b-128e": {
        "model_name": "llama4-17b-128e",
        "quantization": "",  # fp8+sparse_matmul hits quant_dg bug
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "megablox": "False",  # megablox=True (default) uses qwix pallas which isn't supported in container
        "sparse_matmul": "False",
        # xla_config="no_double_buffer" needed: xla_gpu_enable_while_loop_double_buffering=true OOMs ~388GiB
        # with 48-layer scan by double-buffering all attention weight matrices simultaneously
    },
    # scan_layers=False variants: unroll layers to eliminate scan backward gradient accumulation buffer.
    # Hypothesis: scan=True causes XLA to allocate a [48_layers × unsharded_per_layer_weight] buffer
    # (~145 GiB for llama4-17b-16e) during backward. With scan=False, XLA unrolls the loop and
    # each layer's backward is computed independently, capping peak memory at one layer at a time.
    "llama4-17b-16e-noscan": {
        "model_name": "llama4-17b-16e",
        "quantization": "",
        "scan_layers": "False",
        "remat_policy": "full",
        "per_device_batch_size": 2,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "megablox": "False",
        "sparse_matmul": "False",
    },
    "llama4-17b-128e-noscan": {
        "model_name": "llama4-17b-128e",
        "quantization": "",
        "scan_layers": "False",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "megablox": "False",
        "sparse_matmul": "False",
    },
    # Variant for PGLE nsys capture: skip=0, profiler_steps=1.
    # Rationale: PGLE test.sh phase disables async collectives, causing OOM at
    # buffer_and_write_train_metrics. With skip=0, cudaProfilerStart at step 0,
    # cudaProfilerStop at step 0 (before metric write). nsys saves report before
    # the OOM crash at metrics. This gives a valid nsys-rep for PGLE conversion.
    "llama4-17b-128e-noscan-pgle": {
        "model_name": "llama4-17b-128e",
        "quantization": "",
        "scan_layers": "False",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "megablox": "False",
        "sparse_matmul": "False",
        "skip_first_n_steps_for_profiler": 0,
        "profiler_steps": 1,
        # profile_cleanly=False: skip jax.block_until_ready() inside activate()/deactivate().
        # Without this, deactivate() calls block_until_ready(new_state) BEFORE cudaProfilerStop(),
        # and if the training step OOMs with PGLE sync collectives, the OOM surfaces inside
        # deactivate() before cudaProfilerStop() is ever called → nsys generates nothing.
        # With profile_cleanly=False, cudaProfilerStop() is called immediately on process 0,
        # and the OOM defers to step 1 (metric writes) — after the nsys stop signal is sent.
        "profile_cleanly": "False",
    },

    # -------------------------------------------------------------------------
    # Mistral / Mixtral family
    # -------------------------------------------------------------------------
    "mistral-7b-fp8": {
        "model_name": "mistral-7b",
        "quantization": "fp8",
    },
    "mixtral-8x7b": {
        "model_name": "mixtral-8x7b",
        "quantization": "fp8",
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "sparse_matmul": "False",
    },
    "mixtral-8x22b": {
        "model_name": "mixtral-8x22b",
        "quantization": "fp8",
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "sparse_matmul": "False",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
    },

    # -------------------------------------------------------------------------
    # Gemma2 family
    # -------------------------------------------------------------------------
    "gemma2-27b-fp8": {
        "model_name": "gemma2-27b",
        "quantization": "fp8",
    },
    "gemma2-2b-fp8": {
        "model_name": "gemma2-2b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 12,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "gemma2-9b-fp8": {
        "model_name": "gemma2-9b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 6,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },

    # -------------------------------------------------------------------------
    # Gemma (v1) family
    # -------------------------------------------------------------------------
    "gemma-2b-fp8": {
        "model_name": "gemma-2b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 12,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "gemma-7b-fp8": {
        "model_name": "gemma-7b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 6,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },

    # -------------------------------------------------------------------------
    # Gemma3 family
    # -------------------------------------------------------------------------
    "gemma3-4b-fp8": {
        "model_name": "gemma3-4b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 8,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "gemma3-12b-fp8": {
        "model_name": "gemma3-12b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 4,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "gemma3-27b-fp8": {
        "model_name": "gemma3-27b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 2,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },

    # -------------------------------------------------------------------------
    # GPT-3 family
    # -------------------------------------------------------------------------
    "gpt3-175b-fp8": {
        "model_name": "gpt3-175b",
        "quantization": "fp8",
        "attention": "dot_product",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
    },
    "gpt3-22b-fp8": {
        "model_name": "gpt3-22b",
        "quantization": "fp8",
        "attention": "dot_product",
    },
    "gpt3-6b-fp8": {
        "model_name": "gpt3-6b",
        "quantization": "fp8",
        "attention": "dot_product",
    },
    "gpt3-52k-fp8": {
        "model_name": "gpt3-52k",
        "quantization": "fp8",
    },

    # -------------------------------------------------------------------------
    # GPT-OSS family (MoE)
    # -------------------------------------------------------------------------
    "gpt-oss-20b": {
        "model_name": "gpt-oss-20b",
        "quantization": "fp8",
        # Current MaxText defaults these NNX paths to true, but the GPT-OSS
        # AQT MoE path still requires the qualified Linen implementation.
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 4,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
        "sparse_matmul": "False",
    },
    "gpt-oss-120b": {
        "model_name": "gpt-oss-120b",
        "quantization": "",  # fp8+sparse_matmul hits quant_dg bug
        # Keep the qualified Linen implementation instead of current MaxText's
        # NNX defaults; the GPT-OSS MoE path is not yet NNX-compatible here.
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",  # autoselected→GPU pallas flash fails for attention_sink=True; dot_product handles sinks
        "logits_dot_in_fp32": "false",
        "megablox": "False",  # megablox=True (default) uses qwix pallas which isn't supported in container
        "sparse_matmul": "False",
        # capacity_factor: gpt-oss model validates capacity_factor=-1 only (dropless with dense matmul)
        # AlltoAll OOM: XLA SPMD inserts AlltoAll to reshard [B,S,E,H] intermediate during scan backward.
        # With default wi_kernel_axes=("exp","embed_no_exp","mlp") and expert_parallelism=1, E is unsharded
        # so intermediate [1,4096,128,2880]=3GiB is replicated; NCCL AlltoAll buffer for 3GiB OOMs.
    },
    # gpt-oss-120b with shard_exp_on_fsdp=True: E sharded on fsdp axis (128/64=2 experts per GPU).
    # Changes wi_kernel_axes to ("embed_no_exp", None, "mlp") → E on fsdp, M unsharded.
    # Hypothesis: sharding E across fsdp reduces BSEH intermediate from 3GiB to 48MB per GPU,
    # eliminating the AlltoAll OOM from [B,S,E,H] resharding during scan backward.
    "gpt-oss-120b-shard-exp": {
        "model_name": "gpt-oss-120b",
        "quantization": "",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
        "logits_dot_in_fp32": "false",
        "megablox": "False",
        "sparse_matmul": "False",
        "shard_exp_on_fsdp": "True",  # E on fsdp, M unsharded; requires num_experts % ici_fsdp == 0
    },

    # -------------------------------------------------------------------------
    # OLMo3 family
    # -------------------------------------------------------------------------
    "olmo3-7b-fp8": {
        "model_name": "olmo3-7b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 6,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "olmo3-32b-fp8": {
        "model_name": "olmo3-32b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 2,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },

    # -------------------------------------------------------------------------
    # Qwen3 dense family
    # -------------------------------------------------------------------------
    "qwen3-0.6b-fp8": {
        "model_name": "qwen3-0.6b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 12,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "qwen3-4b-fp8": {
        "model_name": "qwen3-4b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 8,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "qwen3-8b-fp8": {
        "model_name": "qwen3-8b",
        "quantization": "fp8",
        "scan_layers": "False",
        "remat_policy": "minimal_with_context",
        "per_device_batch_size": 6,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "qwen3-14b-fp8": {
        "model_name": "qwen3-14b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 4,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },
    "qwen3-32b-fp8": {
        "model_name": "qwen3-32b",
        "quantization": "fp8",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 2,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
    },

    # -------------------------------------------------------------------------
    # Qwen3 MoE family
    # -------------------------------------------------------------------------
    "qwen3-30b-a3b": {
        "model_name": "qwen3-30b-a3b",
        "quantization": "fp8",
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 4,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
        "sparse_matmul": "False",
    },
    "qwen3-235b-a22b": {
        "model_name": "qwen3-235b-a22b",
        "quantization": "fp8",
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "scan_layers": "True",
        "remat_policy": "full",
        "per_device_batch_size": 1,
        "max_target_length": 4096,
        "dataset_type": "synthetic",
        "attention": "dot_product",
        "logits_dot_in_fp32": "false",
        "sparse_matmul": "False",
    },

    # -------------------------------------------------------------------------
    # DeepSeek family
    # -------------------------------------------------------------------------
    "deepseek2-16b": {
        "model_name": "deepseek2-16b",
        "quantization": "fp8",
        "enable_nnx": "false",
        "pure_nnx": "false",
        "pure_nnx_decoder": "false",
        "sparse_matmul": "False",
        "attention": "dot_product",
    },
    "deepseek2-236b": {
        **_DEEPSEEK_BASE,
        "model_name": "deepseek2-236b",
        # sparse_matmul=False (default from _DEEPSEEK_BASE) works fine with 8 nodes (32 GPUs)
    },
    "deepseek3-671b-custom": {
        **_DEEPSEEK_BASE,
        "model_name": "deepseek3-671b",
        "remat_policy": "custom",
        **dict(
            get_remat_mapping(
                map_tensors("out"), map_tensors("qwa,kvwa,mlpwi,mlpwo")
            )
        ),
        # te_grouped_gemm removed: not a valid field in maxtext-2026-03-02+ container
    },
    "deepseek3-671b": {
        **_DEEPSEEK_BASE,
        "model_name": "deepseek3-671b",
        "remat_policy": "custom",
    },
    "deepseek3.2-671b": {
        **_DEEPSEEK_BASE,
        "model_name": "deepseek3.2-671b",
        # DeepSeek-V3.2 enables the indexer by default.  The container default
        # leaves sparse indexer training disabled with a zero loss scale,
        # producing a constant-zero loss that XLA optimizes to a no-op.
        "indexer_sparse_training": "true",
        "indexer_loss_scaling_factor": 0.01,
        # Sparse indexer training adds enough live state that batch 2 exceeds
        # the GB300 VMM physical-allocation budget in the July 22 image.
        "per_device_batch_size": 1,
        "remat_policy": "custom",
        **dict(
            get_remat_mapping(
                map_tensors("out"), map_tensors("qwa,kvwa,mlpwi,mlpwo")
            )
        ),
        # te_grouped_gemm removed: not a valid field in maxtext-2026-03-02+ container
    },
    "deepseek3-671b-2dfsdp": {
        **_DEEPSEEK_BASE,
        "model_name": "deepseek3-671b-2dfsdp",
        "remat_policy": "custom",
        **dict(
            get_remat_mapping(
                map_tensors("out"), map_tensors("qwa,kvwa,mlpwi,mlpwo")
            )
        ),
        # te_grouped_gemm removed: not a valid field in maxtext-2026-03-02+ container
    },

    # -------------------------------------------------------------------------
    # Kimi K2 family
    # -------------------------------------------------------------------------
    "kimi-k2-1t": {
        **_DEEPSEEK_BASE,
        "model_name": "kimi-k2-1t",
        "remat_policy": "custom",
        "per_device_batch_size": 1,
        "max_target_length": 2048,
        **dict(
            get_remat_mapping(
                map_tensors("out"), map_tensors("qwa,kvwa,mlpwi,mlpwo")
            )
        ),
        # te_grouped_gemm removed: not a valid field in maxtext-2026-03-02+ container
    },

    # -------------------------------------------------------------------------
    # Imported from abgoel/maxtext-launcher configs/models
    # abgoel/merge-te-gmm-dsv3-hybridep @ f6657572a131...
    # -------------------------------------------------------------------------
    "launcher-llama3-8b": {
        "model_name": "llama3-8b",
        "max_target_length": 8192,
        "per_device_batch_size": 2,
        "gradient_accumulation_steps": 1,
        "attention": "cudnn_flash_te",
        "remat_policy": "minimal_with_context",
        "quantization": "",
        "scan_layers": "false",
        "zero_one": "false",
        "shard_optimizer_over_data": "false",
    },
    "launcher-llama3-70b": {
        "model_name": "llama3-70b",
        "max_target_length": 8192,
        "per_device_batch_size": 1,
        "gradient_accumulation_steps": 1,
        "attention": "cudnn_flash_te",
        "remat_policy": "save_dot_except_mlpwi",
        "quantization": "",
        "scan_layers": "false",
        "zero_one": "false",
        "shard_optimizer_over_data": "false",
    },
    "launcher-llama3.1-405b": {
        "model_name": "llama3.1-405b",
        "max_target_length": 8192,
        "per_device_batch_size": 1,
        "gradient_accumulation_steps": 1,
        "attention": "cudnn_flash_te",
        "remat_policy": "save_dot_except_mlpwi",
        "quantization": "",
        "scan_layers": "false",
        "zero_one": "false",
        "shard_optimizer_over_data": "false",
    },
    "launcher-mixtral-8x7b": {
        "model_name": "mixtral-8x7b",
        "max_target_length": 4096,
        "per_device_batch_size": 2,
        "gradient_accumulation_steps": 1,
        "attention": "cudnn_flash_te",
        "remat_policy": "save_dot_except_mlpwi",
        "quantization": "",
        "scan_layers": "false",
        "zero_one": "false",
        "sparse_matmul": "false",
        "shard_optimizer_over_data": "false",
    },
    "launcher-deepseek-v3-671b": {
        "model_name": "deepseek3-671b",
        "tokenizer_path": "src/MaxText/assets/tokenizers/deepseek-v3-tokenizer",
        "tokenizer_type": "huggingface",
        "max_target_length": 4096,
        "per_device_batch_size": 6,
        "gradient_accumulation_steps": 1,
        "attention": "cudnn_flash_te",
        "remat_policy": "custom",
        "quantization": "te_fp8_currentscaling",
        "te_router_and_permutation_impl": "false",
        "moe_permutation_group_align_size": 128,
        "te_use_gmm": "true",
        "te_gmm_quantization": "te_mxfp8",
        "weight_dtype": "bfloat16",
        "mu_dtype": "bfloat16",
        "scan_layers": "true",
        "zero_one": "false",
        "shardy": "true",
        "skip_first_n_steps_for_profiler": 4,
        "custom_remat_enabled": "true",
        "logits_dot_in_fp32": "false",
        "use_iota_embed": "false",
        "mlpwi": "device",
        "mlpwi_0": "device",
        "mlpwi_1": "device",
        "mlpwo": "device",
        "moe_mlpwi_0": "remat",
        "moe_mlpwi_1": "remat",
        "moe_mlpwo": "remat",
        "query_proj": "offload",
        "key_proj": "remat",
        "value_proj": "offload",
        "query_wa_proj": "device",
        "kv_wa_proj": "device",
        "out_proj": "device",
        "context": "device",
        "use_ring_of_experts": "false",
        "use_hybrid_ep": "true",
        "hybrid_ep_pad_multiple": 128,
        "n_routing_groups": -1,
        "topk_routing_group": -1,
        "capacity_factor": 1.0,
        "megablox": "false",
        "jax_deep_ep_dir": "/lustre/fsw/coreai_dlcompiler_ci/abgoel/my_code/jax_deep_ep",
        "shard_optimizer_over_data": "false",
        "fused_moe_mlp": "true",
        "fused_mla_lora_proj": "false",
    },
}

MAXTEXT_CONTAINER_CONFIGS = {
    #MAXTEXT container
    40 : "gitlab-master.nvidia.com/dl/dgx/jax:maxtext-2026-03-02",
    41 : "gitlab-master.nvidia.com/dl/dgx/jax:maxtext-47317509",
    42 : "gitlab-master.nvidia.com/dl/dgx/jax:maxtext-2026-05-04",
    43: "gitlab-master.nvidia.com/dl/dgx/jax:maxtext-53501225",
    44: "gitlab-master.nvidia.com/abgoel/paxml-containers:maxtext-05-04-2025-hybridep",
}

AR_THRESHOLD = 33554432
AG_THRESHOLD = 33554432
RS_THRESHOLD = 33554432

MAXTEXT_XLA_CONFIGS = {
    "maxtext_launcher": [],

    "maxtext_launcher_llama3_70b": [
        "--xla_gpu_all_gather_combine_threshold_bytes=956301312",
        "--xla_gpu_reduce_scatter_combine_threshold_bytes=59768832",
    ],

    "maxtext_launcher_llama3_405b": [
        "--xla_gpu_all_gather_combine_threshold_bytes=1879048192",
        "--xla_gpu_reduce_scatter_combine_threshold_bytes=58720256",
    ],

    "maxtext_launcher_deepseek_v3": [
        "--xla_gpu_all_reduce_combine_threshold_bytes=33554432",
        "--xla_gpu_all_gather_combine_threshold_bytes=6442450944",
        "--xla_gpu_reduce_scatter_combine_threshold_bytes=201326592",
        "--xla_gpu_experimental_enable_nccl_symmetric_buffers=false",
        "--xla_gpu_experimental_use_ragged_dot_fusion=true",
        "--xla_gpu_enable_command_buffer=FUSION,CUBLAS,CUDNN,CUSTOM_CALL,DYNAMIC_SLICE_FUSION",
        "--xla_gpu_enable_cublaslt=false",
    ],

    "default": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=true",
        "--xla_gpu_enable_pipelined_reduce_scatter=true",
        "--xla_gpu_enable_pipelined_all_reduce=true",
        "--xla_gpu_enable_while_loop_double_buffering=true",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        "--xla_disable_hlo_passes=rematerialization",
        "--xla_gpu_experimental_parallel_collective_overlap_limit=9",
        "--xla_gpu_shard_autotuning=false",
    ],

    "temp_async_allocator": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=true",
        "--xla_gpu_enable_pipelined_reduce_scatter=true",
        "--xla_gpu_enable_pipelined_all_reduce=true",
        "--xla_gpu_enable_while_loop_double_buffering=true",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        "--xla_disable_hlo_passes=rematerialization",
        "--xla_gpu_experimental_parallel_collective_overlap_limit=9",
        "--xla_gpu_temp_buffer_use_separate_color=1",
    ],

    # Like "default" but with while_loop_double_buffering disabled to prevent
    # XLA from double-buffering scan loop activations for large MoE models
    # (llama4 48-layer scan causes ~192GiB OOM with double buffering on 8 GPUs)
    "no_double_buffer": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=true",
        "--xla_gpu_enable_pipelined_reduce_scatter=true",
        "--xla_gpu_enable_pipelined_all_reduce=true",
        "--xla_gpu_enable_while_loop_double_buffering=false",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        "--xla_disable_hlo_passes=rematerialization",
        "--xla_gpu_experimental_parallel_collective_overlap_limit=9",
        "--xla_gpu_shard_autotuning=false",
    ],

    # No pipelining: disables all pipelined collectives + double buffering.
    # For large MoE with FSDP + scan: pipelined all-gather allows multiple
    # layers' weights to be prefetched simultaneously, causing OOM even with
    # double_buffering=false. Sequential execution (1 layer at a time) caps
    # peak memory at ~3 GiB per layer (one all-gather buffer at a time).
    "no_pipelining": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=false",
        "--xla_gpu_enable_pipelined_reduce_scatter=false",
        "--xla_gpu_enable_pipelined_all_reduce=false",
        "--xla_gpu_enable_while_loop_double_buffering=false",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        "--xla_disable_hlo_passes=rematerialization",
        "--xla_gpu_experimental_parallel_collective_overlap_limit=1",
        "--xla_gpu_shard_autotuning=false",
    ],

    # Like no_pipelining but WITHOUT xla_disable_hlo_passes=rematerialization.
    # Allows XLA's own memory optimization pass to break up large live tensors
    # (e.g. scan backward gradient accumulation buffer ~145GiB for llama4-17b-16e)
    # by recomputing them instead of keeping them live. XLA remat operates on the
    # post-SPMD HLO, so it can see and remat large pipelined buffers that JAX-level
    # remat_policy=full doesn't cover (XLA-inserted allgather prefetch buffers).
    "no_pipelining_xla_remat": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=false",
        "--xla_gpu_enable_pipelined_reduce_scatter=false",
        "--xla_gpu_enable_pipelined_all_reduce=false",
        "--xla_gpu_enable_while_loop_double_buffering=false",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        # NOTE: no --xla_disable_hlo_passes=rematerialization here — allows XLA remat
        "--xla_gpu_experimental_parallel_collective_overlap_limit=1",
        "--xla_gpu_shard_autotuning=false",
    ],

    # Like no_pipelining but forces AllGather to run synchronously.
    # With noscan (unrolled layers), XLA's memory planner schedules all 24 MoE
    # layer AllGathers simultaneously, requiring a 243 GiB preallocated-temp
    # buffer that exceeds the 172 GiB pool. Disabling async AllGather forces
    # sequential execution: one AllGather at a time → ~10 GiB peak per layer
    # instead of 24×10 GiB = 243 GiB all at once.
    "no_pipelining_noscan": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=false",
        "--xla_gpu_enable_pipelined_reduce_scatter=false",
        "--xla_gpu_enable_pipelined_all_reduce=false",
        "--xla_gpu_enable_while_loop_double_buffering=false",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        "--xla_disable_hlo_passes=rematerialization",
        "--xla_gpu_experimental_parallel_collective_overlap_limit=1",
        "--xla_gpu_shard_autotuning=false",
        # Force sync AllGather: prevents 24 MoE layer AG outputs from being
        # simultaneously pre-allocated (which would require 243 GiB).
        "--xla_gpu_disable_async_collectives=ALLGATHER",
    ],

    # Like no_pipelining but WITHOUT --xla_gpu_shard_autotuning=false.
    # Used for 2dfsdp on ptyche/lyris where shard_autotuning=false causes
    # cuBLAS to request workspace for the UNSHARDED (16× enlarged) tensor:
    # ici_fsdp=4 × dcn_fsdp_t=4 × per_shard_weight ≈ 224 GiB → exceeds the
    # 173 GiB BFC pool → cuBLAS gets a NULL workspace pointer → SIGSEGV.
    # With shard_autotuning enabled (default), cuBLAS sees the per-shard
    # tensor size (224/16 = 14 GiB) and allocates a proportionally smaller
    # workspace that fits in the pool.
    "no_pipelining_shard_autotune": [
        "--xla_gpu_nccl_termination_timeout_seconds=120000000",
        "--xla_disable_hlo_passes=hlo-verifier",
        "--xla_gpu_enable_triton_gemm=false",
        "--xla_gpu_enable_highest_priority_async_stream=true",
        "--xla_gpu_all_reduce_combine_threshold_bytes={}".format(AR_THRESHOLD),
        "--xla_gpu_all_gather_combine_threshold_bytes={}".format(AG_THRESHOLD),
        "--xla_gpu_reduce_scatter_combine_threshold_bytes={}".format(RS_THRESHOLD),
        "--xla_gpu_enable_pipelined_all_gather=false",
        "--xla_gpu_enable_pipelined_reduce_scatter=false",
        "--xla_gpu_enable_pipelined_all_reduce=false",
        "--xla_gpu_enable_while_loop_double_buffering=false",
        "--xla_gpu_enable_all_gather_combine_by_dim=false",
        "--xla_gpu_enable_reduce_scatter_combine_by_dim=false",
        "--xla_disable_hlo_passes=rematerialization",
        "--xla_gpu_experimental_parallel_collective_overlap_limit=1",
        # Explicitly enable shard autotuning so cuBLAS workspace is based on
        # the per-shard (per-device) tensor size, not the unsharded tensor.
        # Default for xla_gpu_shard_autotuning is false, so we must set it
        # explicitly to avoid the 224 GiB cuBLAS workspace → SIGSEGV crash.
        "--xla_gpu_shard_autotuning=true",
    ],
}

def maxtext_workload_to_cmd_args(kwargs):

    if kwargs["model"] not in MAXTEXT_WORKLOAD_CONFIG:
        raise ValueError(
            f"Config {kwargs['model']} not found in MAXTEXT_WORKLOAD_CONFIG"
        )

    workload = dict(MAXTEXT_WORKLOAD_CONFIG[kwargs["model"]])
    if kwargs.get("maxtext_runner", "train") != "inference":
        workload.setdefault("learning_rate", "1e-7")
        workload.setdefault("abort_on_nan_loss", "false")
        workload.setdefault("abort_on_inf_loss", "false")
    metadata_keys = {"workload_type", "maxtext_runner"}
    cmd_args = [
        f"{key}={value}"
        for key, value in workload.items()
        if value is not None and key not in metadata_keys and not key.startswith("_")
    ]

    cmd_args.append(f"dcn_data_parallelism={kwargs['dcn_data']}")
    cmd_args.append(f"dcn_fsdp_parallelism={kwargs['dcn_fsdp']}")
    cmd_args.append(f"dcn_fsdp_transpose_parallelism={kwargs['dcn_fsdp_t']}")
    cmd_args.append(f"dcn_pipeline_parallelism={kwargs['dcn_pipe']}")
    cmd_args.append(f"dcn_expert_parallelism={kwargs['dcn_expert']}")
    cmd_args.append(f"ici_data_parallelism={kwargs['ici_data']}")
    cmd_args.append(f"ici_fsdp_parallelism={kwargs['ici_fsdp']}")
    cmd_args.append(f"ici_fsdp_transpose_parallelism={kwargs['ici_fsdp_t']}")
    cmd_args.append(f"ici_sequence_parallelism={kwargs['ici_seq']}")
    cmd_args.append(f"ici_tensor_parallelism={kwargs['ici_tensor']}")
    # Current MaxText removed the legacy tensor-transpose override. Every
    # bundled workload used its default value of 1, so omitting it preserves
    # the tested topology and remains compatible with older images.
    cmd_args.append(f"ici_tensor_sequence_parallelism={kwargs['ici_tensor_seq']}")
    cmd_args.append(f"ici_autoregressive_parallelism={kwargs['ici_auto']}")
    cmd_args.append(f"ici_pipeline_parallelism={kwargs['ici_pipe']}")
    cmd_args.append(f"ici_expert_parallelism={kwargs['ici_expert']}")
    if kwargs["cluster"] == "prenyx":
        return " ".join(["num_slices=" + str(kwargs["nodes"])] + cmd_args)
    else:
        # For ptyche/lyris, compute num_slices from DCN product when all dims are
        # explicitly set (positive). num_slices=-1 relies on JAX NVLink topology
        # auto-detection which can fail with non-contiguous node allocations (e.g.,
        # 32 nodes spanning 3 NVLink racks gives 42 devices/slice instead of 32).
        dcn_dims = [kwargs["dcn_data"], kwargs["dcn_fsdp"], kwargs["dcn_fsdp_t"],
                    kwargs["dcn_pipe"], kwargs["dcn_expert"]]
        if all(d > 0 for d in dcn_dims):
            num_slices = 1
            for d in dcn_dims:
                num_slices *= d
        else:
            num_slices = -1
        return " ".join(["num_slices=" + str(num_slices)] + cmd_args)

# Define different configuration profiles
def make_dict(
    cluster,
    model,
    xla_config=1,
    nodes=1,
    segment=1,
    dcn_data=1,
    dcn_fsdp= -1,
    dcn_fsdp_t=1,
    dcn_pipe=1,
    dcn_expert=1,
    ici_data= 1,
    ici_fsdp= 1,
    ici_fsdp_t= -1,
    ici_seq= 1,
    ici_tensor= 1,
    ici_tensor_t= 1,
    ici_tensor_seq= 1,
    ici_auto= 1,
    ici_pipe= 1,
    ici_expert= 1,
    mem_fraction=0.94,
    nvte_fused_attn=1,
    host_memory_gb=None,
    **kwargs,
):
    return dict(
        cluster=cluster,
        model=model,
        xla_config=xla_config,
        nodes=nodes,
        segment=segment,
        dcn_data=dcn_data,
        dcn_fsdp=dcn_fsdp,
        dcn_fsdp_t=dcn_fsdp_t,
        dcn_pipe=dcn_pipe,
        dcn_expert=dcn_expert,
        ici_data=ici_data,
        ici_fsdp=ici_fsdp,
        ici_fsdp_t=ici_fsdp_t,
        ici_seq=ici_seq,
        ici_tensor=ici_tensor,
        ici_tensor_t=ici_tensor_t,
        ici_tensor_seq=ici_tensor_seq,
        ici_auto=ici_auto,
        ici_pipe=ici_pipe,
        ici_expert=ici_expert,
        mem_fraction=mem_fraction,
        nvte_fused_attn=nvte_fused_attn,
        host_memory_gb=host_memory_gb,
        **kwargs,
    )

def _load_jax_ci_workloads():
    path = Path(__file__).resolve().parent / "jax_ci_workloads.json"
    if not path.exists():
        return {"workloads": {}, "config": {"param_dicts": []}}
    data = json.loads(path.read_text(encoding="utf-8"))
    config = data.get("config", {})
    for key, value in list(config.items()):
        if key != "param_dicts" and isinstance(value, list):
            config[key] = tuple(value)
    return {"workloads": data.get("workloads", {}), "config": config}


INFERENCE_CLUSTERS = {
    "prenyx": {"gpus_per_node": 8, "partition": "batch"},
    "ptyche": {"gpus_per_node": 4, "partition": "36x2-a01r"},
    "lyris": {"gpus_per_node": 4, "partition": "gb300"},
}


def _expand_inference_clusters(rows, workloads, qualification_jobs=None):
    """Place each inference GPU budget on the target cluster's physical nodes.

    Preserve imported CI provenance and all non-inference rows. A two-node
    Grace Blackwell allocation stays within one NVLink segment and JAX slice.
    The historical topology name remains an alias when placement changes.
    """
    qualification_jobs = qualification_jobs or {}
    expanded = [row for row in rows if row.get("maxtext_runner") != "inference"]
    recipes = {}
    for row in rows:
        if row.get("maxtext_runner") == "inference":
            recipes.setdefault(row["model"], row)
    for source_name, source in recipes.items():
        total_gpus = source.get("ci_gpus", source["nodes"] * source.get("tpn", 4))
        for cluster, topology in INFERENCE_CLUSTERS.items():
            row = copy.deepcopy(source)
            tpn = min(total_gpus, topology["gpus_per_node"])
            nodes = total_gpus // tpn
            if total_gpus % tpn:
                raise ValueError(f"cannot place {source_name} on {cluster}")
            name = re.sub(r"-\d+n\d+g$", f"-{nodes}n{tpn}g", source_name)
            workloads.setdefault(name, copy.deepcopy(workloads[source_name]))
            row.update(cluster=cluster, model=name, nodes=nodes, tpn=tpn,
                       segment=1 if cluster == "prenyx" else nodes,
                       partition=topology["partition"], validation="unqualified")
            row["workload_aliases"] = [source_name] if source_name != name else []
            if row.get("inference_mesh_axis") == "expert":
                # Prenyx hosts are separate slices; Grace Blackwell nodes in
                # one requested NVLink segment share a slice. Keep EP=total.
                row["dcn_expert"] = nodes if cluster == "prenyx" else 1
                row["ici_expert"] = tpn if cluster == "prenyx" else total_gpus
            if row.get("ci_kind") == "infer":
                row["ici_fsdp"] = total_gpus
                row["ci_original_workload"] = source_name
                row.setdefault("maxtext_config_path", "/opt/maxtext/src/maxtext/configs/base.yml")
            job_id = qualification_jobs.get((source_name, cluster))
            if job_id:
                row["validation"] = "qualified"
                row["qualification"] = {"cluster": cluster, "slurm_job_id": job_id, "container": 43}
            expanded.append(row)
    return expanded

def get_default_run_dir(mode):
    """Generate default run directory name."""
    date_str = datetime.now().strftime("%m%d")
    return f"maxtext_{mode}_{date_str}"

from config_utils import (
    get_config as _get_config,
    get_parameterized_product_args as _get_parameterized_product_args,
    list_available_configs as _list_available_configs,
    print_config_info as _print_config_info,
)

CONFIGS = {
    "default": {
        "param_dicts": [
            # ---- Llama2-7b ----
            make_dict("prenyx", "llama2-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama2-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama2-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama2-13b ----
            make_dict("prenyx", "llama2-13b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama2-13b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama2-13b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama2-70b ----
            make_dict("prenyx", "llama2-70b-fp8",  xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama2-70b-fp8",  xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama2-70b-fp8",  xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama3-8b ----
            make_dict("prenyx", "llama3-8b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama3-8b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama3-8b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama3-70b ----
            make_dict("prenyx", "llama3-70b-fp16", xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama3-70b-fp16", xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama3-70b-fp16", xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama3.1-8b ----
            make_dict("prenyx", "llama3.1-8b-fp16", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama3.1-8b-fp16", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama3.1-8b-fp16", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama3.1-70b ----
            make_dict("prenyx", "llama3.1-70b-fp16", xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama3.1-70b-fp16", xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama3.1-70b-fp16", xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama3.1-405b ----
            make_dict("prenyx", "llama3.1-405b-fp8", xla_config="default", nodes=16, segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama3.1-405b-fp8", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama3.1-405b-fp8", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama3.3-70b ----
            make_dict("prenyx", "llama3.3-70b-fp8", xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama3.3-70b-fp8", xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "llama3.3-70b-fp8", xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Llama4-17b-16e (MoE) ----
            # no_pipelining + mem_fraction=0.85 required on ptyche/lyris: default XLA pipelining
            # OOMs the scan backward buffer (~97 GiB at FSDP=32 fits BFC) but NCCL AlltoAll needs
            # ~15 GiB outside BFC. 8 nodes (32 GPUs), segment=8 (single ICI slice of 32 GPUs).
            # Verified working: fix_m (maxtext_run_0313s_ptyche), step 0-29 completed, nsys-rep generated.
            make_dict("prenyx", "llama4-17b-16e",  xla_config="no_pipelining", nodes=8,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),
            make_dict("ptyche", "llama4-17b-16e",  xla_config="no_pipelining", nodes=8,  segment=8,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),
            make_dict("lyris",  "llama4-17b-16e",  xla_config="no_pipelining", nodes=8,  segment=8,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),


            # ---- Mixtral-8x7b ----
            make_dict("prenyx", "mixtral-8x7b",    xla_config="default", nodes=4,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "mixtral-8x7b",    xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "mixtral-8x7b",    xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Mixtral-8x22b ----
            make_dict("prenyx", "mixtral-8x22b",   xla_config="default", nodes=16, segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "mixtral-8x22b",   xla_config="default", nodes=16, segment=8,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "mixtral-8x22b",   xla_config="default", nodes=16, segment=8,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Mistral-7b ----
            make_dict("prenyx", "mistral-7b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "mistral-7b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "mistral-7b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma-2b ----
            make_dict("prenyx", "gemma-2b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma-2b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma-2b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma-7b ----
            make_dict("prenyx", "gemma-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma2-2b ----
            make_dict("prenyx", "gemma2-2b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma2-2b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma2-2b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma2-9b ----
            make_dict("prenyx", "gemma2-9b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma2-9b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma2-9b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma2-27b ----
            make_dict("prenyx", "gemma2-27b-fp8", xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma2-27b-fp8", xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma2-27b-fp8", xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma3-4b ----
            make_dict("prenyx", "gemma3-4b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma3-4b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma3-4b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma3-12b ----
            make_dict("prenyx", "gemma3-12b-fp8", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma3-12b-fp8", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma3-12b-fp8", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Gemma3-27b ----
            make_dict("prenyx", "gemma3-27b-fp8", xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gemma3-27b-fp8", xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gemma3-27b-fp8", xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- GPT3-6b ----
            make_dict("prenyx", "gpt3-6b-fp8",    xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gpt3-6b-fp8",    xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gpt3-6b-fp8",    xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- GPT3-22b ----
            make_dict("prenyx", "gpt3-22b-fp8",   xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gpt3-22b-fp8",   xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gpt3-22b-fp8",   xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- GPT3-175b ----
            make_dict("prenyx", "gpt3-175b-fp8",  xla_config="default", nodes=16, segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gpt3-175b-fp8",  xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gpt3-175b-fp8",  xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- GPT-OSS-20b (MoE) ----
            make_dict("prenyx", "gpt-oss-20b",    xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "gpt-oss-20b",    xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "gpt-oss-20b",    xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- GPT-OSS-120b (MoE) ----
            # no_pipelining required: default XLA pipelining causes NCCL AlltoAll OOM.
            # mem_fraction=0.85 required on ptyche/lyris: NCCL AlltoAll workspace needs
            # ~15 GiB free outside BFC; default 0.94 leaves too little room. Verified
            # working with fix_j (maxtext_run_0313p) generating nsys-rep at all 30 steps.
            make_dict("prenyx", "gpt-oss-120b",   xla_config="no_pipelining", nodes=8,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),
            make_dict("ptyche", "gpt-oss-120b",   xla_config="no_pipelining", nodes=16, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),
            make_dict("lyris",  "gpt-oss-120b",   xla_config="no_pipelining", nodes=16, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),

            # ---- OLMo3-7b ----
            make_dict("prenyx", "olmo3-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "olmo3-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "olmo3-7b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- OLMo3-32b ----
            make_dict("prenyx", "olmo3-32b-fp8",  xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "olmo3-32b-fp8",  xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "olmo3-32b-fp8",  xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-0.6b ----
            make_dict("prenyx", "qwen3-0.6b-fp8", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-0.6b-fp8", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-0.6b-fp8", xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-4b ----
            make_dict("prenyx", "qwen3-4b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-4b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-4b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-8b ----
            make_dict("prenyx", "qwen3-8b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-8b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-8b-fp8",   xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-14b ----
            make_dict("prenyx", "qwen3-14b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-14b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-14b-fp8",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-32b ----
            make_dict("prenyx", "qwen3-32b-fp8",  xla_config="default", nodes=2,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-32b-fp8",  xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-32b-fp8",  xla_config="default", nodes=2,  segment=2,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-30b-A3B (MoE) ----
            make_dict("prenyx", "qwen3-30b-a3b",  xla_config="default", nodes=4,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-30b-a3b",  xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-30b-a3b",  xla_config="default", nodes=4,  segment=4,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- Qwen3-235b-A22B (MoE) ----
            make_dict("prenyx", "qwen3-235b-a22b", xla_config="default", nodes=16, segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "qwen3-235b-a22b", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "qwen3-235b-a22b", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- DeepSeek2-16b (MoE) ----
            make_dict("prenyx", "deepseek2-16b",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "deepseek2-16b",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "deepseek2-16b",  xla_config="default", nodes=1,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # ---- DeepSeek2-236b (MoE) ----
            make_dict("prenyx", "deepseek2-236b", xla_config="default", nodes=8,  segment=1,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),
            make_dict("ptyche", "deepseek2-236b", xla_config="default", nodes=8,  segment=8,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.9),
            make_dict("lyris",  "deepseek2-236b", xla_config="default", nodes=8,  segment=8,  dcn_data=1, dcn_fsdp=-1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=-1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1, mem_fraction=0.85),

            # ---- DeepSeek3-671b (MoE) ----
            make_dict("prenyx", "deepseek3-671b", xla_config="default", nodes=32, segment=1,  dcn_data=1, dcn_fsdp=32, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=1,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8,  mem_fraction=0.85),
            make_dict("ptyche", "deepseek3-671b", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2,  dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=4,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16, mem_fraction=0.85),
            make_dict("lyris",  "deepseek3-671b", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2,  dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=4,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16, mem_fraction=0.85),

            # ---- Kimi-K2-1T (MoE) ----
            make_dict("prenyx", "kimi-k2-1t",     xla_config="no_pipelining", nodes=32, segment=1,  dcn_data=1, dcn_fsdp=32, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=1,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8,  mem_fraction=0.85),
            make_dict("ptyche", "kimi-k2-1t",     xla_config="no_pipelining", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2,  dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=4,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16, mem_fraction=0.85),
            make_dict("lyris",  "kimi-k2-1t",     xla_config="no_pipelining", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2,  dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1,  ici_fsdp=4,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16, mem_fraction=0.85),

            # ---- DeepSeek3.2-671b (MoE) ----
            # host_memory_gb=128 required: host OOM at 86.97 GiB without it.
            make_dict("prenyx", "deepseek3.2-671b", xla_config="default", nodes=32, segment=1,  dcn_data=1, dcn_fsdp=32, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8,  mem_fraction=0.85, host_memory_gb=128),
            make_dict("ptyche", "deepseek3.2-671b", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2,  dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=4,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16, mem_fraction=0.85, host_memory_gb=128),
            make_dict("lyris",  "deepseek3.2-671b", xla_config="default", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2,  dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=4,  ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16, mem_fraction=0.85, host_memory_gb=128),

            # ---- Llama4-17b-128e-noscan-pgle (ptyche only) ----
            # Training step completes; OOM at metrics write is expected (PGLE sync collectives).
            # nsys report is the deliverable and is saved before the OOM crash.
            make_dict("ptyche", "llama4-17b-128e-noscan-pgle", xla_config="no_pipelining", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=2, ici_fsdp_t=1, ici_seq=1, ici_tensor=8, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=4),
        ],
        "container": (43,),
        "allocator": ("bfc",),
        "maxtext": ("container",),
        "graph": ("CGOFF","UnrolledModel"),
        "steps":(30,),
        "time":(60,),
        "cuda_device_max_connections": (0,),
        "jaxlib": (0,),
        "pgle": (0,),
        "baseDir": ("results",),
        "script": ("slurm_run.sub",),
        "nccl": (0,),
        "NcclGraphMix": (1,),
        "NcclLink": (0,),
        "fmha": (1,),
        "LHS": (1,),
        "Exclusive": (0,),
        "Sanitizer": (0,),
        "bindpcie": (0,),
        "ScaleLaunchQueue": ("1x",),
        "NcclDebug": (0,),
        "XLADUMPS": (1,),
        "CMDBUFFERDUMP": (0,),
        "PROFILE": ("nsys",),
        "GDB": (0,),
        "Driver": (0,),
        "va_remapping": (0, 1, 2),
        "overwrite": (1,),
        "mode": (os.getenv("MAXTEXT_RUN", "perf"),),
        "runDir": (
            os.getenv(
                "MAXTEXT_RUN_DIR", get_default_run_dir(os.getenv("MAXTEXT_RUN", "perf"))
            ),
        ),
    },

    "maxtext_launcher": {
        "param_dicts": [
            # Source: configs/models/llama3-8b.yaml
            make_dict("prenyx", "launcher-llama3-8b", xla_config="maxtext_launcher", nodes=1, segment=1, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=4, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "launcher-llama3-8b", xla_config="maxtext_launcher", nodes=1, segment=1, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=4, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "launcher-llama3-8b", xla_config="maxtext_launcher", nodes=1, segment=1, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=4, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # Source: configs/models/llama3-70b.yaml
            make_dict("prenyx", "launcher-llama3-70b", xla_config="maxtext_launcher_llama3_70b", nodes=4, segment=1, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=16, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "launcher-llama3-70b", xla_config="maxtext_launcher_llama3_70b", nodes=4, segment=4, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=16, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "launcher-llama3-70b", xla_config="maxtext_launcher_llama3_70b", nodes=4, segment=4, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=16, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # Source: configs/models/llama3.1-405b.yaml
            make_dict("prenyx", "launcher-llama3.1-405b", xla_config="maxtext_launcher_llama3_405b", nodes=8, segment=1, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=32, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "launcher-llama3.1-405b", xla_config="maxtext_launcher_llama3_405b", nodes=8, segment=8, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=32, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("lyris",  "launcher-llama3.1-405b", xla_config="maxtext_launcher_llama3_405b", nodes=8, segment=8, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=32, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),

            # Source: configs/models/mixtral-8x7b.yaml
            make_dict("prenyx", "launcher-mixtral-8x7b", xla_config="maxtext_launcher", nodes=2, segment=1, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8),
            make_dict("ptyche", "launcher-mixtral-8x7b", xla_config="maxtext_launcher", nodes=2, segment=2, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8),
            make_dict("lyris",  "launcher-mixtral-8x7b", xla_config="maxtext_launcher", nodes=2, segment=2, dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8),

            # Source: configs/models/deepseek-v3-671b.yaml
            make_dict("prenyx", "launcher-deepseek-v3-671b", xla_config="maxtext_launcher_deepseek_v3", nodes=32, segment=1, dcn_data=1, dcn_fsdp=2, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=16, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=4, mem_fraction=0.88, cuda_device_max_connections=16, host_memory_gb=180, pgle=1, container=44, env_vars=MAXTEXT_LAUNCHER_DEEPSEEK_ENV_VARS),
            make_dict("ptyche", "launcher-deepseek-v3-671b", xla_config="maxtext_launcher_deepseek_v3", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=16, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=4, mem_fraction=0.88, cuda_device_max_connections=16, host_memory_gb=180, pgle=1, container=44, env_vars=MAXTEXT_LAUNCHER_DEEPSEEK_ENV_VARS),
            make_dict("lyris",  "launcher-deepseek-v3-671b", xla_config="maxtext_launcher_deepseek_v3", nodes=32, segment=16, dcn_data=1, dcn_fsdp=2, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=16, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=4, mem_fraction=0.88, cuda_device_max_connections=16, host_memory_gb=180, pgle=1, container=44, env_vars=MAXTEXT_LAUNCHER_DEEPSEEK_ENV_VARS),
        ],
        "container": (43,),
        "allocator": ("bfc",),
        "maxtext": ("container",),
        "graph": ("CGOFF","UnrolledModel"),
        "steps":(30,),
        "time":(60,),
        "cuda_device_max_connections": (0,),
        "jaxlib": (0,),
        "pgle": (0,),
        "baseDir": ("results",),
        "script": ("slurm_run.sub",),
        "nccl": (0,),
        "NcclGraphMix": (1,),
        "NcclLink": (0,),
        "fmha": (1,),
        "LHS": (1,),
        "Exclusive": (0,),
        "Sanitizer": (0,),
        "bindpcie": (0,),
        "ScaleLaunchQueue": ("1x",),
        "NcclDebug": (0,),
        "XLADUMPS": (1,),
        "CMDBUFFERDUMP": (0,),
        "PROFILE": ("nsys",),
        "GDB": (0,),
        "Driver": (0,),
        "va_remapping": (0, 1, 2),
        "overwrite": (1,),
        "mode": (os.getenv("MAXTEXT_RUN", "perf"),),
        "runDir": (
            os.getenv(
                "MAXTEXT_RUN_DIR", get_default_run_dir(os.getenv("MAXTEXT_RUN", "perf"))
            ),
        ),
    },

    # Configs that are currently failing and need investigation.
    "failing": {
        "param_dicts": [
            # ---- Llama4-17b-128e (MoE, noscan) ----
            # noscan unrolls all 48 layers into one flat HLO. XLA schedules 24 layer
            # AllGather outputs as simultaneously live during the backward pass → huge
            # preallocated-temp → OOM.
            # Root cause: the original ptyche config had ici_fsdp=2, ici_expert=4 →
            #   AllGather group = dcn_fsdp=4 × ici_fsdp=2 × ici_expert=4 = 32 devices.
            #   Each AllGather output = 64 GiB; 24 × 64 = 1.5 TiB preallocated-temp.
            # Tried: no_pipelining_xla_remat → only 5% improvement.
            # Tried: ici_fsdp=1, ici_seq=8, ici_tensor=8, ici_expert=1, segment=16 →
            #   SPMD "involuntary full rematerialization" (941 GiB OOM). ici_expert=1
            #   with no dcn_expert forces SPMD to replicate expert weights.
            # Tried: segment=2, dcn_expert=8 → FAILS: ptyche has fixed 4 physical NVLink
            #   islands (16 nodes each); JAX always detects num_slices=4 regardless of
            #   --segment flag; dcn_expert=8 gives dcn product=32 ≠ 4 → ValueError.
            # Fix: ici_tensor=8, ici_expert=8, ici_fsdp=1 (dcn_fsdp=4).
            #   ICI = 8×8 = 64 ✓ (matches 16 nodes × 4 tasks/island). DCN = 4 ✓.
            #   AllGather group for attention = dcn_fsdp × ici_fsdp = 4×1 = 4 (same as
            #     prenyx dcn_fsdp=4) → AllGather outputs same size as prenyx which passes.
            #   Expert routing on ICI (ici_expert=8): 128/8=16 experts per device → SPMD
            #     can use ici_expert axis → no forced rematerialization.
            make_dict("prenyx", "llama4-17b-128e-noscan", xla_config="no_pipelining_xla_remat", nodes=32, segment=1,  dcn_data=1, dcn_fsdp=4, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=8, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=8, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1),
            make_dict("ptyche", "llama4-17b-128e-noscan", xla_config="no_pipelining_xla_remat", nodes=64, segment=16, dcn_data=1, dcn_fsdp=4, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=8, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8),
            make_dict("lyris",  "llama4-17b-128e-noscan", xla_config="no_pipelining_xla_remat", nodes=64, segment=16, dcn_data=1, dcn_fsdp=4, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=8, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8),

            # ---- DeepSeek3-671b-2dfsdp (MoE) ----
            # prenyx: dcn_fsdp=8, dcn_fsdp_t=4, ici_fsdp=1, ici_expert=8 (total FSDP=32).
            #   Uses 2D DCN-FSDP (regular × transpose) with no ICI FSDP. Passes on prenyx.
            #
            # ptyche/lyris: failed with ici_fsdp=4 + dcn_fsdp_t=4 → SPMD involuntary full
            #   rematerialization (converts {devices=[256,1,1]} → {devices=[1,1,4,64]}) →
            #   336 GiB intermediate tensor → cuBLAS requests 224 GiB workspace → NULL
            #   deref (bfc can't allocate) → SIGSEGV. shard_autotuning=true did not help.
            #
            # Root cause: the ici_fsdp + dcn_fsdp_t combination creates a sharding
            #   conversion that SPMD can't handle efficiently → forced full remat.
            #
            # Attempt 2 (dcn_fsdp=4, ici_fsdp=8): FAILED. SPMD can't convert
            #   fake_parameter.2 from {devices=[256,1,1]} →
            #   {devices=[1,1,32,8] last_tile_dim_replicate} when the 32-way non-replicated
            #   sharding spans BOTH ICI (ici_fsdp=8) and DCN (dcn_fsdp=4) dims.
            #   Creates full 256-expert copy per device → bf16[58,256,512,128,256] = 464 GiB
            #   → cuBLAS requests 224 GiB workspace (> 185 GiB total HBM) → NULL → SIGSEGV.
            #
            # Fix attempt 3: mirror prenyx structure exactly — keep FSDP entirely at DCN
            #   level (dcn_fsdp=2, dcn_fsdp_t=2 for "2D" = 4 total), ici_fsdp=1. Add
            #   TP at ICI (ici_tensor=8) + expert routing at ICI (ici_expert=8) like prenyx.
            #   This avoids the mixed ICI+DCN FSDP sharding conversion that causes remat.
            make_dict("prenyx", "deepseek3-671b-2dfsdp", xla_config="default",    nodes=32, segment=1,  dcn_data=1, dcn_fsdp=8, dcn_fsdp_t=4, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8,  mem_fraction=0.9),
            make_dict("ptyche", "deepseek3-671b-2dfsdp", xla_config="no_pipelining", nodes=64, segment=16, dcn_data=1, dcn_fsdp=2, dcn_fsdp_t=2, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=8, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8,  mem_fraction=0.9),
            make_dict("lyris",  "deepseek3-671b-2dfsdp", xla_config="no_pipelining", nodes=64, segment=16, dcn_data=1, dcn_fsdp=2, dcn_fsdp_t=2, dcn_pipe=1, dcn_expert=1, ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=8, ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=8,  mem_fraction=0.9),
        ],
        "container": (41,),
        "allocator": ("bfc",),
        "maxtext": ("container",),
        "graph": ("CGOFF","UnrolledModel"),
        "steps":(30,),
        "time":(60,),
        "cuda_device_max_connections": (0,),
        "jaxlib": (0,),
        "pgle": (0,),
        "baseDir": ("results",),
        "script": ("slurm_run.sub",),
        "nccl": (0,),
        "NcclGraphMix": (1,),
        "NcclLink": (0,),
        "fmha": (1,),
        "LHS": (1,),
        "Exclusive": (0,),
        "Sanitizer": (0,),
        "bindpcie": (0,),
        "ScaleLaunchQueue": ("1x",),
        "NcclDebug": (0,),
        "XLADUMPS": (1,),
        "CMDBUFFERDUMP": (0,),
        "PROFILE": ("nsys",),
        "GDB": (0,),
        "Driver": (0,),
        "overwrite": (1,),
        "mode": (os.getenv("MAXTEXT_RUN", "perf"),),
        "runDir": (
            os.getenv(
                "MAXTEXT_RUN_DIR", get_default_run_dir(os.getenv("MAXTEXT_RUN", "perf"))
            ),
        ),
    },

}

# Reviewed against MaxText upstream 48c7da3e28e8f57fe36ddf09d00eec53072a2ea0
# and qualified on ptyche GB200 GPUs with container 43. Other cluster
# placements below remain unqualified until a strict-wrapper run succeeds.
MAXTEXT_WORKLOAD_CONFIG.update(
    {
        # Qualification: Slurm 2374471, COMPLETED 0:0.
        "infer-gemma2-2b-bf16-1n4g": {
            "model_name": "gemma2-2b",
            "tokenizer_path": "/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.gemma",
            "max_prefill_predict_length": 1024,
            "max_target_length": 2048,
            "per_device_batch_size": 64,
            "attention": "dot_product",
            "scan_layers": "false",
            "async_checkpointing": "false",
            "inference_microbenchmark_prefill_lengths": '"1024"',
            "inference_microbenchmark_stages": "prefill,generate",
            "inference_microbenchmark_loop_iters": 32,
            "weight_dtype": "bfloat16",
            "gcs_metrics": "false",
        },
        # Qualification: Slurm 2374472, COMPLETED 0:0.
        "infer-llama3-8b-bf16-1n4g": {
            "model_name": "llama3-8b",
            "tokenizer_path": "/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer_llama3.tiktoken",
            "tokenizer_type": "tiktoken",
            "max_prefill_predict_length": 1024,
            "max_target_length": 2048,
            "per_device_batch_size": 64,
            "attention": "dot_product",
            "scan_layers": "false",
            "async_checkpointing": "false",
            "inference_microbenchmark_prefill_lengths": '"1024"',
            "inference_microbenchmark_stages": "prefill,generate",
            "inference_microbenchmark_loop_iters": 32,
            "weight_dtype": "bfloat16",
            "gcs_metrics": "false",
        },
        "infer-qwen3-8b-bf16-1n4g": {
            # Native dense Qwen3: 36 layers, 4096 hidden size, 32 query
            # heads, 8 KV heads, and QK normalization. No model overrides.
            # Reviewed at MaxText 188af874fb7d28b4ae9a344d4bb5a0f46aaaddba.
            "model_name": "qwen3-8b",
            # Preserve the model's HF tokenizer type using bundled assets;
            # no model checkpoint or tokenizer download is required.
            "tokenizer_type": "huggingface",
            "tokenizer_path": "/opt/maxtext/src/maxtext/assets/tokenizers/qwen3-tokenizer",
            "max_prefill_predict_length": 1024,
            "max_target_length": 2048,
            "per_device_batch_size": 1,
            "attention": "dot_product",
            "scan_layers": "false",
            "dtype": "bfloat16",
            "weight_dtype": "bfloat16",
            "quantization": "",
            "quantize_kvcache": "false",
            "async_checkpointing": "false",
            "inference_microbenchmark_prefill_lengths": '\"1024\"',
            "inference_microbenchmark_stages": "prefill,generate",
            "inference_microbenchmark_loop_iters": 32,
            "gcs_metrics": "false",
        },
        # Qualification: Slurm 2374438, COMPLETED 0:0. This preserves the
        # upstream Llama2-70B GPU recipe's intent with current-schema values:
        # quantization=fp8 and INT8 KV cache replace rejected aqt_fp8/FP8 KV.
        "infer-llama2-70b-fp8-int8kv-2n4g": {
            "model_name": "llama2-70b",
            "tokenizer_path": "/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.llama2",
            "max_prefill_predict_length": 1024,
            "max_target_length": 2048,
            "per_device_batch_size": 190,
            "attention": "dot_product",
            # The pure-NNX loader materializes both AR and PREFILL models at
            # once, which exhausts VMM PA budget for this 70B configuration.
            "enable_nnx": "false",
            "pure_nnx": "false",
            "pure_nnx_decoder": "false",
            "scan_layers": "false",
            "async_checkpointing": "false",
            "inference_microbenchmark_prefill_lengths": '"1024"',
            "inference_microbenchmark_stages": "prefill,generate",
            "inference_microbenchmark_loop_iters": 64,
            "weight_dtype": "bfloat16",
            "quantization": "fp8",
            "quantize_kvcache": "true",
            "kv_quant_dtype": "int8",
            "gcs_metrics": "false",
        },
        "infer-deepseek3-671b-bf16-8n4g": {
            # Full upstream model: 61 layers (3 dense), 256 routed experts,
            # top-8 routing, 7168 hidden size, and MLA. No training overrides.
            # Checked against upstream 259de09cdb91b55ffa7cf71ff5bd92541942d2bc.
            "model_name": "deepseek3-671b",
            # Synthetic microbenchmark inputs need only in-vocabulary IDs.
            # This bundled tokenizer avoids an HF download/auth dependency.
            "tokenizer_type": "sentencepiece",
            "tokenizer_path": "/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.default",
            "max_prefill_predict_length": 512,
            "max_target_length": 1024,
            "per_device_batch_size": 1,
            "attention": "dot_product",
            "mla_naive_kvcache": "false",
            "scan_layers": "false",
            "dtype": "bfloat16",
            "weight_dtype": "bfloat16",
            "quantization": "",
            "quantize_kvcache": "false",
            # Portable XLA matmuls, with no TPU-specific grouped-GEMM kernel
            # or training TE-EP capacity/gradient-accumulation settings.
            "sparse_matmul": "false",
            "capacity_factor": -1.0,
            "n_routing_groups": 8,
            "topk_routing_group": 4,
            "async_checkpointing": "false",
            "inference_microbenchmark_prefill_lengths": '"512"',
            "inference_microbenchmark_stages": "prefill,generate",
            "inference_microbenchmark_loop_iters": 32,
            "gcs_metrics": "false",
        },
        "infer-deepseek4-flash-284b-bf16-4n4g": {
            # Native V4-Flash: 43 layers, 256 experts, top-6 routing, mHC,
            # and SWA/HCA/CSA. Upstream omits the auxiliary MTP layer.
            # Reviewed at 2a4988bcf65603f34af24b85a7d57cf0f9862a00, including
            # compressed KV and indexer caches for autoregressive decoding.
            "model_name": "deepseek4-284b",
            "tokenizer_type": "sentencepiece",
            "tokenizer_path": "/opt/maxtext/src/maxtext/assets/tokenizers/tokenizer.default",
            # 4096 / CSA ratio 4 > native indexer_topk 512, exercising top-k
            # selection without reducing the model's architecture settings.
            "max_prefill_predict_length": 4096,
            "max_target_length": 8192,
            "per_device_batch_size": 1,
            "attention": "dot_product",
            "scan_layers": "false",
            "dtype": "bfloat16",
            "weight_dtype": "bfloat16",
            "quantization": "",
            "quantize_kvcache": "false",
            "sparse_matmul": "false",
            "capacity_factor": -1.0,
            "async_checkpointing": "false",
            "inference_microbenchmark_prefill_lengths": '"4096"',
            "inference_microbenchmark_stages": "prefill,generate",
            "inference_microbenchmark_loop_iters": 32,
            "gcs_metrics": "false",
        },
    }
)

MAXTEXT_XLA_CONFIGS["maxtext_gpu_inference"] = [
    "--xla_disable_hlo_passes=rematerialization",
]

CONFIGS["inference"] = {
    "param_dicts": [
        make_dict(
            "ptyche", "infer-gemma2-2b-bf16-1n4g",
            xla_config="maxtext_gpu_inference", nodes=1, segment=1, tpn=4,
            dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1,
            ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1,
            ici_tensor_t=1, ici_tensor_seq=1, ici_auto=-1, ici_pipe=1, ici_expert=1,
            mem_fraction=0.94, maxtext_runner="inference", workload_type="Inference",
            maxtext_config_path="/opt/maxtext/src/maxtext/configs/inference/inference.yml",
            env_vars={"TF_FORCE_GPU_ALLOW_GROWTH": "true", "TF_CPP_VMODULE": ""},
            graph="FusionCustom", time=30,
        ),
        make_dict(
            "ptyche", "infer-llama3-8b-bf16-1n4g",
            xla_config="maxtext_gpu_inference", nodes=1, segment=1, tpn=4,
            dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1,
            ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1,
            ici_tensor_t=1, ici_tensor_seq=1, ici_auto=-1, ici_pipe=1, ici_expert=1,
            mem_fraction=0.94, maxtext_runner="inference", workload_type="Inference",
            maxtext_config_path="/opt/maxtext/src/maxtext/configs/inference/inference.yml",
            env_vars={"TF_FORCE_GPU_ALLOW_GROWTH": "true", "TF_CPP_VMODULE": ""},
            graph="FusionCustom", time=30,
        ),
        make_dict(
            "ptyche", "infer-qwen3-8b-bf16-1n4g",
            xla_config="maxtext_gpu_inference", nodes=1, segment=1, tpn=4,
            dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1,
            ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=4,
            ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1,
            mem_fraction=0.90, maxtext_runner="inference", workload_type="Inference",
            # Current MaxText removed tensor_transpose from its mesh, but
            # inference.yml still references it in cache sharding rules.
            maxtext_config_path="/opt/maxtext/src/maxtext/configs/inference/jax_workloads_legacy.yml",
            custom_mounts=(
                f"{Path(__file__).resolve().parent / 'inference_legacy_no_tensor_transpose.yml'}:"
                "/opt/maxtext/src/maxtext/configs/inference/jax_workloads_legacy.yml:ro"
            ),
            env_vars={"TF_FORCE_GPU_ALLOW_GROWTH": "true", "TF_CPP_VMODULE": ""},
            graph="CGOFF", pgle=0, time=60,
            maxtext_reviewed_revision="188af874fb7d28b4ae9a344d4bb5a0f46aaaddba",
        ),
        make_dict(
            "ptyche", "infer-llama2-70b-fp8-int8kv-2n4g",
            xla_config="maxtext_gpu_inference", nodes=2, segment=2, tpn=4,
            dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1,
            ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=-1,
            ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=1,
            mem_fraction=0.94, maxtext_runner="inference", workload_type="Inference",
            maxtext_config_path="/opt/maxtext/src/maxtext/configs/inference/jax_workloads_legacy.yml",
            custom_mounts=(
                f"{Path(__file__).resolve().parent / 'inference_legacy_no_tensor_transpose.yml'}:"
                "/opt/maxtext/src/maxtext/configs/inference/jax_workloads_legacy.yml"
            ),
            env_vars={"TF_FORCE_GPU_ALLOW_GROWTH": "true", "TF_CPP_VMODULE": ""},
            graph="FusionCustom", time=60,
        ),
        make_dict(
            "ptyche", "infer-deepseek3-671b-bf16-8n4g",
            xla_config="maxtext_gpu_inference", nodes=8, segment=8, tpn=4,
            dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1,
            ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1,
            ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=32,
            inference_mesh_axis="expert", mem_fraction=0.90,
            maxtext_runner="inference", workload_type="Inference",
            maxtext_config_path="/opt/maxtext/src/maxtext/configs/base.yml",
            env_vars={"TF_FORCE_GPU_ALLOW_GROWTH": "true", "TF_CPP_VMODULE": ""},
            graph="CGOFF", pgle=0, time=120,
        ),
        make_dict(
            "ptyche", "infer-deepseek4-flash-284b-bf16-4n4g",
            xla_config="maxtext_gpu_inference", nodes=4, segment=4, tpn=4,
            dcn_data=1, dcn_fsdp=1, dcn_fsdp_t=1, dcn_pipe=1, dcn_expert=1,
            ici_data=1, ici_fsdp=1, ici_fsdp_t=1, ici_seq=1, ici_tensor=1,
            ici_tensor_t=1, ici_tensor_seq=1, ici_auto=1, ici_pipe=1, ici_expert=16,
            inference_mesh_axis="expert", mem_fraction=0.90,
            maxtext_runner="inference", workload_type="Inference",
            maxtext_config_path="/opt/maxtext/src/maxtext/configs/base.yml",
            env_vars={"TF_FORCE_GPU_ALLOW_GROWTH": "true", "TF_CPP_VMODULE": ""},
            graph="CGOFF", pgle=0, time=120, container=None,
            inference_aot_mode="consistent",
            maxtext_reviewed_revision="2a4988bcf65603f34af24b85a7d57cf0f9862a00",
            _notes=[
                "Selected image must provide V4 compressed KV/indexer decode support "
                "(MaxText reviewed at 2a4988bcf65603f34af24b85a7d57cf0f9862a00); "
                "container 43 is not established as compatible."
            ],
        ),
    ],
    "container": (43,),
    "allocator": ("bfc",),
    "maxtext": ("container",),
    "graph": ("FusionCustom",),
    "steps": (1,),
    "time": (30,),
    "cuda_device_max_connections": (0,),
    "jaxlib": (0,),
    "pgle": (0,),
    "baseDir": ("results",),
    "script": ("slurm_run.sub",),
    "nccl": (0,),
    "NcclGraphMix": (1,),
    "NcclLink": (0,),
    "fmha": (1,),
    "LHS": (1,),
    "Exclusive": (0,),
    "Sanitizer": (0,),
    "bindpcie": (0,),
    "ScaleLaunchQueue": ("1x",),
    "NcclDebug": (0,),
    "XLADUMPS": (0,),
    "CMDBUFFERDUMP": (0,),
    "PROFILE": ("none",),
    "GDB": (0,),
    "Driver": (0,),
    "overwrite": (1,),
    "mode": ("inference",),
    "runDir": ("maxtext_inference",),
}

CONFIGS["inference"]["param_dicts"] = _expand_inference_clusters(
    CONFIGS["inference"]["param_dicts"], MAXTEXT_WORKLOAD_CONFIG,
    qualification_jobs={
        ("infer-gemma2-2b-bf16-1n4g", "ptyche"): "2374471",
        ("infer-llama3-8b-bf16-1n4g", "ptyche"): "2374472",
        ("infer-llama2-70b-fp8-int8kv-2n4g", "ptyche"): "2374438",
    },
)

_JAX_CI_WORKLOADS = _load_jax_ci_workloads()
_JAX_CI_WORKLOADS["config"]["param_dicts"] = _expand_inference_clusters(
    _JAX_CI_WORKLOADS["config"]["param_dicts"], _JAX_CI_WORKLOADS["workloads"],
)
MAXTEXT_WORKLOAD_CONFIG.update(_JAX_CI_WORKLOADS["workloads"])
if _JAX_CI_WORKLOADS["config"].get("param_dicts"):
    CONFIGS["jax_ci"] = _JAX_CI_WORKLOADS["config"]

def get_config(config_name=None):
    return _get_config(CONFIGS, "MAXTEXT_CONFIG", config_name)


def get_parameterized_product_args(config_name=None):
    return _get_parameterized_product_args(CONFIGS, "MAXTEXT_CONFIG", "param_dicts", config_name)


def list_available_configs():
    return _list_available_configs(CONFIGS)


def print_config_info(config_name=None):
    _print_config_info(CONFIGS, "MAXTEXT_CONFIG", "MaxText", "param_dicts", config_name)

if __name__ == "__main__":
    print("Available MaxText v2 configurations:")
    print("=" * 50)
    for config_name in list_available_configs():
        print_config_info(config_name)
        print()
