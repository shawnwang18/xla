"""
Shared configuration utilities for test suite config files (grok, saxml, maxtext).
"""
import os


def get_config(configs, env_var, config_name=None):
    if config_name is None:
        config_name = os.getenv(env_var, "default")
    if config_name not in configs:
        raise ValueError(
            f"Unknown configuration: '{config_name}'. "
            f"Available configurations: {', '.join(configs)}"
        )
    return configs[config_name]


def get_parameterized_product_args(configs, env_var, positional_key, config_name=None):
    config = get_config(configs, env_var, config_name)
    positional_args = (tuple(config[positional_key]),)
    kwargs = {k: v for k, v in config.items() if k != positional_key}
    return positional_args, kwargs


def list_available_configs(configs):
    return list(configs.keys())


def print_config_info(configs, env_var, label, positional_key, config_name=None):
    if config_name is None:
        config_name = os.getenv(env_var, "default")
    config = get_config(configs, env_var, config_name)
    print(f"\n=== {label} Configuration: {config_name} ===")
    print(f"Number of configurations: {len(config[positional_key])}")
    for field in ("runDir", "mode", "graph", "container", "Driver", "PROFILE"):
        if field in config:
            print(f"{field}: {config[field]}")
    print("=" * 50)
