"""Run single-node trials concurrently inside a retained eight-node allocation."""
import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parent
REQUEST = json.loads((ROOT / 'request.json').read_text())
ALLOCATION = REQUEST['allocation_id']
LOCK_PATH = Path(REQUEST['reuse_lock'])

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, data):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2) + '\n')
    tmp.replace(path)

def steps(allocation=ALLOCATION):
    raw = subprocess.check_output(['squeue', '--steps', '-j', allocation,
                                   '-h', '-o', '%i|%j|%N'], text=True, timeout=30)
    return [line.split('|') for line in raw.splitlines()
            if line.split('|')[0].split('.')[-1] not in {'batch', 'extern'}]

def check_node(node, allocation=ALLOCATION):
    raw = subprocess.check_output(['squeue', '-j', allocation, '-h', '-o', '%T|%u|%L'],
                                  text=True, timeout=30).strip()
    assert raw.startswith('RUNNING|shawnw|'), raw
    for ident, name, nodes in steps(allocation):
        expanded = subprocess.check_output(['scontrol', 'show', 'hostnames', nodes], text=True).splitlines()
        if node in expanded:
            raise RuntimeError('Node already has active step ' + ident)

def mounts(out=None):
    values = [f'{ROOT}:/work', f'{ROOT}/jaxlibs:/opt/pr-jaxlibs:ro']
    values.extend(REQUEST.get('extra_mounts', []))
    if out:
        values.append(f'{out}:/result')
    return values

def base_command(node, ranks, label, out, mount_values, allocation=ALLOCATION):
    image = 'oauth2@' + REQUEST['image'].replace('gitlab-master.nvidia.com:5005/',
                                               'gitlab-master.nvidia.com:5005#').replace('@sha256:', ':sha256:')
    return ['srun', '--jobid=' + allocation, '--nodelist=' + node, '--nodes=1',
            '--ntasks=' + str(ranks), '--ntasks-per-node=' + str(ranks),
            '--cpus-per-task=16', '--cpu-bind=none', '--gres=gpu:' + REQUEST['gpu_type'] + ':4',
            '--exact', '--exclusive', '--time=01:00:00', '--kill-on-bad-exit=1',
            '--job-name=pr50278-' + label, '--container-image=' + image,
            '--container-mounts=' + ','.join(mount_values),
            '--container-name=pr50278-ten-workloads', '--container-remap-root',
            '--container-writable', '--container-workdir=/opt/maxtext',
            '--output=' + str(out / 'rank-%t.log'), '--error=' + str(out / 'rank-%t.log')]

def preflight(node, allocation=ALLOCATION):
    out = ROOT / 'preflight' / node
    out.mkdir(parents=True, exist_ok=True)
    check_node(node, allocation)
    cmd = base_command(node, 1, 'preflight', out, mounts(), allocation) + ['bash', '/work/preflight.sh']
    save(out / 'launch.json', dict(command=cmd, started_at=now()))
    with (out / 'launcher.log').open('w') as log:
        rc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT).returncode
    text = (out / 'rank-0.log').read_text() if (out / 'rank-0.log').exists() else ''
    save(out / 'status.json', dict(returncode=rc, valid=rc == 0 and 'PREFLIGHT_PASS' in text,
                                   finished_at=now()))
    assert rc == 0 and 'PREFLIGHT_PASS' in text, 'Preflight failed: ' + str(out)

def one(case, trial, worker):
    out = Path(trial['directory'])
    status_path = out / 'run-status.json'
    if status_path.exists():
        previous = json.loads(status_path.read_text())
        assert previous['state'] == 'COMPLETED', 'Reconcile previous failed trial ' + str(out)
        return previous
    assert not (out / 'launch.json').exists(), 'Reconcile previous launch ' + str(out)
    assert json.loads((ROOT / 'control.json').read_text())['enabled'], 'Stopped by control file'
    allocation=worker['allocation_id']
    check_node(worker['node'], allocation)
    env = os.environ.copy()
    env.update(json.loads((out / 'env.json').read_text()))
    env.update(WORKLOAD=case['workload'], EXPECTED_MODEL=case['model'],
               EARLY_RELEASE_MODE=str(trial['mode']), EXPECTED_GPU_TYPE=REQUEST['gpu_type'])
    mount_values = mounts(out)
    if env.get('CUSTOM_MOUNTS'):
        mount_values.append(env['CUSTOM_MOUNTS'])
    cmd = base_command(worker['node'], 4, case['model'] + '-' + str(trial['index']), out,
                       mount_values, allocation) + ['bash', '/work/rank.sh']
    record = dict(trial=trial, command=cmd, state='RUNNING', started_at=now(),
                  allocation_id=allocation, node=worker['node'], gpu_type=REQUEST['gpu_type'])
    save(out / 'launch.json', record)
    with (out / 'launcher.log').open('w') as log:
        process = subprocess.Popen(cmd, env=env, stdout=log, stderr=subprocess.STDOUT)
        while process.poll() is None:
            time.sleep(20)
            ranks = list(out.glob('step-rank*.json'))
            if ranks:
                record['step_id'] = json.loads(ranks[0].read_text())['step_id']
                save(out / 'launch.json', record)
        rc = process.returncode
    ranks = [json.loads(p.read_text()) for p in out.glob('runtime-rank*.json')]
    valid = rc == 0 and len(ranks) == 4 and all(r['state'] == 'COMPLETED' for r in ranks)
    pattern = 'stable-rank*.json' if case['type'] == 'inference' else 'training-summary-rank*.json'
    reports = [json.loads(p.read_text()) for p in out.glob(pattern)]
    valid = valid and len(reports) == 4
    if case['type'] == 'inference':
        valid = valid and all(r['status'] == 'completed' and r.get('model_request_e2e') for r in reports)
    record.update(returncode=rc, state='COMPLETED' if valid else 'FAILED', finished_at=now())
    if record.get('step_id'):
        record['accounting'] = subprocess.run(
            ['sacct', '-j', record['step_id'], '-nP', '--format=JobIDRaw,State,ExitCode,Elapsed,NodeList'],
            capture_output=True, text=True, timeout=30).stdout
    save(status_path, record)
    assert valid, 'Trial failed: ' + str(out)
    return record

def main():
    os.environ['ENROOT_CONFIG_PATH'] = '/home/scratch.shawnw_inf/workload-runs/deepseek4-cb-modes-20261013/.enroot'
    plan = json.loads((ROOT / 'parallel-plan.json').read_text())
    cases = json.loads((ROOT / 'cases.json').read_text())
    by_name = {case['workload']: case for case in cases}
    lock = LOCK_PATH.open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not steps(), 'Reservation is busy'
    claim = dict(allocation_id=ALLOCATION, nodes=REQUEST['nodes'], active_task=REQUEST['thread_id'],
                 active_root=str(ROOT), reuse_state='BUSY_PR50278_TEN_WORKLOADS',
                 controller_pid=os.getpid(), controller_host=os.uname().nodename,
                 updated_at=now(), reuse_lock=str(LOCK_PATH), keep_allocation_open=True)
    save(LOCK_PATH.parent / 'active-reuse.json', claim)
    status = dict(state='STAGING_RUNTIME', pid=os.getpid(), host=os.uname().nodename,
                  started_at=now(), completed=[], workers={})
    mutex = threading.Lock()
    def persist():
        status['checked_at'] = now()
        save(ROOT / 'suite-status.json', status)
    persist()
    try:
        while not (ROOT / 'TRANSFER_READY').exists():
            assert json.loads((ROOT / 'control.json').read_text())['enabled']
            time.sleep(15)
        status['state'] = 'PREFLIGHT'
        persist()
        # Catch package/runtime incompatibilities before eight simultaneous starts.
        preflight(plan['workers'][0]['node'])
        if not (ROOT / 'RUN_READY').exists():
            status['state'] = 'WAITING_FOR_LAUNCH_GATE'
            persist()
            while not (ROOT / 'RUN_READY').exists():
                assert json.loads((ROOT / 'control.json').read_text())['enabled']
                time.sleep(15)
        status['state'] = 'RUNNING'
        for worker in plan['workers']:
            status['workers'][worker['node']] = dict(**worker, state='STARTING', current=None)
        persist()
        def work(worker):
            ws = status['workers'][worker['node']]
            try:
                for name in worker['workloads']:
                    for trial in by_name[name]['trials']:
                        with mutex:
                            ws.update(state='RUNNING', current=trial)
                            persist()
                        result = one(by_name[name], trial, worker)
                        with mutex:
                            status['completed'].append(result)
                            persist()
                with mutex:
                    ws.update(state='COMPLETED', current=None, finished_at=now())
                    persist()
            except BaseException as exc:
                with mutex:
                    ws.update(state='FAILED', error=repr(exc), finished_at=now())
                    persist()
        with ThreadPoolExecutor(max_workers=len(plan['workers'])) as pool:
            futures = [pool.submit(work, w) for w in plan['workers']]
            for future in futures:
                future.result()
        status['state'] = 'COMPLETED' if len(status['completed']) == 50 else 'FAILED'
    except BaseException as exc:
        status.update(state='FAILED', error=repr(exc))
        raise
    finally:
        status['finished_at'] = now()
        persist()
        claim.update(reuse_state='IDLE_RETAINED', suite_state=status['state'], updated_at=now())
        save(LOCK_PATH.parent / 'active-reuse.json', claim)

if __name__ == '__main__':
    main()
