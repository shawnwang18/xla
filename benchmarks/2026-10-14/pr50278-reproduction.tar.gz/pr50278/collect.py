"""Collect strict completed trials, retaining timings and memory as separate metrics."""
import csv
import json
import math
from pathlib import Path
import re
import statistics
import sys

ROOT=Path(__file__).resolve().parent

def summarize(out,kind):
    result=dict(directory=str(out))
    status=json.loads((out/'run-status.json').read_text())
    result.update(state=status['state'],step_id=status.get('step_id'),allocation_id=status.get('allocation_id'),node=status.get('node'),gpu_type=status.get('gpu_type'))
    if (out/'hardware.json').exists():result['hardware']=json.loads((out/'hardware.json').read_text())
    if result['state']!='COMPLETED':
        return result
    ranks=[json.loads(p.read_text()) for p in sorted(out.glob('runtime-rank*.json'))]
    assert len(ranks)==4 and all(r['returncode']==0 for r in ranks)
    result['process_wall_s']=max(r['process_wall_s'] for r in ranks)
    result['host_peak_rss_gib_max_rank']=max(r['host_peak_rss_kib'] for r in ranks)/1024**2
    device_stats=[d['stats'] for r in ranks for d in r.get('devices',[]) if d.get('stats')]
    for key in ('peak_bytes_in_use','peak_pool_bytes','bytes_in_use','pool_bytes'):
        values=[s[key]/2**30 for s in device_stats if key in s]
        result[key+'_gib_max_gpu']=max(values) if values else None
    if kind=='training':
        times=[json.loads(p.read_text()) for p in sorted(out.glob('training-summary-rank*.json'))]
        assert len(times)==4 and all(len(t['samples_ms'])==60 for t in times)
        # The slowest rank defines completion of each distributed iteration.
        values=[max(t['samples_ms'][i] for t in times) for i in range(60)]
        result['e2e_ms']=statistics.mean(values)
        result['e2e_median_ms']=statistics.median(values)
        result['e2e_p95_ms']=sorted(values)[int(.95*(len(values)-1))]
        result['e2e_cv_percent']=statistics.pstdev(values)/result['e2e_ms']*100
        for rank in range(4):
            samples=[json.loads(line) for line in (out/f'training-samples-rank{rank}.jsonl').read_text().splitlines()]
            assert [s['step'] for s in samples]==list(range(101)),(out,rank,'incomplete training iterations')
        metrics_path=out/'training-metrics-rank0.jsonl'
        if not metrics_path.exists():metrics_path=out/'training-metrics.jsonl'
        metrics=[json.loads(l) for l in metrics_path.read_text().splitlines() if l.strip()]
        losses=[]
        def find_losses(obj):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    if k.endswith('/loss') and isinstance(v,(int,float)):
                        losses.append(v)
                    elif isinstance(v,dict):find_losses(v)
        for row in metrics:find_losses(row)
        assert losses and all(math.isfinite(x) for x in losses),'Missing/nonfinite loss'
        result['losses']=losses
        result['loss_by_step']={str(int(row['step'])):row['learning/loss'] for row in metrics if 'step' in row and 'learning/loss' in row}
    else:
        times=[json.loads(p.read_text()) for p in sorted(out.glob('stable-rank*.json'))]
        assert len(times)==4 and all(t['status']=='completed' for t in times)
        for phase in ('prefill','decode'):
            result[phase+'_ms']=max(t['stages'][phase]['mean_ms'] for t in times)
        n=len(times[0]['model_request_e2e']['samples_ms'])
        assert n==20
        samples=[max(t['model_request_e2e']['samples_ms'][i] for t in times) for i in range(n)]
        result['e2e_ms']=statistics.mean(samples)
        result['compiled_memory']=times[0]['compiled_memory']
        result['final_logits_samples']=[t.get('final_logits_sample',[]) for t in times]
        assert all(t['finite_final_local_logits'] for t in times)
        result['phase_stable']=all(t['stages'][p]['stable'] for t in times for p in ('prefill','decode'))
    physical=[]
    with (out/'gpu-memory.csv').open() as f:
        for row in csv.reader(f):
            try:physical.append((int(row[1]),float(row[2])/1024))
            except (ValueError,IndexError):pass
    result['sampled_physical_peak_gib_max_gpu']=max((v for _,v in physical),default=None)
    result['sampled_physical_peak_gib_by_gpu']={str(i):max(v for j,v in physical if i==j) for i in sorted({i for i,_ in physical})}
    compiled=[]
    for p in sorted((out/'hlo').glob('*memory-usage-report.txt')):
        m=re.search(r'Total bytes(?: used)?:\s*(\d+)',p.read_text())
        if m:compiled.append(dict(file=p.name,bytes=int(m[1]),gib=int(m[1])/2**30))
    result['hlo_memory_reports']=compiled
    result['max_compiled_module_gib']=max((r['gib'] for r in compiled),default=None)
    pairs=[]
    for before in sorted((out/'hlo').glob('*before_hlo-early-buffer-release.txt')):
        match=re.match(r'^(.*)\.(\d+)\.latency-hiding-scheduler\.',before.name)
        if not match:continue
        candidates=list((out/'hlo').glob(match[1]+'.*.latency-hiding-scheduler.after_hlo-early-buffer-release.*'))
        if len(candidates)==1:
            pairs.append(dict(before=before.name,after=candidates[0].name,changed=before.read_bytes()!=candidates[0].read_bytes()))
    result['pass_hlo_pairs']=pairs
    decisions=[line for line in (out/'rank-0.log').read_text(errors='replace').splitlines()
               if 'early buffer release' in line.lower() or 'hlo_early_buffer_release.cc' in line]
    result['pass_log_decision_count']=len(decisions)
    result['pass_log_decisions']=decisions[-200:]
    return result

def main():
    cases=[]
    protocol=json.loads((ROOT/'protocol.json').read_text())
    hardware_by_workload=protocol.get('hardware_by_workload',{})
    for case in json.loads((ROOT/'cases.json').read_text()):
        item=dict(workload=case['workload'],type=case['type'],hardware=hardware_by_workload.get(case['workload'],{}),trials=[])
        for trial in case['trials']:
            out=Path(trial['directory'])
            if not (out/'run-status.json').exists():continue
            try:
                data=summarize(out,case['type'])
                data.update(mode=trial['mode'],pilot=trial['pilot'],index=trial['index'])
                (out/'collected.json').write_text(json.dumps(data,indent=2)+'\n')
                item['trials'].append(data)
            except Exception as exc:
                item['trials'].append(dict(index=trial['index'],mode=trial['mode'],pilot=trial['pilot'],state='INVALID',error=repr(exc)))
        modes={}
        for mode in (0,1):
            rows=[t for t in item['trials'] if t['mode']==mode and not t['pilot'] and t['state']=='COMPLETED']
            if len(rows)==2:
                modes[str(mode)]={k:statistics.mean(t[k] for t in rows)
                                 for k in ('e2e_ms','process_wall_s','peak_bytes_in_use_gib_max_gpu',
                                           'sampled_physical_peak_gib_max_gpu','max_compiled_module_gib',
                                           'prefill_ms','decode_ms','host_peak_rss_gib_max_rank') if all(isinstance(t.get(k),(int,float)) for t in rows)}
        item['modes']=modes
        item['repeat_e2e_ms']={str(mode):[t['e2e_ms'] for t in item['trials'] if t['mode']==mode and not t['pilot'] and t['state']=='COMPLETED'] for mode in (0,1)}
        if case['type']=='training' and len(modes)==2:
            measured=[t for t in item['trials'] if not t['pilot'] and t['state']=='COMPLETED']
            ref=measured[0]['loss_by_step']
            assert all(t['loss_by_step'].keys()==ref.keys() for t in measured)
            item['max_abs_loss_difference_across_measured_trials']=max(abs(v-t['loss_by_step'][step]) for t in measured for step,v in ref.items())
        if case['type']=='inference' and len(modes)==2:
            measured=[t for t in item['trials'] if not t['pilot'] and t['state']=='COMPLETED']
            ref=measured[0]['final_logits_samples']
            assert all(len(v)==256 for v in ref), 'Missing inference correctness sample'
            item['max_abs_logit_sample_difference_across_measured_trials']=max(abs(v-t['final_logits_samples'][rank][index]) for t in measured for rank,values in enumerate(ref) for index,v in enumerate(values))
        if len(modes)==2:
            item['percent_change_on_vs_off']={k:(modes['1'][k]/v-1)*100 for k,v in modes['0'].items() if v and k in modes['1']}
        cases.append(item)
    (ROOT/'summary.json').write_text(json.dumps(cases,indent=2)+'\n')
    print(json.dumps([dict(workload=c['workload'],modes=c['modes'],trials=len(c['trials'])) for c in cases],indent=2))

if __name__=='__main__':
    main()
