import hashlib,importlib,json,os,sys
from pathlib import Path
m=json.loads(Path('/opt/pr-jaxlibs/build-manifest.json').read_text())
for n,h in m['libraries'].items():
    with (Path('/opt/pr-jaxlibs')/n).open('rb') as f: assert hashlib.file_digest(f,'sha256').hexdigest()==h,n
import jax,jaxlib,jax.numpy as jnp
import jax_plugins.xla_cuda13 as plugin
print('VERSIONS',jax.__version__,jaxlib.__version__,jaxlib.__file__,plugin.__file__,flush=True)
for mode in (0,1):
    f=jax.jit(lambda x:x@x+1,compiler_options={'xla_gpu_enable_latency_hiding_scheduler':True,'xla_gpu_experimental_enable_early_buffer_release':bool(mode)})
    y=f(jnp.ones((32,32))).block_until_ready()
    assert float(y[0,0])==33
from maxtext.trainers.pre_train import train
assert hasattr(train,'training_loop_iteration')
print('PASS',m['xla_commit'],jax.devices(),flush=True)
