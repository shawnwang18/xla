#!/bin/bash
set -euo pipefail
export PYTHONPATH=/opt/pr-jaxlibs/jax-python:/opt/pr-jaxlibs/jaxlib:/opt/pr-jaxlibs/jax_cuda13_plugin:/opt/pr-jaxlibs/jax_cuda13_pjrt:/opt/maxtext/src:/work/skill/assets/jax-run-scripts
export PYTHONUNBUFFERED=1
export JAX_ENABLE_COMPILATION_CACHE=false
export JAX_ENABLE_PGLE=false
export XLA_PYTHON_CLIENT_PREALLOCATE=false
export TF_FORCE_GPU_ALLOW_GROWTH=true
export DECOUPLE_GCLOUD=TRUE
export TF_CPP_MIN_LOG_LEVEL=0
export TF_CPP_VMODULE=hlo_early_buffer_release=1
export PYTHONUSERBASE="/tmp/pr-python-user-${SLURM_JOB_ID}-${SLURM_PROCID}"
python3 -m pip install --quiet --no-deps --user /work/wheels/typeguard-2.13.3-py3-none-any.whl
mkdir -p "/work/autotune/${WORKLOAD}/rank${SLURM_PROCID}"
export XLA_FLAGS="${BASE_XLA_FLAGS} --xla_gpu_per_fusion_autotune_cache_dir=/work/autotune/${WORKLOAD}/rank${SLURM_PROCID}"
if [[ "${SLURM_PROCID}" == 0 ]]; then
  mkdir -p /result/hlo
  export XLA_FLAGS="${XLA_FLAGS} --xla_dump_to=/result/hlo --xla_dump_hlo_as_text --xla_dump_hlo_pass_re=hlo-early-buffer-release"
  nvidia-smi --query-gpu=timestamp,index,memory.used,memory.total,utilization.gpu,power.draw,clocks.sm --format=csv,noheader,nounits -lms 200 > /result/gpu-memory.csv 2> /result/gpu-memory.err &
  sampler_pid=$!
  trap 'kill "$sampler_pid" 2>/dev/null || true; wait "$sampler_pid" 2>/dev/null || true' EXIT
fi
export SLURM_JOB_NODELIST="$SLURM_STEP_NODELIST"
export SLURM_NODELIST="$SLURM_STEP_NODELIST"
export SLURM_JOB_NUM_NODES=1
export SLURM_NNODES=1
cd /opt/maxtext
python3 /work/run_rank.py
