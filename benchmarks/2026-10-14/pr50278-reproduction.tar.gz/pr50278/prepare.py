"""Resolve bundled recipes for a same-binary, single-node PR comparison."""
import copy
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'skill/scripts'))
import jax_workloads as api

CASES = [
    ('default', 'llama3-8b-fp8'),
    ('default', 'qwen3-8b-fp8'),
    ('default', 'mistral-7b-fp8'),
    ('default', 'gemma2-9b-fp8'),
    ('default', 'gemma3-4b-fp8'),
    ('inference', 'infer-llama3-8b-bf16-1n4g'),
    ('inference', 'infer-qwen3-8b-bf16-1n4g'),
    ('inference', 'infer-gemma2-2b-bf16-1n4g'),
    ('jax_ci', 'ci-infer-gemma2-27b-bf16-1n4g'),
    ('jax_ci', 'ci-infer-gemma3-27b-bf16-1n4g'),
]

def main():
    request = json.loads((ROOT / 'request.json').read_text())
    api.CLUSTER_DEFAULTS['dlcluster'] = {'partition': 'gb300nvl72_preprod', 'tpn': 4}
    cfg = api.load_config_module(api.BUNDLED_REPO, api.DEFAULT_MODULE)
    cases = []
    for profile, name in CASES:
        config = cfg.CONFIGS[profile]
        base = api.config_defaults(config) | copy.deepcopy(next(
            r for r in config['param_dicts'] if r['cluster'] == 'ptyche' and r['model'] == name))
        assert base['nodes'] == 1
        inference = profile != 'default'
        work = cfg.MAXTEXT_WORKLOAD_CONFIG[name]
        if inference:
            work.update(dtype='bfloat16', weight_dtype='bfloat16', quantization='',
                        quantize_kvcache='false', attention='dot_product',
                        inference_microbenchmark_prefill_lengths='"1024"',
                        inference_microbenchmark_stages='prefill,generate',
                        inference_microbenchmark_loop_iters=300, gcs_metrics='false')
        base.update(cluster='dlcluster', partition=request['partition'], account='blackwell',
                    graph='CGOFF', pgle=0, steps=101, XLADUMPS=1,
                    PROFILE='none', profile_mode='none',
                    validation='unqualified', mem_fraction=.85,
                    _explicit_container_image=request['image'])
        if inference:
            base.update(inference_aot_mode='consistent', xla_config='maxtext_gpu_inference')
        if profile == 'inference':
            base['maxtext_config_path'] = '/opt/maxtext/src/maxtext/configs/inference/pr_comparison.yml'
            base['custom_mounts'] = (str(api.BUNDLED_REPO / 'inference_legacy_no_tensor_transpose.yml') +
                ':/opt/maxtext/src/maxtext/configs/inference/pr_comparison.yml:ro')
        api.resolve_job_containers(cfg, [base], {})
        api.apply_cluster_defaults(base)
        api.canonicalize_job(base)
        api.validate_job(cfg, base)
        case = dict(workload=name, model=work['model_name'], profile=profile,
                    type='inference' if inference else 'training', trials=[])
        # A discarded OFF pilot primes the persistent kernel autotune cache.
        for index, mode in enumerate([0, 0, 1, 1, 0]):
            job = copy.deepcopy(base)
            job['xla_extra_flags'] = f'--xla_gpu_experimental_enable_early_buffer_release={str(bool(mode)).lower()}'
            directory = ROOT / 'results' / name / f'{index:02d}-mode{mode}'
            env = api.build_env(cfg, job, directory)
            record = dict(index=index, mode=mode, pilot=index == 0, directory=str(directory),
                          type=case['type'], workload=name, model=case['model'])
            metadata = dict(job=job, env=env, trial=record, summary=api.summarize_job(job,cfg),
                            pr_head=request['pr_head'])
            api.write_launch_files(directory, metadata, env, ['true'])
            (directory/'env.json').write_text(json.dumps(env,indent=2)+'\n')
            (directory/'trial.json').write_text(json.dumps(record,indent=2)+'\n')
            case['trials'].append(record)
        cases.append(case)
    (ROOT/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    print(json.dumps([dict(workload=c['workload'],type=c['type']) for c in cases],indent=2))

if __name__ == '__main__':
    main()
