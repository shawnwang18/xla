#!/bin/bash
#SBATCH --account=coreai_dlcompiler_ci
#SBATCH --partition=gb300
#SBATCH --nodes=4
#SBATCH --ntasks-per-node=4
#SBATCH --overcommit
#SBATCH --exclusive
#SBATCH --mem=0
#SBATCH --segment=4
#SBATCH --time=01:25:00
#SBATCH --job-name=coreai_dlcompiler_ci-pr50286.n4-ga3
#SBATCH --output=/lustre/fsw/coreai_dlcompiler_ci/shawnw/bugs/6811592/pr50286-rebased-20261013/n4-ga3/slurm-%j.out
#SBATCH --error=/lustre/fsw/coreai_dlcompiler_ci/shawnw/bugs/6811592/pr50286-rebased-20261013/n4-ga3/slurm-%j.err
set -euo pipefail
python3 /lustre/fsw/coreai_dlcompiler_ci/shawnw/bugs/6811592/pr50286-rebased-20261013/run-case.py n4-ga3
