#!/bin/bash
set -euo pipefail
task_root=/lustre/fsw/coreai_dlcompiler_ci/shawnw/bugs/6811592/pr50286-rebased-20261013
exec > >(tee -a "$task_root/build.log") 2>&1
trap 'rc=$?; python3 - "$task_root" "$rc" <<'"'"'PY'"'"'
import datetime,json,sys
from pathlib import Path
p=Path(sys.argv[1]);rc=int(sys.argv[2])
(p/"build_status.json").write_text(json.dumps(dict(state="COMPLETED" if rc==0 else "FAILED",returncode=rc,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+"\n")
PY
' EXIT
date -u
uname -m
nvidia-smi
test -d /opt/jax
test -x /usr/local/bin/build-jax.sh
test -d "$task_root/build/xla/xla"
cp /usr/local/bin/build-jax.sh "$task_root/build-jax.sh.snapshot"
if [ ! -d "$task_root/build/jax" ]; then cp -a /opt/jax "$task_root/build/jax"; fi
export TMPDIR="$task_root/build/tmp" TEST_TMPDIR="$task_root/build/test_tmp"
export PIP_CACHE_DIR="$task_root/build/pip_cache"
export XDG_CACHE_HOME="$task_root/build/xdg_cache"
export JAX_COMPILATION_CACHE_DIR="$task_root/build/jax_cache"
export PYTHONUSERBASE="$task_root/build/python-user"
mkdir -p "$TMPDIR" "$TEST_TMPDIR" "$PIP_CACHE_DIR" "$XDG_CACHE_HOME" "$JAX_COMPILATION_CACHE_DIR" "$PYTHONUSERBASE"
python3 - "$task_root" <<'PY'
import pathlib,json,subprocess,hashlib,sys
r=pathlib.Path(sys.argv[1]);request=json.loads((r/'request.json').read_text())
assert hashlib.file_digest((r/'xla-source.tar.gz').open('rb'),'sha256').hexdigest()==request['source_archive_sha256']
for name,sha in json.loads((r/'source-files.json').read_text()).items():
 assert hashlib.sha256((r/'build/xla'/name).read_bytes()).hexdigest()==sha,name
revisions={}
for name in ['jax','xla','maxtext']:
 p=pathlib.Path('/opt')/name
 q=subprocess.run(['git','-C',str(p),'rev-parse','HEAD'],text=True,capture_output=True)
 revisions[name]=q.stdout.strip() if q.returncode==0 else None
(r/'container-source-revisions.json').write_text(json.dumps(revisions,indent=2)+'\n')
print('SOURCE_VERIFIED',request['pr_head'],revisions,flush=True)
PY
/usr/local/bin/build-jax.sh \
  --src-path-jax "$task_root/build/jax" \
  --src-path-xla "$task_root/build/xla" \
  --build-path-jaxlib "$task_root/jaxlibs" \
  --bazel-cache http://bazel-tf-cache.nvidia.com:9091 \
  --sm 10.0,10.3 \
  "--build-param=--bazel_startup_options=--output_user_root=$task_root/build/bazel" \
  --build-param=--bazel_startup_options=--batch \
  --build-param=--bazel_startup_options=--host_jvm_args=-Xmx16g \
  --build-param=--bazel_options=--remote_upload_local_results=false \
  --build-param=--bazel_options=--jobs=64 \
  --build-param=--bazel_options=--local_resources=memory=192000 \
  --no-install
python3 - "$task_root" <<'PY'
import pathlib,json,hashlib,sys,os
r=pathlib.Path(sys.argv[1]);q=json.loads((r/'request.json').read_text())
files={str(p.relative_to(r/'jaxlibs')):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in (r/'jaxlibs').rglob('*.so')}
assert files
d=dict(pr_commit=q['pr_head'],pass_name='recompute-fusion-side-outputs',container=q['container'],libraries=files,source_archive_sha256=q['source_archive_sha256'],build_job=os.environ['SLURM_JOB_ID'])
d['pass']=d.pop('pass_name')
(r/'jaxlibs/build-manifest.json').write_text(json.dumps(d,indent=2)+'\n')
print('BUILT_LIBRARIES',len(files),flush=True)
PY
python3 -m pip install --user --no-deps --no-build-isolation \
  -e "$task_root/jaxlibs/jaxlib" -e "$task_root/jaxlibs/jax_cuda13_pjrt" -e "$task_root/jaxlibs/jax_cuda13_plugin"
export PYTHONPATH="$task_root/jaxlibs/jaxlib:$task_root/jaxlibs/jax_cuda13_pjrt:$task_root/jaxlibs/jax_cuda13_plugin"
CUDA_VISIBLE_DEVICES=0 XLA_PYTHON_CLIENT_PREALLOCATE=false python3 - <<'PY'
import jax,jaxlib,jax.numpy as jnp
import jax_plugins.xla_cuda13 as plugin
assert 'pr50286-rebased-20261013/jaxlibs' in jaxlib.__file__,jaxlib.__file__
assert 'pr50286-rebased-20261013/jaxlibs' in plugin.__file__,plugin.__file__
for mode in (0,2):
 y=jax.jit(lambda x:x@x+1,compiler_options={'xla_gpu_experimental_fusion_recomputation':mode})(jnp.ones((32,32))).block_until_ready()
 assert float(y[0,0])==33
print('SMOKE_PASS',jax.__version__,jaxlib.__version__,jax.devices(),flush=True)
PY
touch "$task_root/jaxlibs/BUILD_READY"
