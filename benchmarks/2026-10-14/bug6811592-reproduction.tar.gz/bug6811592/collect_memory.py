"""Collect allocator peaks and sampled physical memory independently of HLO allocation."""
import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
plan = json.loads((ROOT / 'plan.json').read_text())
rows = []
for output in sorted((ROOT / 'outputs').glob('*')):
    status_path = output / 'run-status.json'
    if not status_path.exists():
        continue
    status = json.loads(status_path.read_text())
    ranks = []
    for path in sorted(output.glob('output-*-*-*.txt')):
        text = path.read_text(errors='replace')
        stats = [json.loads(s) for s in re.findall(r'^PERF_DEVICE_MEMORY (.+)$', text, re.M)]
        wall = re.findall(r'^PERF_PROCESS_WALL_SECONDS ([\d.]+)', text, re.M)
        ranks.append(dict(path=str(path), device_memory=stats,
                          process_wall_seconds=float(wall[-1]) if wall else None))
    devices = []
    for path in sorted(output.glob('gpu-memory-node-*.csv')):
        samples = {}
        malformed = 0
        for fields in csv.reader(path.open()):
            if not fields:
                continue
            try:
                timestamp, device, used, total = [x.strip() for x in fields]
                samples.setdefault(device, []).append((timestamp, float(used), float(total)))
            except (ValueError, TypeError):
                malformed += 1
        for device, values in samples.items():
            devices.append(dict(node=int(path.stem.rsplit('-', 1)[1]), device=device,
                                samples=len(values), peak_used_gib=max(v[1] for v in values)/1024,
                                total_gib=values[0][2]/1024, first_sample=values[0][0],
                                last_sample=values[-1][0], malformed_lines=malformed))
    peaks = [d['stats'].get('peak_bytes_in_use') for rank in ranks
             for d in rank['device_memory'] if d.get('stats')]
    complete = (status['exit_code'] == 0 and len(ranks) == plan['gpus_per_ga'] and
                len(peaks) == plan['gpus_per_ga'] and all(v is not None for v in peaks) and
                all(rank['process_wall_seconds'] is not None for rank in ranks) and
                len(devices) == plan['gpus_per_ga'] and all(d['samples'] >= 2 for d in devices))
    row = dict(status=status, complete=complete, ranks=ranks, physical_devices=devices,
               allocator_peak_max_gib=max(peaks)/(1<<30) if peaks and all(v is not None for v in peaks) else None,
               physical_peak_max_gib=max((d['peak_used_gib'] for d in devices), default=None))
    rows.append(row)
result = dict(runs=rows, complete=len(rows)==4 and all(r['complete'] for r in rows),
              units='GiB per GPU', sampling_interval_ms=1000,
              scope='Process lifetime, including compilation and training; sampled physical peaks are lower bounds. Allocator counters include reserved-pool behavior and are distinct from compiled HLO allocation.')
(ROOT / 'runtime-memory.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(runs=len(rows), complete=result['complete'])))
