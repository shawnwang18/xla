"""Serial OFF/ON repetitions on one exclusive allocation; no retries."""
from pathlib import Path
import datetime
import fcntl
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
case = next(c for c in json.loads((ROOT / 'matrix.json').read_text())['cases']
            if c['name'] == sys.argv[1])
work = ROOT / case['name']
lock = (work / 'run.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (work / 'case-status.json').exists(), 'Case already started; reconcile first'
build = json.loads((ROOT / 'build_status.json').read_text())
assert build['state'] == 'COMPLETED' and build['returncode'] == 0
assert (ROOT / 'jaxlibs/BUILD_READY').exists()
state = dict(state='RUNNING', job_id=os.environ['SLURM_JOB_ID'],
             nodes=os.environ['SLURM_JOB_NODELIST'], case=case['name'], runs=[])

def save():
    p = work / 'case-status.json'
    t = p.with_suffix('.tmp')
    t.write_text(json.dumps(state, indent=2) + '\n')
    t.replace(p)

save()
for sequence, mode in enumerate(['OFF', 'ON', 'ON', 'OFF'], 1):
    if not json.loads((ROOT / 'control.json').read_text())['enabled']:
        state.update(state='STOPPED_BY_CONTROL')
        save()
        raise SystemExit(1)
    name = f"{state['job_id']}_ga{case['ga']}-n{case['nodes']}-l{case['layers']}-recompute{mode}-r{sequence}"
    output = work / 'outputs' / name
    output.mkdir(parents=True)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    item = dict(sequence=sequence, variant=mode, state='RUNNING', directory=str(output), started_utc=started)
    state['runs'].append(item)
    save()
    command = ['srun', f"--nodes={case['nodes']}", f"--ntasks={case['nodes']*4}",
               '--ntasks-per-node=4', '--overcommit', '--kill-on-bad-exit=1',
               f"--time={case['run_minutes']}", f'--job-name=pr50286-{mode}-{sequence}',
               f'--output={output}/output-%j-%n-%t.txt', f'--error={output}/output-%j-%n-%t.txt',
               '--container-image=' + case['container'],
               '--container-mounts=' + ','.join([f'{work}:/opt/workspace', f'{ROOT}/maxtext:/opt/maxtext',
                                                f'{ROOT}/jaxlibs:/opt/jaxlibs']),
               'bash', '/opt/workspace/run-one.sh', str(case['ga']), mode, str(sequence)]
    (output / 'launch.json').write_text(json.dumps(command, indent=2) + '\n')
    start = time.monotonic()
    with (output / 'srun.log').open('w') as log:
        returncode = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT).returncode
    finished = datetime.datetime.now(datetime.timezone.utc).isoformat()
    status = dict(job_id=state['job_id'], nodes=state['nodes'], num_nodes=case['nodes'],
                  ga=case['ga'], variant=mode, sequence=sequence, exit_code=returncode,
                  started_utc=started, ended_utc=finished, process_step_wall_seconds=time.monotonic()-start)
    step_file = output / 'step.json'
    if step_file.exists():
        status['step_id'] = json.loads(step_file.read_text())['step_id']
    (output / 'run-status.json').write_text(json.dumps(status, indent=2) + '\n')
    item.update(status, state='COMPLETED' if returncode == 0 else 'FAILED')
    save()
    if returncode:
        state.update(state='FAILED', reason='Trial failed; no automatic retry.', finished_utc=finished)
        save()
        raise SystemExit(returncode)
    subprocess.run(['python3', str(work / 'verify_long_hlo.py'), '--ga', str(case['ga'])], check=True)
    subprocess.run(['python3', str(work / 'collect_long.py'), '--ga', str(case['ga'])], check=True)
    subprocess.run(['python3', str(work / 'collect_memory.py')], check=True)

result = json.loads((work / 'results.json').read_text())
memory = json.loads((work / 'runtime-memory.json').read_text())
valid = result['complete'] and memory['complete']
state.update(state='COMPLETED' if valid else 'VALIDATION_FAILED',
             training_valid=result['complete'], hlo_verified=result['all_hlos_verified'],
             runtime_memory_valid=memory['complete'],
             finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
raise SystemExit(0 if valid else 1)
