#!/bin/bash
set -euo pipefail

# This script runs inside the container
# All variables are substituted by launcher.py

# === Parallelism configuration ===
DP=1
FSDP=4
TP=1
EP=4
DCN_DP=1
DCN_FSDP=1
DCN_TP=1
DCN_EP=1
OPTIM_SHARD_OVER_DATA=false

echo "ICI Parallelism: DP=$DP, FSDP=$FSDP, TP=$TP, EP=$EP"
echo "DCN Parallelism: DP=$DCN_DP, FSDP=$DCN_FSDP, TP=$DCN_TP, EP=$DCN_EP"
echo "Optimizer sharding over data: $OPTIM_SHARD_OVER_DATA"

# === Run name (set by launcher, matches output directory) ===
TASK_GA=${1:?gradient accumulation required}
TASK_VARIANT=${2:?ON or OFF required}
TASK_SEQUENCE=${3:?sequence required}
[[ "$TASK_GA" == 2 || "$TASK_GA" == 3 ]]
[[ "$TASK_VARIANT" == ON || "$TASK_VARIANT" == OFF ]]
RUN_NAME="ga${TASK_GA}-n4-l5-recompute${TASK_VARIANT}-r${TASK_SEQUENCE}"
# Prepend SLURM job ID if available
if [ -n "$SLURM_JOB_ID" ]; then
  RUN_NAME="${SLURM_JOB_ID}_${RUN_NAME}"
fi

# === Environment variables ===
export XLA_PYTHON_CLIENT_MEM_FRACTION="0.88"
export CUDA_DEVICE_MAX_CONNECTIONS="16"
export NVTE_FUSED_ATTN="1"
export DECOUPLE_GCLOUD="TRUE"
export XLA_PJRT_GPU_HOST_MEMORY_PREALLOCATE="false"
export XLA_PJRT_GPU_HOST_MEMORY_LIMIT_GB="180"
export NVTE_MAXTEXT_DO_FSDP_AG_IN_BF16="1"
export TF_CPP_VMODULE="compilation_stats=10,buffer_assignment=1,compile_module_to_llvm_ir=1,fusion_recomputation=1,recompute_fusion_side_outputs=2"
export TF_CPP_MIN_LOG_LEVEL="0"
export TF_CPP_MAX_LOG_LEVEL="10"
export RECOMPUTE_VARIANT="$TASK_VARIANT"
export JAX_COMPILATION_CACHE_DIR="/opt/workspace/jax_cache/${RUN_NAME}"

# === XLA Flags ===
TASK_DISABLED=rematerialization
TASK_RECOMPUTE=0
if [[ "$TASK_VARIANT" == ON ]]; then TASK_RECOMPUTE=2; fi
# Runtime flags apply on every rank. Dump flags (xla_dump_*/xla_gpu_dump_*) apply
# on every rank unless dump_rank_0_only=true.
XLA_FLAGS="--xla_gpu_experimental_fusion_recomputation=${TASK_RECOMPUTE} --xla_gpu_enable_latency_hiding_scheduler=true --xla_gpu_enable_triton_gemm=false --xla_gpu_enable_highest_priority_async_stream=true --xla_gpu_all_reduce_combine_threshold_bytes=33554432 --xla_gpu_all_gather_combine_threshold_bytes=6442450944 --xla_gpu_reduce_scatter_combine_threshold_bytes=201326592 --xla_gpu_enable_pipelined_all_gather=true --xla_gpu_enable_pipelined_reduce_scatter=true --xla_gpu_enable_pipelined_all_reduce=true --xla_gpu_enable_while_loop_double_buffering=true --xla_gpu_enable_all_gather_combine_by_dim=false --xla_gpu_enable_reduce_scatter_combine_by_dim=false --xla_disable_hlo_passes=${TASK_DISABLED} --xla_gpu_enable_command_buffer='FUSION,CUBLAS,CUDNN,DYNAMIC_SLICE_FUSION' --xla_gpu_experimental_enable_nccl_symmetric_buffers=false --xla_gpu_experimental_use_ragged_dot_fusion=true --xla_gpu_enable_cublaslt=false --xla_gpu_experimental_max_unroll_factor=8 --xla_gpu_print_compilation_stats=true --xla_gpu_memory_limit_slop_factor=99"
SLURM_PROCID=${SLURM_PROCID:-0}
if [ -n "--xla_dump_hlo_as_text=true --xla_dump_to=/opt/workspace/hlo_dumps/${RUN_NAME} --xla_dump_hlo_pass_re=recompute-fusion-side-outputs" ]; then
  if [ "$SLURM_PROCID" != "0" ]; then
    echo "HLO dump skipped on rank $SLURM_PROCID (dump_rank_0_only=true)"
  else
    XLA_FLAGS="$XLA_FLAGS --xla_dump_hlo_as_text=true --xla_dump_to=/opt/workspace/hlo_dumps/${RUN_NAME} --xla_dump_hlo_pass_re=recompute-fusion-side-outputs"
    echo "HLO dump enabled on rank $SLURM_PROCID (dump_rank_0_only=true)"
  fi
fi
export XLA_FLAGS

# PGLE flags
if [ "true" = "true" ]; then
  export JAX_ENABLE_PGLE=true
  export JAX_PGLE_PROFILING_RUNS=3
else
  export JAX_ENABLE_PGLE=false
fi

# === Profiling ===
# Note: nsys and PGLE both use CUPTI and cannot coexist. Use xplane with PGLE instead.
PROF_COMMAND=()
if [ "xplane" = "nsys" ] && [ "true" != "true" ]; then
  mkdir -p /opt/workspace/nsys_logs/${RUN_NAME}
  NSYS_OUTPUT="/opt/workspace/nsys_logs/${RUN_NAME}/${RUN_NAME}"
  PROF_COMMAND=(nsys profile -s none -o "${NSYS_OUTPUT}" --force-overwrite true
    --capture-range=cudaProfilerApi --cuda-graph-trace=node --capture-range-end=stop --trace=cuda,nvtx)
fi

# === Create output directories ===
mkdir -p /opt/workspace/outputs/${RUN_NAME}
mkdir -p /opt/workspace/hlo_dumps/${RUN_NAME}

# Verify the requested compiler libraries before starting distributed training.
export PYTHONPATH="/opt/jaxlibs/jaxlib:/opt/jaxlibs/jax_cuda13_pjrt:/opt/jaxlibs/jax_cuda13_plugin${PYTHONPATH:+:$PYTHONPATH}"
python - <<'PYVERIFY'
import hashlib, importlib, json, os
from pathlib import Path
import jax, jaxlib
manifest=json.loads(Path('/opt/jaxlibs/build-manifest.json').read_text())
assert manifest['pass']=='recompute-fusion-side-outputs', manifest
assert manifest['pr_commit']=='3c5d6db0a29728982cfc2aeda3f003c1fa128f61', manifest
assert '/opt/jaxlibs/' in jaxlib.__file__, jaxlib.__file__
plugin=importlib.import_module('jax_plugins.xla_cuda13')
assert '/opt/jaxlibs/' in plugin.__file__, plugin.__file__
if int(os.environ.get('SLURM_PROCID','0')) == 0:
    for name in ('jaxlib/jaxlib/libjax_common.so','jax_cuda13_pjrt/jax_plugins/xla_cuda13/xla_cuda_plugin.so'):
        h=hashlib.sha256()
        with (Path('/opt/jaxlibs')/name).open('rb') as f:
            for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
        assert h.hexdigest()==manifest['libraries'][name], name
    print('PERF_LIBRARY_HASHES_VERIFIED',flush=True)
    source=json.loads(Path('/opt/workspace/maxtext-source-manifest.json').read_text())
    for name,expected in source['files'].items():
        assert hashlib.sha256((Path('/opt/maxtext')/name).read_bytes()).hexdigest()==expected,name
    print('PERF_MAXTEXT_SOURCE_VERIFIED',source['commit'],flush=True)
print('PERF_BUILD', json.dumps(manifest,sort_keys=True),flush=True)
print('PERF_LIBRARIES',jax.__version__,jaxlib.__version__,jaxlib.__file__,plugin.__file__,flush=True)
PYVERIFY

# One lightweight physical-memory sampler per node.
export RUN_NAME
TASK_MEMORY_PID=
if [[ "${SLURM_LOCALID:-0}" == 0 ]]; then
  nvidia-smi --query-gpu=timestamp,index,memory.used,memory.total --format=csv,noheader,nounits -lms 1000 > "/opt/workspace/outputs/${RUN_NAME}/gpu-memory-node-${SLURM_NODEID}.csv" 2> "/opt/workspace/outputs/${RUN_NAME}/gpu-memory-node-${SLURM_NODEID}.err" &
  TASK_MEMORY_PID=$!
fi
stop_memory_sampler() {
  if [[ -n "$TASK_MEMORY_PID" ]]; then kill "$TASK_MEMORY_PID" 2>/dev/null || true; wait "$TASK_MEMORY_PID" 2>/dev/null || true; fi
}
trap stop_memory_sampler EXIT
if [[ "${SLURM_PROCID:-0}" == 0 ]]; then
  python3 - <<'PYSTEP'
import json,os,pathlib
d=dict(step_id=os.environ['SLURM_JOB_ID']+'.'+os.environ['SLURM_STEP_ID'], nodes=os.environ['SLURM_JOB_NODELIST'])
(pathlib.Path('/opt/workspace/outputs')/os.environ['RUN_NAME']/'step.json').write_text(json.dumps(d,indent=2)+'\n')
print('PERF_STEP',json.dumps(d),flush=True)
PYSTEP
fi

# === Run training ===
MAXTEXT_ROOT=/opt/maxtext
cd "$MAXTEXT_ROOT" || exit 1
export PYTHONPATH="$MAXTEXT_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"

# NUMA binding for GPU affinity
SLURM_LOCALID=${SLURM_LOCALID:-0}
GPUS_PER_NODE=4
NUMA_ID=$((SLURM_LOCALID / (GPUS_PER_NODE / 2)))
CPUBIND=(numactl "--cpunodebind=$NUMA_ID" "--membind=$NUMA_ID")
echo "NUMA binding: LOCALID=$SLURM_LOCALID, GPUS_PER_NODE=$GPUS_PER_NODE, NUMA_ID=$NUMA_ID"

COMMAND=("${CPUBIND[@]}" "${PROF_COMMAND[@]}"
  python /opt/workspace/run-training.py src/maxtext/configs/base.yml
  "run_name=${RUN_NAME}"
  "base_output_directory=/opt/workspace/outputs/${RUN_NAME}"
  "jax_cache_dir=/opt/workspace/jax_cache/${RUN_NAME}"
  model_name=deepseek3-671b
  max_target_length=4096
  per_device_batch_size=6
  "gradient_accumulation_steps=${TASK_GA}"
  steps=165
  attention=cudnn_flash_jax
  remat_policy=custom
  enable_checkpointing=false
  dataset_type=synthetic
  dataset_path=local
  hardware=gpu_multiprocess
  quantization=te_fp8_currentscaling
  profiler=xplane
  skip_first_n_steps_for_profiler=50
  profiler_steps=51
  scan_layers=true
  shardy=true
  sparse_matmul=true
  ici_data_parallelism=1
  ici_fsdp_parallelism=4
  ici_tensor_parallelism=1
  ici_expert_parallelism=4
  dcn_data_parallelism=1
  dcn_fsdp_parallelism=1
  dcn_tensor_parallelism=1
  dcn_expert_parallelism=1
  shard_optimizer_over_data=false
  weight_dtype=bfloat16
  mu_dtype=bfloat16
  logits_dot_in_fp32=false
  use_iota_embed=false
  enable_goodput_recording=false
  monitor_goodput=false
  n_routing_groups=-1
  topk_routing_group=-1
  capacity_factor=1.0
  megablox=false
  te_moe_block=true
  te_gmm_quantization=te_mxfp8
  ragged_buffer_factor=2.0
  te_ep_overflow_check_every_n_steps=20
  prefuse_moe_weights=true
  shard_exp_on_fsdp=false
  mlpwi=device
  mlpwi_0=device
  mlpwi_1=device
  mlpwo=device
  moe_mlpwi_0=offload
  moe_mlpwi_1=offload
  moe_mlpwo=device
  query_proj=remat
  key_proj=remat
  value_proj=remat
  query_wa_proj=device
  kv_wa_proj=device
  out_proj=device
  context=device
  override_model_config=true
  base_num_decoder_layers=5
  first_num_dense_layers=1
  num_experts=128
)

printf 'Command: '
printf '%q ' "${COMMAND[@]}"
printf '\n'
echo ""

{
  echo "=== Configuration ==="
  echo "Model: deepseek3-671b"
  echo "Parallelism: DP=${DP}, FSDP=${FSDP}, DCN_DP=${DCN_DP}, DCN_FSDP=${DCN_FSDP}"
  echo "Batch size: 6, Grad accum: ${TASK_GA}; profile: 50-100; timing: 110-159"
  echo "XLA_FLAGS: $XLA_FLAGS"
  echo "===================="
  echo ""

  "${COMMAND[@]}"
} 2>&1
