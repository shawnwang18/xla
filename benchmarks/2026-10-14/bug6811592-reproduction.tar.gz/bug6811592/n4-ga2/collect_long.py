"""Collect repeated training runs; incomplete runs never become performance rows."""
import argparse
import fcntl
import json
import math
import os
import re
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT/'plan.json').read_text())
EXPECTED_RANKS = PLAN['gpus_per_ga']
EXPECTED_RUNS = 4*len(PLAN['ga'])
WINDOWS = {'early': (10, 49), 'profiled': (50, 100), 'primary': (110, 159)}
STEP = re.compile(r'completed step:\s*(\d+), seconds:\s*([\d.]+), TFLOP/s/device:\s*([\d.]+), Tokens/s/device:\s*([\d.]+).*?\bloss:\s*([^, ]+)')
ERROR = re.compile(r'Traceback \(most recent|RESOURCE_EXHAUSTED|Check failed:|JaxRuntimeError:|NCCL error|CUDA_ERROR')


def summarize(values):
    ordered = sorted(values)
    def quantile(q):
        position = (len(ordered)-1)*q
        low = int(position)
        return ordered[low] + (ordered[min(low+1,len(ordered)-1)]-ordered[low])*(position-low)
    return dict(n=len(values), mean_s=statistics.mean(values), median_s=statistics.median(values),
                stdev_s=statistics.stdev(values) if len(values)>1 else 0,
                p05_s=quantile(.05), p95_s=quantile(.95), min_s=min(values), max_s=max(values))


def parse_log(path):
    text = path.read_text(errors='replace')
    steps = {}
    for match in STEP.finditer(text):
        n, seconds, tflops, tokens, loss = match.groups()
        steps[int(n)] = dict(seconds=float(seconds), tflops=float(tflops), tokens_s=float(tokens), loss=float(loss))
    allocations = []
    for block in re.findall(r'Buffer Assignment Stats for jit_train_step\n(.*?)(?:\n\n)',text,re.S):
        values = {}
        for name, value, unit in re.findall(r'(parameter allocation|constant allocation|maybe_live_out allocation|preallocated temp allocation|preallocated temp fragmentation|total allocation|total fragmentation):\s+([\d.]+)(GiB|MiB|KiB|B)',block):
            values[name] = float(value)*{'GiB':1,'MiB':1/1024,'KiB':1/1048576,'B':1/(1<<30)}[unit]
        if 'total allocation' in values:
            allocations.append(values)
    windows = {}
    for name,(start,end) in WINDOWS.items():
        selected = [steps[i]['seconds'] for i in range(start,end+1) if i in steps]
        if len(selected)==end-start+1:
            windows[name] = summarize(selected)
    manifest_match = re.search(r'^PERF_BUILD (.+)$',text,re.M)
    build = json.loads(manifest_match[1]) if manifest_match else None
    cost_blocks = re.findall(r'Fusion recomputation: (.*?)(?=\n[IWEF]\d{4}|\Z)', text, re.S)
    cost_reports = []
    for block in cost_blocks:
        fields = dict(re.findall(r'^(\w+)=([^\n]+)', block, re.M))
        if fields:
            cost_reports.append(fields)
    decision_lines = [line[:1200] for line in text.splitlines()
                      if 'recompute_fusion_side_outputs.cc:' in line and 'Recomputation ' in line]
    ep_capacities = re.findall(r'max_tokens_per_rank=(\d+) recv_capacity_per_rank=(\d+)', text)
    return dict(file=str(path),steps=steps,windows=windows,allocation_compilations=allocations,
                cost_reports=cost_reports, recomputation_decisions=decision_lines,
                ep_capacities=ep_capacities,
                ep_capacity_verified=bool(ep_capacities) and all(a=='24576' and b=='393216' for a,b in ep_capacities),
                initial_gib=allocations[0]['total allocation'] if allocations else None,
                post_pgle_gib=allocations[-1]['total allocation'] if len(allocations)>1 else None,
                finite_losses=bool(steps) and all(math.isfinite(v['loss']) for v in steps.values()),
                oom_seen=bool(re.search(r'CUDA_ERROR_OUT_OF_MEMORY|RESOURCE_EXHAUSTED|out of memory|Out of memory',text)),
                infrastructure_failure=bool(re.search(r'401 Unauthorized|failed to import docker image|task_init\(\) failed|Failed to invoke spank',text)),
                errors=[line[:800] for line in text.splitlines() if ERROR.search(line)][-6:],
                build_verified=bool(build and build['pr_commit']=='3c5d6db0a29728982cfc2aeda3f003c1fa128f61'),
                libraries_verified='PERF_LIBRARY_HASHES_VERIFIED' in text,
                source_verified='PERF_MAXTEXT_SOURCE_VERIFIED' in text)


def collect_run(directory):
    status=json.loads((directory/'run-status.json').read_text())
    ranks=[parse_log(f) for f in sorted(directory.glob('output-*-*-*.txt'))]
    rank0=next((r for r in ranks if r['file'].endswith('-0-0.txt')),None)
    complete=(status['exit_code']==0 and len(ranks)==EXPECTED_RANKS and rank0 is not None and
              all(set(r['steps'])==set(range(165)) and r['finite_losses'] and r['build_verified'] and r['ep_capacity_verified']
                  and len(r['allocation_compilations'])>=2 for r in ranks) and
              rank0['libraries_verified'] and rank0['source_verified'])
    outcome = 'completed' if complete else ('infrastructure_failure' if any(r['infrastructure_failure'] for r in ranks) else 'out_of_memory' if any(r['oom_seen'] for r in ranks) else 'failed_or_incomplete')
    row=dict(**status,directory=str(directory),valid=complete,outcome=outcome,ranks=ranks,
             rank0=rank0,profile_summary=None)
    profile_file=directory/'profile-summary.json'
    if profile_file.exists():row['profile_summary']=json.loads(profile_file.read_text())
    hlo_file=directory/'hlo-summary.json'
    row['hlo_summary']=json.loads(hlo_file.read_text()) if hlo_file.exists() else None
    if complete:
        row['memory']={stage:dict(rank0_gib=rank0[stage+'_gib'],
            min_gib=min(r[stage+'_gib'] for r in ranks),max_gib=max(r[stage+'_gib'] for r in ranks))
            for stage in ('initial','post_pgle')}
    dumps=ROOT/'hlo_dumps'/directory.name
    modules=sorted(dumps.glob('module_*.jit_train_step.*gpu_after_optimizations-memory-usage-report.txt'),
                   key=lambda f:int(re.search(r'module_(\d+)',f.name)[1]))
    row['hlo_memory_reports']=[str(f) for f in modules]
    return row


def markdown_table(headers, rows):
    rows=[[str(v) for v in row] for row in rows]
    widths=[max(3,len(h),*(len(r[i]) for r in rows)) for i,h in enumerate(headers)] if rows else [max(3,len(h)) for h in headers]
    def line(row):return '| '+' | '.join(v.ljust(w) for v,w in zip(row,widths))+' |'
    return '\n'.join([line(headers),line(['-'*w for w in widths]),*(line(r) for r in rows)])


def write_atomic(path, text):
    temporary=path.with_name(path.name+f'.tmp.{os.getpid()}')
    temporary.write_text(text)
    temporary.replace(path)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--ga',type=int,choices=(2,3));args=parser.parse_args()
    rows=[]
    for path in sorted((ROOT/'outputs').glob('*')):
        if not (path/'run-status.json').exists():continue
        if args.ga and f'_ga{args.ga}-' not in path.name:continue
        rows.append(collect_run(path))
    # Each GA writes an independent file. The aggregate is rebuilt under a lock.
    if args.ga:write_atomic(ROOT/f'results-ga{args.ga}.json',json.dumps(rows,indent=2)+'\n')
    with (ROOT/'collect.lock').open('w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if args.ga:
            rows=[]
            for f in sorted(ROOT.glob('results-ga[23].json')):rows.extend(json.loads(f.read_text()))
        rows.sort(key=lambda r:(r['ga'],r['sequence']))
        summary=[]
        pairs=[]
        for ga in PLAN['ga']:
            matching=[r for r in rows if r['ga']==ga and r['valid']]
            for variant in ('OFF','ON'):
                group=[r for r in matching if r['variant']==variant]
                if len(group)!=2:continue
                windows={name:summarize([r['rank0']['steps'].get(i,r['rank0']['steps'].get(str(i)))['seconds']
                      for r in group for i in range(start,end+1)]) for name,(start,end) in WINDOWS.items()}
                summary.append(dict(ga=ga,variant=variant,run_sequences=[r['sequence'] for r in group],
                    windows=windows,run_primary_means_s=[r['rank0']['windows']['primary']['mean_s'] for r in group],
                    initial_rank0_gib=[r['rank0']['initial_gib'] for r in group],
                    post_pgle_rank0_gib=[r['rank0']['post_pgle_gib'] for r in group]))
            for pair_number,off_sequence,on_sequence in ((1,1,2),(2,4,3)):
                off=next((r for r in matching if r['sequence']==off_sequence),None)
                on=next((r for r in matching if r['sequence']==on_sequence),None)
                if off and on:
                    a=off['rank0']['windows']['primary']['mean_s'];b=on['rank0']['windows']['primary']['mean_s']
                    pairs.append(dict(ga=ga,pair=pair_number,off_sequence=off_sequence,on_sequence=on_sequence,
                                      off_mean_s=a,on_mean_s=b,latency_change_percent=100*(b/a-1),
                                      max_rank0_logged_loss_difference=max(abs(
                                          off['rank0']['steps'].get(i, off['rank0']['steps'].get(str(i)))['loss']-
                                          on['rank0']['steps'].get(i, on['rank0']['steps'].get(str(i)))['loss'])
                                          for i in range(165)),
                                      same_nodes=off['nodes']==on['nodes']))
        result=dict(runs=rows,summary=summary,paired_comparisons=pairs,
                    complete=len(rows)==EXPECTED_RUNS and all(r['valid'] for r in rows),
                    all_hlos_verified=len(rows)==EXPECTED_RUNS and all(r['hlo_summary'] and r['hlo_summary']['valid'] for r in rows),
                    all_profiles_verified=len(rows)==EXPECTED_RUNS and all(r.get('profile_summary',{}).get('valid',False) if r.get('profile_summary') else False for r in rows))
        write_atomic(ROOT/'results.json',json.dumps(result,indent=2)+'\n')
        aggregate_table=markdown_table(['GA','Mode','Samples','Primary mean (s)','Median (s)','Stdev (s)','Run means (s)','Profiled mean (s)'],[
            [r['ga'],r['variant'],r['windows']['primary']['n'],f"{r['windows']['primary']['mean_s']:.6f}",
             f"{r['windows']['primary']['median_s']:.6f}",f"{r['windows']['primary']['stdev_s']:.6f}",
             ', '.join(f'{v:.6f}' for v in r['run_primary_means_s']),f"{r['windows']['profiled']['mean_s']:.6f}"] for r in summary])
        run_table=markdown_table(['GA','Order','Mode','Valid','Primary mean (s)','Profiled mean (s)','Initial rank0 (GiB)','Post-PGLE rank0 (GiB)'],[
            [r['ga'],r['sequence'],r['variant'],r['valid'],
             f"{r['rank0']['windows']['primary']['mean_s']:.6f}" if r['valid'] else 'pending/invalid',
             f"{r['rank0']['windows']['profiled']['mean_s']:.6f}" if r['valid'] else 'pending/invalid',
             r['rank0']['initial_gib'] if r['rank0'] else '',r['rank0']['post_pgle_gib'] if r['rank0'] else ''] for r in rows])
        pair_table=markdown_table(['GA','Pair','OFF mean (s)','ON mean (s)','Latency change','Same nodes'],[
            [r['ga'],r['pair'],f"{r['off_mean_s']:.6f}",f"{r['on_mean_s']:.6f}",f"{r['latency_change_percent']:+.3f}%",r['same_nodes']] for r in pairs])
        memory_rows=[]
        for r in rows:
            if not r['valid']:continue
            for stage,compilation in [('initial',0),('post_pgle',-1)]:
                memory=r['memory'][stage]
                exact=r['hlo_summary']['stages'][stage]['allocation_gib'] if r['hlo_summary'] and stage in r['hlo_summary'].get('stages',{}) else None
                allocation=r['rank0']['allocation_compilations'][compilation]
                memory_rows.append([r['ga'],r['sequence'],r['variant'],stage,
                    f'{exact:.6f}' if exact is not None else memory['rank0_gib'],
                    f"{memory['min_gib']:.2f}–{memory['max_gib']:.2f}",
                    allocation.get('preallocated temp allocation',''),allocation.get('total fragmentation','')])
        memory_table=markdown_table(['GA','Order','Mode','Compilation','Rank0 total (GiB)',f'{EXPECTED_RANKS}-rank range (GiB)','Rank0 temp (GiB)','Rank0 fragmentation (GiB)'],memory_rows)
        report='Generalized fusion recomputation: bug 6811592 workload comparison\n\nPrimary timing: steps 110–159, after profiling stops; 50 steps per run, two runs per mode. Profiles cover steps 50–100 inclusive. Same 4-node allocation within each GA; OFF–ON–ON–OFF order. Every run has fresh compilation and automatic PGLE.\n\n'+aggregate_table+'\n\n'+run_table+'\n\n'+pair_table+'\n\n'+memory_table+'\n\nMemory is compiled XLA total allocation, not device-wide runtime peak. Rank-0 totals use exact bytes from HLO reports when available; other memory values come from rounded compilation logs. results.json includes per-rank memory, fragmentation, step samples, medians, spread, profile verification, and initial/post-PGLE recomputation verification. A single pooled mean does not establish a stable small effect; inspect both paired comparisons and run-to-run variation.\n'
        write_atomic(ROOT/'results.txt',report)
        state_path=ROOT/'state.json'
        state=json.loads(state_path.read_text())
        state['completed_training_runs']=sum(r['valid'] for r in rows)
        state['verified_profiles']=sum(bool(r.get('profile_summary') and r['profile_summary']['valid']) for r in rows)
        state['verified_hlo_runs']=sum(bool(r.get('hlo_summary') and r['hlo_summary']['valid']) for r in rows)
        if result['complete'] and result['all_profiles_verified'] and result['all_hlos_verified']:state['status']='complete'
        elif len(rows)==EXPECTED_RUNS:state['status']='finished_with_validation_failures'
        else:state['status']='partially_collected'
        write_atomic(state_path,json.dumps(state,indent=2)+'\n')
        print(run_table+'\n\n'+pair_table)


if __name__=='__main__':main()
