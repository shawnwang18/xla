"""Run the authorized case once inside the retained allocation."""
from pathlib import Path
import datetime
import fcntl
import json
import os
import platform
import subprocess

root = Path(__file__).resolve().parent
lock = (root / 'allocation-use.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (root / 'controller-status.json').exists(), 'Reconcile existing controller first'
assert not (root / 'n8-ga3/case-status.json').exists(), 'Case already started'
assert (root / 'ASSETS_READY').exists()
preflight = json.loads((root / 'preflight-status.json').read_text())
assert preflight['state'] == 'COMPLETED' and preflight['all_nodes_verified']
allocation = json.loads((root / 'allocation.json').read_text())
job = allocation['allocation_id']
scheduler = subprocess.check_output(['scontrol', 'show', 'job', job, '-o'], text=True)
assert 'JobState=RUNNING ' in scheduler and 'NumNodes=8 ' in scheduler
steps = subprocess.check_output(['squeue', '--steps', '-j', job, '-h', '-o', '%i'], text=True)
assert not any(s.rsplit('.', 1)[-1].isdigit() for s in steps.split()), steps
state = dict(state='RUNNING', pid=os.getpid(), hostname=platform.node(), allocation_id=job,
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)
save(root / 'controller-status.json', state)
allocation.update(state='RUNNING_N8_GA3', controller_pid=os.getpid(), controller_host=platform.node(),
                  start_time_utc='2026-10-14T00:48:11Z', end_time_utc='2026-10-14T08:48:11Z')
save(root / 'allocation.json', allocation)
env = os.environ.copy()
env.update(SLURM_JOB_ID=job, SLURM_JOB_NODELIST=allocation['nodes'], SLURM_NNODES='8')
try:
    rc = subprocess.run(['python3', str(root / 'run-case.py'), 'n8-ga3'], env=env).returncode
    state.update(state='COMPLETED' if rc == 0 else 'FAILED', exit_code=rc)
    if rc == 0:
        collected = subprocess.run(['python3', str(root / 'collect_results.py')]).returncode
        state['collector_exit_code'] = collected
        if collected:
            state.update(state='FAILED', reason='Collection failed; benchmark data retained')
except Exception as exc:
    state.update(state='FAILED', reason=str(exc))
finally:
    state['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save(root / 'controller-status.json', state)
    allocation.update(state='IDLE_RESERVED', last_case_state=state['state'], updated_at=state['finished_at'])
    save(root / 'allocation.json', allocation)
