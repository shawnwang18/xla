from pathlib import Path
import datetime
import fcntl
import json
import os
import subprocess

root = Path(__file__).resolve().parent
os.environ['ENROOT_CONFIG_PATH'] = str(root / '.enroot')
lock = (root / 'allocation-use.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (root / 'preflight-status.json').exists(), 'Reconcile existing preflight first'
state = dict(state='RUNNING', started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():
    t = root / 'preflight-status.tmp'
    t.write_text(json.dumps(state, indent=2) + '\n')
    t.replace(root / 'preflight-status.json')
save()
req = json.loads((root / 'request.json').read_text())
command = ['srun', '--jobid=2521414', '--nodes=8', '--ntasks=8', '--ntasks-per-node=1',
           '--cpus-per-task=16', '--gres=gpu:GB300:4', '--kill-on-bad-exit=1', '--time=30',
           '--job-name=bug6811592-preflight', '--container-image=' + ('oauth2@' + req['container'].replace('/', '#', 1).replace('@sha256:', ':sha256:')),
           '--container-remap-root', '--container-writable', '--cpu-bind=none', '--container-mounts=' + str(root) + ':/opt/task', '--output=' + str(root) + '/preflight-node-%n.log',
           '--error=' + str(root) + '/preflight-node-%n.log', 'python', '/opt/task/check-node.py']
try:
    code = subprocess.run(command).returncode
    valid = len(list(root.glob('preflight-node-*.json'))) == 8
    state.update(state='COMPLETED' if code == 0 and valid else 'FAILED', exit_code=code,
                 all_nodes_verified=valid)
except Exception as exc:
    state.update(state='FAILED', reason=str(exc))
state['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
