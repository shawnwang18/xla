"""Verify initial and PGLE HLOs and collect exact rank-0 allocation bytes."""
import argparse
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TARGET = 'f32[6,4096,129280]'


def verify_module(hlo, assignment, memory, ga, enabled):
    computations = {}
    current = None
    with hlo.open() as source:
        for number, line in enumerate(source, 1):
            match = re.match(r'^(?:ENTRY )?%([^ ]+) \(', line)
            if match:
                current = dict(name=match[1], line=number, exponentials=[], parameters=[], gradient=False)
                computations[match[1]] = current
            elif current:
                if '= '+TARGET in line and ' exponential(' in line:
                    current['exponentials'].append(number)
                if TARGET in line and ' parameter(' in line:
                    current['parameters'].append(number)
                if 'ROOT' in line and '(bf16[6,4096,129280]' in line:
                    current['gradient'] = True
    consumers = [c for c in computations.values()
                 if c['name'].startswith('fused_convert_reduce') and c['gradient']]
    exponentials = sum(len(c['exponentials']) for c in computations.values())
    saved_buffers = []
    with assignment.open() as source:
        for number, line in enumerate(source, 1):
            if re.search(r'\(size=12708741120,offset=\d+\): f32\[6,4096,129280\]', line):
                saved_buffers.append(dict(line=number, text=line.strip()))
    with memory.open() as source:
        header = ''.join(next(source) for _ in range(2))
    total_bytes = int(re.search(r'Total bytes: (\d+)', header)[1])
    recomputed = sum(len(c['exponentials']) for c in consumers)
    valid = (len(consumers) == ga and exponentials == ga + recomputed
             and len(saved_buffers) == ga - recomputed
             and all(len(c['exponentials']) in (0, 1)
                     and len(c['parameters']) == 1-len(c['exponentials']) for c in consumers)
             and (enabled or recomputed == 0))
    return dict(valid=valid, hlo=str(hlo), assignment=str(assignment), memory_report=str(memory),
                allocation_bytes=total_bytes, allocation_gib=total_bytes/(1 << 30),
                target_exponentials=exponentials, recomputed_gradient_consumers=recomputed, gradient_consumers=consumers,
                saved_exp_buffers=saved_buffers)


def analyze(directory):
    status = json.loads((directory/'run-status.json').read_text())
    dump = ROOT/'hlo_dumps'/directory.name
    modules = sorted(dump.glob('module_*.jit_train_step.*gpu_after_optimizations.txt'),
                     key=lambda p: int(re.search(r'module_(\d+)', p.name)[1]))
    if not modules:
        return dict(valid=False, module_count=0, error='No compiled training HLO')
    stages = {}
    available = [('initial',modules[0])] + ([('post_pgle',modules[-1])] if len(modules)>1 else [])
    for stage, hlo in available:
        prefix = hlo.with_suffix('')
        stages[stage] = verify_module(hlo, Path(str(prefix)+'-buffer-assignment.txt'),
                                     Path(str(prefix)+'-memory-usage-report.txt'),
                                     status['ga'], status['variant'] == 'ON')
    reports = {p.name: p.read_text() for p in sorted(dump.glob('fusion-recomputation.*.txt'))}
    return dict(valid=len(modules)>=2 and all(s['valid'] for s in stages.values()), module_count=len(modules), stages=stages, cost_reports=reports)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--ga', type=int, required=True, choices=(2, 3))
    args = parser.parse_args()
    for directory in sorted((ROOT/'outputs').glob(f'*_ga{args.ga}-*')):
        if not (directory/'run-status.json').exists():
            continue
        try:
            result = analyze(directory)
        except Exception as error:
            result = dict(valid=False, error=f'{type(error).__name__}: {error}')
        (directory/'hlo-summary.json').write_text(json.dumps(result, indent=2)+'\n')
        print(directory.name, 'HLO valid:', result['valid'], result.get('error', ''), flush=True)
