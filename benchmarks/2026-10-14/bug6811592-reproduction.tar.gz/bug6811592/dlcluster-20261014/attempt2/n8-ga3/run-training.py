"""Run the unchanged reproducer entry point and report process/allocator metrics."""
import json
import os
import runpy
import time

started = time.monotonic()
try:
    runpy.run_module('maxtext.trainers.pre_train.train', run_name='__main__')
except SystemExit as error:
    if error.code not in (None, 0):
        raise
finally:
    print('PERF_PROCESS_WALL_SECONDS', time.monotonic() - started, flush=True)
import jax
for device in jax.local_devices():
    print('PERF_DEVICE_MEMORY', json.dumps(dict(
        rank=int(os.environ.get('SLURM_PROCID', '0')),
        device=str(device), stats=device.memory_stats()), sort_keys=True), flush=True)
