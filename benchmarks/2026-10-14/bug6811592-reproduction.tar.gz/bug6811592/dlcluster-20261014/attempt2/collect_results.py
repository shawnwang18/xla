"""Summarize validated cases; failed or incomplete trials never become speedups."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parent
matrix = json.loads((ROOT / 'matrix.json').read_text())
jobs = [c['job_id'] for c in matrix['cases'] if c.get('job_id')]
accounting = subprocess.check_output(['sacct', '-n', '-P', '-j', ','.join(jobs),
                                    '--format=JobID,State,ExitCode,Elapsed,NodeList'], text=True) if jobs else ''
(ROOT / 'scheduler.txt').write_text(accounting)
records = {v[0]:v[1:] for line in accounting.splitlines() if (v:=line.split('|')) and len(v)>=3}
results = []
for case in matrix['cases']:
    work = ROOT / case['name']
    row = dict(case=case, valid=False)
    if (work / 'case-status.json').exists():
        row['supervisor'] = json.loads((work / 'case-status.json').read_text())
    if not (work / 'results.json').exists() or not (work / 'runtime-memory.json').exists():
        results.append(row)
        continue
    training = json.loads((work / 'results.json').read_text())
    memory = json.loads((work / 'runtime-memory.json').read_text())
    steps = [r.get('step_id') for r in training['runs']]
    scheduler_ok = case.get('job_id') in records and ((case.get('parent_is_reservation') and records[case['job_id']][0]=='RUNNING' and row.get('supervisor',{}).get('state')=='COMPLETED') or records[case['job_id']][:2]==['COMPLETED','0:0']) and all(
        step in records and records[step][:2]==['COMPLETED','0:0'] for step in steps)
    row.update(valid=training['complete'] and memory['complete'] and scheduler_ok,
               scheduler_ok=scheduler_ok, training_complete=training['complete'],
               runtime_memory_complete=memory['complete'], hlo_verified=training['all_hlos_verified'],
               paired_comparisons=training['paired_comparisons'])
    if row['valid']:
        modes = {}
        for mode in ['OFF','ON']:
            runs = [r for r in training['runs'] if r['variant']==mode]
            runtime = [r for r in memory['runs'] if r['status']['variant']==mode]
            timing = next(s for s in training['summary'] if s['variant']==mode)['windows']['primary']
            modes[mode] = dict(timing=timing,
                compiled_initial_max_rank_gib=max(r['memory']['initial']['max_gib'] for r in runs),
                compiled_post_pgle_max_rank_gib=max(r['memory']['post_pgle']['max_gib'] for r in runs),
                allocator_peak_max_gib=max(r['allocator_peak_max_gib'] for r in runtime),
                sampled_physical_peak_max_gib=max(r['physical_peak_max_gib'] for r in runtime),
                process_wall_max_seconds=max(rank['process_wall_seconds'] for r in runtime for rank in r['ranks']),
                ranks=len(runs[0]['ranks']), runs=2,
                logged_losses_finite=all(rank['finite_losses'] for r in runs for rank in r['ranks']))
        row.update(modes=modes, latency_change_percent=100*(modes['ON']['timing']['mean_s']/modes['OFF']['timing']['mean_s']-1))
    results.append(row)
output = dict(request=json.loads((ROOT/'request.json').read_text()), cases=results,
              complete=len(results)==len(matrix['cases']) and all(c['valid'] for c in results),
              memory_definitions='Compiled allocations are rounded per-rank log values. Memory columns are maxima across all GPUs and both repetitions. Allocator and sampled physical peaks cover the process lifetime including compilation. Physical sampling is every 1s and can miss short spikes. Process wall time includes compilation, profiling and all165steps; step latency uses unprofiled steps110-159.')
(ROOT/'summary.json').write_text(json.dumps(output,indent=2)+'\n')
headers=['Case','Mode','Mean step (s)','Initial XLA (GiB)','Post-PGLE XLA (GiB)','Allocator peak (GiB)','Sampled GPU peak (GiB)']
rows=[]
for case in results:
    if not case['valid']:
        continue
    for mode in ['OFF','ON']:
        m=case['modes'][mode]
        rows.append([case['case']['name'],mode,f"{m['timing']['mean_s']:.6f}",
                     *(f'{m[k]:.3f}' for k in ['compiled_initial_max_rank_gib','compiled_post_pgle_max_rank_gib','allocator_peak_max_gib','sampled_physical_peak_max_gib'])])
widths=[max(len(headers[i]),*(len(row[i]) for row in rows)) if rows else len(headers[i]) for i in range(len(headers))]
def line(row):return '| '+' | '.join(cell.ljust(width) for cell,width in zip(row,widths))+' |'
table='\n'.join([line(headers),line(['-'*w for w in widths]),*(line(row) for row in rows)])
(ROOT/'comparison.txt').write_text(table+'\n\n'+output['memory_definitions']+'\n')
print(table)
print('All cases complete:',output['complete'])
