from pathlib import Path
import datetime, fcntl, json, os, socket, subprocess
ROOT = Path(__file__).resolve().parent
ORIGINAL = ROOT.parent / 'deepseek4-cb-modes-20261013'
RESERVE = Path('/home/shawnw/.local/state/job-monitoring/dlcluster-gb200nvl72-reserve-20261015')
ALLOCATION = '2550798'
NODE = 'gb-nvl-081-compute06'
THREAD = '01a13e82-497d-77f0-8c38-a1b05360a512'
RESULT = ROOT / 'result'
RESULT.mkdir(exist_ok=True)
(RESULT / 'logs').mkdir(exist_ok=True)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(path, data):
    tmp=path.with_suffix('.tmp'); tmp.write_text(json.dumps(data,indent=2)+'\n'); tmp.replace(path)
lock=(RESERVE / f'node-use-{NODE}.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
claim_path=RESERVE / f'node-use-{NODE}.json'
claim=dict(allocation_id=ALLOCATION,node=NODE,owner='shawnw',thread_id=THREAD,task='Issue7 DeepSeek OFF retry and matched GC-controlled modes',controller_pid=os.getpid(),controller_host=socket.gethostname(),started_at=now(),reuse_state='IN_USE',coordination='PR50795 controller explicitly permits compute06; it uses compute05 only',keep_allocation_open=True)
save(claim_path,claim)
rc=1
try:
    job=json.loads(subprocess.check_output(['scontrol','show','job',ALLOCATION,'--json'],text=True))['jobs'][0]
    assert 'RUNNING' in str(job.get('job_state')), job.get('job_state')
    steps=subprocess.check_output(['squeue','--steps','-j',ALLOCATION,'-h','-o','%i|%N'],text=True)
    for row in steps.splitlines():
        step,nodes=row.split('|',1)
        if step.endswith(('.batch','.extern')): continue
        hosts=subprocess.check_output(['scontrol','show','hostnames',nodes],text=True).split()
        assert NODE not in hosts, ('Node already in use',step,nodes)
    env=os.environ.copy()
    env['ENROOT_CONFIG_PATH']=str(ORIGINAL/'.enroot')
    mounts=[f'{RESULT}:/opt/workspace',f'{ROOT}/test.sh:/tmp/test.sh:ro',
            f'{ORIGINAL}/skill/assets/jax-run-scripts/bindpcie:/tmp/bindpcie:ro']
    for name in ['step_start.py','mode_sweep.sh','retry_observer.py','collect_stable.py','check_off.py']:
        mounts.append(f'{ROOT}/{name}:/tmp/{name}:ro')
    mounts.append(env['CUSTOM_MOUNTS'])
    command=['srun','--jobid='+ALLOCATION,'--nodes=1','--nodelist='+NODE,'--ntasks=4','--ntasks-per-node=4',
             '--cpus-per-task=16','--cpu-bind=none','--gres=gpu:GB200:4','--exact','--exclusive',
             '--kill-on-bad-exit=1','--job-name=deepseek4-off-gc-controls',
             '--container-image='+('oauth2@'+env['CONTAINER']).replace('gitlab-master.nvidia.com:5005/','gitlab-master.nvidia.com:5005#'),
             '--container-mounts='+','.join(mounts),'--container-remap-root','--container-writable',
             '--container-workdir=/opt/maxtext','--export=ALL',
             '--output='+str(RESULT/'logs/output-%j-%n-%t.txt'),
             '--error='+str(RESULT/'logs/output-%j-%n-%t.txt'),
             'bash','-e','-c','python3 /tmp/step_start.py; if [ "$SLURM_PROCID" = 0 ]; then uname -a; nvidia-smi; nvidia-smi topo -m; fi; bash /tmp/mode_sweep.sh']
    save(RESULT/'launch.json',dict(allocation_id=ALLOCATION,node=NODE,started_at=now(),command=command,controller_pid=os.getpid(),controller_host=socket.gethostname()))
    save(RESULT/'run_status.json',dict(state='RUNNING',started_at=now(),allocation_id=ALLOCATION,node=NODE))
    with (RESULT/'supervisor.log').open('a') as log:
        rc=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
    save(RESULT/'run_status.json',dict(state='COMPLETED' if rc==0 else 'FAILED',returncode=rc,finished_at=now(),allocation_id=ALLOCATION,node=NODE))
except Exception as exc:
    save(RESULT/'run_status.json',dict(state='FAILED',returncode=1,error=str(exc),finished_at=now(),allocation_id=ALLOCATION,node=NODE))
    raise
finally:
    claim.update(reuse_state='IDLE_RESERVED',finished_at=now(),returncode=rc)
    save(claim_path,claim)
raise SystemExit(rc)
