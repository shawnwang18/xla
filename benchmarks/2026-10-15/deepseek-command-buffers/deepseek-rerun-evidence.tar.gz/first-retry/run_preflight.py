"""Inspect the selected image and enable its full non-control-flow command list."""
from pathlib import Path
import importlib.metadata
import json
import os
import re
import subprocess
import sys

source = Path("/opt/xla/xla/xla.proto").read_text()
body = re.search(r"enum CommandBufferCmdType\s*\{(.*?)\n\s*\}", source, re.S).group(1)
commands = [name for name, number in re.findall(r"^\s*(\w+)\s*=\s*(\d+)\s*;", body, re.M)
            if int(number) != 0 and name not in {"WHILE", "CONDITIONAL"}]
assert commands and "FUSION" in commands and "COLLECTIVES" in commands
mode = os.environ['CB_MODE']
assert mode in {'OFF', 'ALWAYS_UPDATE', 'SKIP_TEMP', 'SKIP_PROFILED'}
mode_body = re.search(r"enum CommandBufferUpdateMode\s*\{(.*?)\n\s*\}", source, re.S).group(1)
supported_modes = re.findall(r"^\s*(\w+)\s*=\s*\d+\s*;", mode_body, re.M)
assert {'ALWAYS_UPDATE', 'SKIP_TEMP', 'SKIP_PROFILED'} <= set(supported_modes), supported_modes
selected_commands = [] if mode == 'OFF' else commands
flags, count = re.subn(r"--xla_gpu_enable_command_buffer=\S*",
                      "--xla_gpu_enable_command_buffer=" + ",".join(selected_commands),
                      os.environ["BASE_XLA_FLAGS"])
assert count == 1, "Expected exactly one command-buffer flag"
flags = re.sub(r"--xla_gpu_command_buffer_update_mode=\S+", "", flags)
flags += ' --xla_gpu_command_buffer_update_mode=' + ('ALWAYS_UPDATE' if mode == 'OFF' else mode)
model = Path("/opt/maxtext/src/maxtext/configs/models/deepseek4-284b.yml")
cache = Path("/opt/maxtext/src/maxtext/layers/attention_compressed.py")
assert model.is_file(), "Image lacks DeepSeek-V4 model configuration"
assert cache.is_file(), "Image lacks compressed attention implementation"
cache_text = cache.read_text()
assert "cache" in cache_text.lower() and "autoregressive" in cache_text.lower(), "Inspect compressed attention decode support"

if os.environ.get("SLURM_PROCID", "0") == "0":
    revisions = {}
    for repo in ("xla", "maxtext", "jax"):
        proc = subprocess.run(["git", "-C", f"/opt/{repo}", "rev-parse", "HEAD"],
                              text=True, capture_output=True)
        revisions[repo] = proc.stdout.strip() if proc.returncode == 0 else None
    versions = {}
    for package in ("jax", "jaxlib", "typeguard"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    info = {"mode": mode, "supported_update_modes": supported_modes, "command_buffer_commands": selected_commands, "excluded_commands": ["WHILE", "CONDITIONAL"],
            "base_xla_flags": flags, "revisions": revisions, "versions": versions,
            "model_config": model.read_text(), "compressed_attention_source": str(cache)}
    (Path(os.environ["CB_OUTPUT_DIR"]) / "container_provenance.json").write_text(json.dumps(info, indent=2) + "\n")
    print("IMAGE_PREFLIGHT " + json.dumps(info), file=sys.stderr)
if os.environ.get("SLURM_PROCID", "0") == "0":
    destination = Path(os.environ['CB_OUTPUT_DIR']) / 'xla-source'
    destination.mkdir(exist_ok=True)
    for name in ['xla.proto', 'service/gpu/gpu_executable_va_remap_allocator.cc', 'pjrt/gpu/se_gpu_pjrt_client.cc']:
        path = Path('/opt/xla/xla') / name
        if path.is_file():
            (destination / path.name).write_bytes(path.read_bytes())
print(flags)
