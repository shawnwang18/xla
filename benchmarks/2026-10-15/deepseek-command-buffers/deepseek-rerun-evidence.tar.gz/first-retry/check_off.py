from pathlib import Path
import json
from collect_stable import collect
root = Path('/opt/workspace')
collect(root)
data = json.loads((root / 'stable-comparison.json').read_text())
off = next(row for row in data['modes'] if row['mode'] == 'OFF')
passed = off['status'] == 'stable'
for rank in range(4):
    report = json.loads((root / 'modes/OFF' / f'stable-rank{rank}.json').read_text())
    for phase in ['prefill', 'decode']:
        control = report['gc_control'][phase]
        passed &= control['enabled_during_phase'] is False
        passed &= control['stats_at_phase_start'] == control['stats_at_phase_end']
result = {'passed': bool(passed), 'OFF': off, 'condition': 'All rank/global CV <=10%, drift <=5%, 200/200 samples, no cyclic collection during either phase'}
tmp = root / 'off-quality-gate.tmp'
tmp.write_text(json.dumps(result, indent=2)+'\n')
tmp.replace(root / 'off-quality-gate.json')
print('OFF_QUALITY_GATE', passed, flush=True)
