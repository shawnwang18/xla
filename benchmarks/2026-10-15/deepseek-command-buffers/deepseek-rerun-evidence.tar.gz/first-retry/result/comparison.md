| Mode          | Prefill status | Prefill (ms) | Decode status | Decode (ms) | Decode (tokens/s) | Decode vs OFF | Decode vs ALWAYS_UPDATE |
| ------------- | -------------- | ------------ | ------------- | ----------- | ----------------- | ------------- | ----------------------- |
| OFF           | stable         | 834.413      | unstable      | —           | —                 | —             | —                       |
| ALWAYS_UPDATE | unavailable    | —            | unavailable   | —           | —                 | —             | —                       |
| SKIP_TEMP     | unavailable    | —            | unavailable   | —           | —                 | —             | —                       |
| SKIP_PROFILED | unavailable    | —            | unavailable   | —           | —                 | —             | —                       |
