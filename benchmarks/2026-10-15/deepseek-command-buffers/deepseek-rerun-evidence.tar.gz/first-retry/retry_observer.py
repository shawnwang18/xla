"""Record GC events while the runner controls GC outside fixed timing windows."""
import gc
import json
import os
from pathlib import Path
import resource
import runpy
import sys
import time

events = []
pending = {}


def observe(phase, info):
    timestamp = time.perf_counter_ns()
    generation = info['generation']
    if phase == 'start':
        frame = sys._getframe(1)
        stage, step = None, None
        try:
            while frame is not None:
                if frame.f_code.co_name in {'measure', 'measure_phase'} and frame.f_code.co_filename.endswith('/stable_inference.py'):
                    stage = frame.f_locals.get('stage')
                    step = frame.f_locals.get('step')
                    break
                frame = frame.f_back
        finally:
            del frame
        pending[generation] = dict(start_ns=timestamp, generation=generation, stage=stage, step=step)
    elif generation in pending:
        record = pending.pop(generation)
        record.update(end_ns=timestamp, duration_ms=(timestamp-record['start_ns'])/1e6,
                      collected=info['collected'], uncollectable=info['uncollectable'])
        events.append(record)


before = dict(enabled=gc.isenabled(), thresholds=gc.get_threshold(), stats=gc.get_stats())
gc.callbacks.append(observe)
try:
    sys.argv[0] = '/tmp/stable_inference.py'
    runpy.run_path(sys.argv[0], run_name='__main__')
finally:
    gc.callbacks.remove(observe)
    usage = resource.getrusage(resource.RUSAGE_SELF)
    result = dict(policy_unchanged=False, policy='collect_then_disable_cyclic_gc_for_phase', before=before,
                  after=dict(enabled=gc.isenabled(), thresholds=gc.get_threshold(), stats=gc.get_stats()),
                  events=events, max_rss_kib=usage.ru_maxrss,
                  voluntary_context_switches=usage.ru_nvcsw,
                  involuntary_context_switches=usage.ru_nivcsw)
    out = Path(os.environ['CB_OUTPUT_DIR']) / ('gc-rank'+os.environ['SLURM_PROCID']+'.json')
    out.write_text(json.dumps(result, indent=2)+'\n')
