# GB200 JAX inference: command-buffer performance and reproduction environments

This report compares command buffers OFF, ALWAYS_UPDATE, SKIP_TEMP and SKIP_PROFILED for six full-size BF16 inference workloads on four GB200 GPUs. Gemma 2 2B and Llama 3 8B gained decode throughput; Qwen 3 8B was fastest with OFF. DeepSeek has stable enabled-mode results but no valid OFF decode baseline. Both 27B configurations failed before timing.

These are random-weight microbenchmarks. They do not establish checkpoint accuracy. The measurements were collected on 2026-10-13–14.

## Speedup summary

**The largest observed decode gain versus OFF is 1.075× (+7.47% throughput) for Llama 3 8B with SKIP_TEMP.** Gemma 2 2B gains **1.052× (+5.18%)** with ALWAYS_UPDATE. Qwen 3 8B is fastest with OFF: even its fastest enabled mode delivers **0.914× (−8.59%)**.

The table selects the fastest measured **enabled** mode for each model; it does not imply that enabling command buffers always improves performance. All speedups and percentage changes in this table use **OFF as the baseline**.

| Model                  | Global batch | Fastest enabled mode |     OFF (tokens/s) | Enabled (tokens/s) | Speedup vs OFF | Throughput change |
| ---------------------- | -----------: | -------------------- | -----------------: | -----------------: | -------------: | ----------------: |
| DeepSeek V4 Flash 284B |            4 | SKIP_PROFILED        | Unstable; excluded |             33.763 |            N/A |               N/A |
| Gemma 2 2B             |          256 | ALWAYS_UPDATE        |         22,233.331 |         23,383.982 |         1.052× |            +5.18% |
| Llama 3 8B             |          256 | SKIP_TEMP            |         20,726.505 |         22,273.831 |         1.075× |            +7.47% |
| Qwen 3 8B              |            4 | SKIP_PROFILED        |            374.889 |            342.668 |         0.914× |            -8.59% |

- **DeepSeek:** no valid OFF decode speedup can be reported because both OFF runs were unstable. Comparing enabled modes only, SKIP_PROFILED delivers **1.129× (+12.90%)** the decode throughput of ALWAYS_UPDATE (29.904 → 33.763 tokens/s). This uses **ALWAYS_UPDATE**, not OFF, as its baseline.
- **Prefill:** OFF is fastest for all four measured models; every enabled-mode prefill speedup is below 1×.
- **Gemma 2 27B / Gemma 3 27B:** initialization ran out of GPU memory; no timings or speedups are available.

## How to read the speedup numbers

- **Speedup = OFF mean latency / mode mean latency.** For decode, this also equals mode throughput / OFF throughput.
- **Performance change (%) = 100 × (speedup − 1).** Positive values mean faster; negative values mean slower. This is a throughput/performance change, not a percentage latency reduction.
- **OFF = 1.000× (0.00%).** For example, 1.075× means approximately 7.5% higher throughput; 0.914× means approximately 8.6% lower throughput.
- Ratios and percentages are calculated from unrounded measurements, then rounded independently to three decimals and two decimals, respectively.
- **N/A** means no stable OFF baseline exists for that phase. Failed or unstable timings are excluded from performance and speedup claims.

## Decode results: latency, throughput and speedup

| Model                  | Mode          | Decode latency (ms) | Throughput (tokens/s) | Speedup vs OFF | Throughput change |
| ---------------------- | ------------- | ------------------: | --------------------: | -------------: | ----------------: |
| DeepSeek V4 Flash 284B | OFF           |  Unstable; excluded |    Unstable; excluded |            N/A |               N/A |
| DeepSeek V4 Flash 284B | ALWAYS_UPDATE |             133.762 |                29.904 |            N/A |               N/A |
| DeepSeek V4 Flash 284B | SKIP_TEMP     |             141.535 |                28.262 |            N/A |               N/A |
| DeepSeek V4 Flash 284B | SKIP_PROFILED |             118.474 |                33.763 |            N/A |               N/A |
| Gemma 2 2B             | OFF           |              11.514 |            22,233.331 |         1.000× |             0.00% |
| Gemma 2 2B             | ALWAYS_UPDATE |              10.948 |            23,383.982 |         1.052× |            +5.18% |
| Gemma 2 2B             | SKIP_TEMP     |              11.089 |            23,086.504 |         1.038× |            +3.84% |
| Gemma 2 2B             | SKIP_PROFILED |              11.322 |            22,609.934 |         1.017× |            +1.69% |
| Llama 3 8B             | OFF           |              12.351 |            20,726.505 |         1.000× |             0.00% |
| Llama 3 8B             | ALWAYS_UPDATE |              12.388 |            20,665.811 |         0.997× |            -0.29% |
| Llama 3 8B             | SKIP_TEMP     |              11.493 |            22,273.831 |         1.075× |            +7.47% |
| Llama 3 8B             | SKIP_PROFILED |              11.877 |            21,554.539 |         1.040× |            +4.00% |
| Qwen 3 8B              | OFF           |              10.670 |               374.889 |         1.000× |             0.00% |
| Qwen 3 8B              | ALWAYS_UPDATE |              16.343 |               244.749 |         0.653× |           -34.71% |
| Qwen 3 8B              | SKIP_TEMP     |              13.495 |               296.400 |         0.791× |           -20.94% |
| Qwen 3 8B              | SKIP_PROFILED |              11.673 |               342.668 |         0.914× |            -8.59% |

Qwen's enabled modes reduce decode throughput by **34.71% / 20.94% / 8.59%** for ALWAYS_UPDATE / SKIP_TEMP / SKIP_PROFILED, respectively. Investigation: [issue #6](https://github.com/shawnwang18/xla/issues/6).

## Prefill results: latency and speedup

| Model                  | Mode          | Prefill latency (ms) | Speedup vs OFF | Performance change |
| ---------------------- | ------------- | -------------------: | -------------: | -----------------: |
| DeepSeek V4 Flash 284B | OFF           |             1110.972 |         1.000× |              0.00% |
| DeepSeek V4 Flash 284B | ALWAYS_UPDATE |             1186.917 |         0.936× |             -6.40% |
| DeepSeek V4 Flash 284B | SKIP_TEMP     |             1147.946 |         0.968× |             -3.22% |
| DeepSeek V4 Flash 284B | SKIP_PROFILED |             1187.004 |         0.936× |             -6.41% |
| Gemma 2 2B             | OFF           |               13.900 |         1.000× |              0.00% |
| Gemma 2 2B             | ALWAYS_UPDATE |               15.734 |         0.883× |            -11.65% |
| Gemma 2 2B             | SKIP_TEMP     |               16.431 |         0.846× |            -15.40% |
| Gemma 2 2B             | SKIP_PROFILED |               17.076 |         0.814× |            -18.60% |
| Llama 3 8B             | OFF           |               16.386 |         1.000× |              0.00% |
| Llama 3 8B             | ALWAYS_UPDATE |               18.207 |         0.900× |            -10.00% |
| Llama 3 8B             | SKIP_TEMP     |               19.529 |         0.839× |            -16.10% |
| Llama 3 8B             | SKIP_PROFILED |               20.012 |         0.819× |            -18.12% |
| Qwen 3 8B              | OFF           |               18.618 |         1.000× |              0.00% |
| Qwen 3 8B              | ALWAYS_UPDATE |               27.341 |         0.681× |            -31.91% |
| Qwen 3 8B              | SKIP_TEMP     |               32.923 |         0.566× |            -43.45% |
| Qwen 3 8B              | SKIP_PROFILED |               31.058 |         0.599× |            -40.05% |

Exact accepted values and OFF-relative ratios are also saved in [command-buffer-results.csv](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/command-buffer-results.csv). The CSV leaves rejected measurements and unavailable ratios empty; the reproduction archive preserves their raw evidence.

## Measurement protocol

Each model used one aarch64 node and four GB200 GPUs. Modes ran sequentially on the same GPU set in the order OFF → ALWAYS_UPDATE → SKIP_TEMP → SKIP_PROFILED. Independent models could run on separate nodes. DeepSeek's later OFF retry used its original node.

Every phase used 100 warmup steps and **all 200 measured steps 101–300**. Each call was synchronized; a global step is the maximum latency across the four ranks. Reported latency is the mean of these 200 global steps. Every rank and the global series must pass CV ≤10% and half-window mean drift ≤5%. No stalls were dropped or faster windows selected. Stability is checked separately for prefill and decode.

Decode throughput is global batch × 1000 / mean decode latency in milliseconds. These are single fixed-order sweeps, not randomized repeated trials with confidence intervals. Compare modes within a workload; batches and node topology differ between workloads.

## Failed configurations and DeepSeek OFF retry

Gemma 2 27B (global batch 600, step 2521171.0) and Gemma 3 27B (global batch 480, step 2521172.0) ran out of GPU memory during OFF state initialization, before any timing. Their supervisors returned 143 after termination; the remaining modes did not start. No performance or speedup is reported for those configurations.

DeepSeek step 2497742.6 completed, and OFF retry job 2507484 also completed on gb-nvl-053-compute09. The original OFF decode window failed stability (CV 59.628%, half-window drift 14.309%); the retry also failed (CV 65.638%, drift 19.454%). Retry stalls at steps 138, 174, 186 and 187 coincided with generation-2 Python GC events lasting 588.817–647.491 ms. This is correlation, not a controlled causal test. Both complete windows and GC observations remain archived. The tables use stable retry OFF prefill and the original enabled-mode measurements; OFF decode is excluded.

## Reproduction environments

[Per-workload environment index](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environment-summary.md) · [All six environment records](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments.json) · [Reproduction archive](https://raw.githubusercontent.com/shawnwang18/xla/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/command-buffers-reproduction.tar.gz) · [SHA-256 checksums](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/SHA256SUMS)

The archive preserves the six configurations, original and retry samples, available runtime commands, hardware observations, source revisions, frozen runners and collectors, scheduler/status records and GC evidence. The individual JSON records save exact model settings, flags, mode-specific provenance and evidence paths.

| Workload / environment record                                                    | Node (4 × GB200)     | Global batch | Allocation/job or step   | Outcome                            |
| -------------------------------------------------------------------------------- | -------------------- | ------------ | ------------------------ | ---------------------------------- |
| [DeepSeek V4 Flash 284B](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments/command-buffers/deepseek4-flash-284b.json) | gb-nvl-053-compute09 | 4            | 2497742.6; retry 2507484 | Completed; OFF decode unstable     |
| [Gemma 2 2B](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments/command-buffers/gemma2-2b.json)                        | gb-nvl-053-compute09 | 256          | 2507927                  | Stable, all four modes             |
| [Llama 3 8B](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments/command-buffers/llama3-8b.json)                        | gb200-nvl4-ts2-79    | 256          | 2521076                  | Stable, all four modes             |
| [Qwen 3 8B](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments/command-buffers/qwen3-8b.json)                          | gb200-nvl4-ts2-88    | 4            | 2521170                  | Stable, all four modes             |
| [Gemma 2 27B](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments/command-buffers/gemma2-27b.json)                      | gb200-nvl4-ts2-82    | 600          | 2521171                  | OFF initialization OOM; no timings |
| [Gemma 3 27B](https://github.com/shawnwang18/xla/blob/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14/environments/command-buffers/gemma3-27b.json)                      | gb200-nvl4-ts2-81    | 480          | 2521172                  | OFF initialization OOM; no timings |

All models use BF16 weights/compute, random weights and the skill-owned consistent-AOT runner (`inference_aot_mode=consistent`), with typeguard 2.13.3. No MaxText or JAX source edits were applied. True prompt lengths are 4 tokens for DeepSeek/Gemma/Llama and 3 for Qwen; padded prefill lengths are 4096 for DeepSeek and 1024 for the other models. Maximum sequence lengths are 8192 and 2048, respectively. Exact meshes and model arguments are retained in each environment record.

OFF disables command buffers. Enabled modes include every image-supported command type except WHILE and CONDITIONAL:

```text
FUSION,CUBLAS,CUDNN,COLLECTIVES,CUSTOM_CALL,CUBLASLT,DYNAMIC_SLICE_FUSION,CONVOLUTION,HOST_EXECUTE,COLLECTIVES_KERNEL
```

Command-buffer scheduling is LHS and command-buffer loop unrolling is false. OFF/ALWAYS_UPDATE use BFC; SKIP_TEMP/SKIP_PROFILED select VMM, so the measured comparison includes allocator differences. Preserve the exact archived flags when reproducing.

| Software component          | Recorded value                                                |
| --------------------------- | ------------------------------------------------------------- |
| Container                   | `gitlab-master.nvidia.com:5005/dl/dgx/jax:maxtext-2026-10-12` |
| XLA revision                | `5cba10fbbb68e6d549d7670aa2d4d7b487494c86`                    |
| MaxText revision            | `b51e17d5dde9590909537673864cde99481f6f2e`                    |
| JAX revision                | `290228f95c2435d1cc110469e785b83e9859760a`                    |
| JAX / jaxlib versions       | `0.12.0.dev20261012+290228f95c` / `0.12.0.dev20261013`        |
| Runtime dependency override | `typeguard==2.13.3`                                           |

The dated image tag has no captured immutable digest. Registry access is required; verify saved source revisions and available library hashes before accepting a reproduction. GPU identities, driver and topology observations are saved per mode where captured. The Qwen node records driver 595.84.01 and NV6 links between every GPU pair; consult the other workloads' own hardware records.

## Reproduce later

1. Download the command-buffer reproduction archive and check its SHA-256 against `SHA256SUMS`; verify its internal `MANIFEST.json` entries.
2. Select `environments/<workload>.json` in the archive. Restore its container, dependency override, model size, precision, batch, sequence lengths and mesh.
3. Stage the archived runner/configuration on shared storage. Adapt historical paths, Slurm IDs and node constraints to compatible resources while preserving the recorded mount targets and flags. Use the saved consistent-AOT runner.
4. Access dlcluster compute nodes through the dlcluster head node and launch through Slurm. Run the four modes sequentially on the same GPU set, preserving allocator choices, mode order, warmups and the full measurement window.
5. Use the archived `deepseek/collect_stable.py` or `suite/collect_stable.py` to evaluate every required sample. For DeepSeek, `deepseek/off-retry-01/comparison-updated/stable-comparison.json` identifies the retry-OFF/original-enabled combination reported here. Report failures and instability explicitly.

The archive saves configurations, measurements and runner code. Container images, large binary wheels, CUDA libraries, full HLO dumps, Nsight captures and checkpoints are not bundled; available hashes and original paths identify those dependencies. Historical launch commands require resource/path adaptation and have not been newly validated as portable launchers. This report update did not rerun benchmarks.

Artifact snapshot: [9efe517b25ee](https://github.com/shawnwang18/xla/tree/9efe517b25ee943b404b9273942800134a6a046c/benchmarks/2026-10-14). All issue artifact links are pinned to this commit.

<!-- benchmark-results-20261014-reproduction-v1 -->
