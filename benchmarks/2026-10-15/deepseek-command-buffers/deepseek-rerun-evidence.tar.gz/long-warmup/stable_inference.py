"""Fixed-window synchronized inference measurements; no framework patches."""
import gc
import resource
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time

sys.path.insert(0, '/tmp/jax-workloads')
from inference_aot_runner import compile_engine, require_same_formats

WARMUP = {'prefill': 100, 'decode': 1000}
MEASURE = 200


def summarize(samples):
    values = [s['milliseconds'] for s in samples if not s['warmup']]
    mean = statistics.mean(values)
    half = len(values) // 2
    drift = abs(statistics.mean(values[:half]) - statistics.mean(values[half:])) / mean * 100
    cv = statistics.pstdev(values) / mean * 100
    return dict(mean_ms=mean, median_ms=statistics.median(values),
                p95_ms=sorted(values)[int(.95 * (len(values)-1))],
                cv_percent=cv, half_mean_drift_percent=drift,
                stable=drift <= 5 and cv <= 10,
                measured_steps=[next(s['step'] for s in samples if not s['warmup']), samples[-1]['step']])


def run(config):
    import jax
    import numpy as np
    from maxtext.inference.maxengine import maxengine
    from maxtext.input_pipeline.packing import prefill_packing
    from maxtext.utils import max_utils

    rank = jax.process_index()
    out = Path(os.environ['CB_OUTPUT_DIR'])
    report_path = out / f'stable-rank{rank}.json'
    samples_path = out / f'samples-rank{rank}.jsonl'
    report = dict(mode=os.environ['CB_MODE'], rank=rank, warmup_steps=WARMUP,
                  measurement_steps=MEASURE, timing='perf_counter_ns; each call block_until_ready',
                  xla_flags=os.environ.get('XLA_FLAGS'), framework_source_patches=[],
                  stable_runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  stages={}, status='initializing', cpu_affinity=sorted(os.sched_getaffinity(0)))
    def save():
        report_path.write_text(json.dumps(report, indent=2)+'\n')
    save()

    engine = maxengine.MaxEngine(config)
    processor = prefill_packing.PrefillProcessor(engine)
    rng = jax.random.PRNGKey(1234)
    rng, rng_params = jax.random.split(rng)
    params = engine.load_params(rng_params)
    tokenizer = engine.build_tokenizer(engine.get_tokenizer())
    rng, rng_init = jax.random.split(rng)
    rng_shape = jax.ShapeDtypeStruct([4], jax.numpy.dtype('uint32'))
    generate, params, initialize = compile_engine(engine, params, rng_shape)
    state = initialize(rng_init)
    jax.block_until_ready(state)
    num_params, model_size, _ = max_utils.summarize_pytree_data(params, name='Model')
    _, cache_size, _ = max_utils.summarize_pytree_data(state['cache'], name='Cache')
    report.update(model_params=num_params, model_bytes=model_size, cache_bytes=cache_size,
                  global_batch=engine.max_concurrent_decodes,
                  decoder_layers=config.num_decoder_layers, experts=config.num_experts,
                  status='compiling_prefill')
    save()
    lengths = [int(v) for v in config.inference_microbenchmark_prefill_lengths.split(',')]
    assert lengths == [4096], lengths
    length = lengths[0]
    tokens, true_length = tokenizer.encode(config.prompt, is_bos=tokenizer.bos_id is not None,
                                          prefill_lengths=[length])
    prefill = jax.jit(engine.prefill_aot,
                     in_shardings=(engine.param_layouts, None, None, None)).lower(
                         params, jax.ShapeDtypeStruct([length], jax.numpy.int32),
                         jax.ShapeDtypeStruct((), int), rng_shape).compile()
    insert = processor.aot_compile(params, length)
    require_same_formats(insert.output_formats[1], engine.decode_state_layouts, 'insert output')
    require_same_formats(insert.input_formats[0][4], engine.decode_state_layouts, 'insert input')
    report.update(padded_prefill_tokens=length, true_prompt_tokens=int(true_length),
                  decode_input_output_formats_equal=True, status='measuring')
    save()

    def next_rng():
        nonlocal rng
        rng, key = jax.random.split(rng)
        # RNG dispatch/compilation are outside the timed model call.
        jax.block_until_ready((rng, key))
        return key

    def measure_phase(stage, invoke):
        warmup = WARMUP[stage]
        samples = []
        with samples_path.open('a', buffering=1) as log:
            for step in range(1, warmup + MEASURE + 1):
                key = next_rng()
                start = time.perf_counter_ns()
                output = invoke(key)
                jax.block_until_ready(output)
                elapsed = (time.perf_counter_ns() - start) / 1e6
                record = dict(stage=stage, step=step, milliseconds=elapsed,
                              warmup=step <= warmup)
                samples.append(record)
                # Retain normal overlapping output lifetime until the next call.
                log.write(json.dumps(record)+'\n')
                if rank == 0 and step in (1, warmup, warmup+MEASURE):
                    print('STABLE_STEP '+json.dumps(record), flush=True)
        report['stages'][stage] = summarize(samples)
        save()
        return output

    def measure(stage, invoke):
        # Collection is moved outside the entire fixed warmup+measurement phase.
        # Reference counting stays enabled; no steps are removed or selected.
        from jax.experimental import multihost_utils
        was_enabled = gc.isenabled()
        before_stats = gc.get_stats()
        collected = gc.collect(2)
        gc.disable()
        metadata = dict(policy='collect_then_disable_cyclic_gc_for_phase',
                        enabled_before=was_enabled, collected_before_phase=collected,
                        stats_before_collection=before_stats,
                        stats_at_phase_start=gc.get_stats(),
                        max_rss_kib_before=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        report.setdefault('gc_control', {})[stage] = metadata
        save()
        try:
            multihost_utils.sync_global_devices('gc_control_start_' + stage)
            result = measure_phase(stage, invoke)
            multihost_utils.sync_global_devices('gc_control_end_' + stage)
            return result
        finally:
            metadata.update(stats_at_phase_end=gc.get_stats(),
                            enabled_during_phase=gc.isenabled(),
                            max_rss_kib_after=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
            if was_enabled:
                gc.enable()
            metadata['enabled_after_restore'] = gc.isenabled()
            save()

    last = measure('prefill', lambda key: prefill(params, tokens, true_length, key))
    del last
    # Populate every slot identically across modes; insertion is outside timing.
    for slot in range(engine.max_concurrent_decodes):
        _, state = insert(params, tokens, slot, true_length, state, next_rng())
        jax.block_until_ready(state)
    require_same_formats(jax.tree.map(lambda x: x.format, state),
                         engine.decode_state_layouts, 'runtime decode input')
    def decode(key):
        nonlocal state
        state, result = generate(params, state, key)
        return state, result
    last = measure('decode', decode)
    local_logits = state['logits'].addressable_shards[0].data
    finite = bool(np.isfinite(np.asarray(jax.device_get(local_logits))).all())
    report['finite_final_local_logits'] = finite
    report['status'] = 'completed' if finite else 'failed_nonfinite_logits'
    report['stages']['decode']['tokens_per_second'] = engine.max_concurrent_decodes * 1000 / report['stages']['decode']['mean_ms']
    save()
    assert finite, 'Non-finite final logits'
    print('STABLE_RESULTS '+json.dumps(report), flush=True)


def main(argv):
    import jax
    from maxtext.configs import pyconfig
    jax.config.update('jax_default_prng_impl', 'unsafe_rbg')
    config = pyconfig.initialize(argv)
    run(config)


if __name__ == '__main__':
    from absl import app
    app.run(main)
