"""Validate the full GC-controlled campaign and render OFF-relative results."""
from pathlib import Path
import argparse, csv, json
from collect_stable import collect

parser=argparse.ArgumentParser()
parser.add_argument('result_dir', type=Path)
args=parser.parse_args()
root=args.result_dir
collect(root)
comparison=json.loads((root/'stable-comparison.json').read_text())
checks=[]
for row in comparison['modes']:
    mode=row['mode']
    directory=root/'modes'/mode
    mode_checks=[]
    for rank in range(4):
        path=directory/f'stable-rank{rank}.json'
        if not path.exists():
            mode_checks.append(f'Missing rank {rank} report')
            continue
        report=json.loads(path.read_text())
        for phase in ['prefill','decode']:
            control=report.get('gc_control',{}).get(phase,{})
            if control.get('policy')!='collect_then_disable_cyclic_gc_for_phase':
                mode_checks.append(f'{rank}/{phase}: missing GC policy')
            if control.get('enabled_during_phase') is not False:
                mode_checks.append(f'{rank}/{phase}: cyclic GC was not disabled')
            if control.get('stats_at_phase_start')!=control.get('stats_at_phase_end'):
                mode_checks.append(f'{rank}/{phase}: GC counters changed during phase')
            if control.get('enabled_before')!=control.get('enabled_after_restore'):
                mode_checks.append(f'{rank}/{phase}: GC policy was not restored')
    checks.append({'mode':mode,'valid_gc_control':not mode_checks,'errors':mode_checks})
checks_by_mode={c['mode']:c for c in checks}
all_valid=all(c['valid_gc_control'] for c in checks) and all(row['status']=='stable' for row in comparison['modes'])
(root/'gc-quality-checks.json').write_text(json.dumps({'all_modes_valid_and_stable':all_valid,'checks':checks},indent=2)+'\n')
headers=['Mode','Phase','Mean (ms)','Throughput (tokens/s)','Speedup vs OFF','Performance change','CV (%)','Drift (%)','Status']
rows=[]
flat=[]
for mode in comparison['modes']:
    for phase in ['prefill','decode']:
        stage=mode['stages'].get(phase,{})
        valid=checks_by_mode[mode['mode']]['valid_gc_control']
        stable=stage.get('stable',False) and valid
        status='stable' if stable else 'unstable' if stage else 'unavailable'
        ratio=stage.get('speedup_vs_OFF') if stable and checks_by_mode['OFF']['valid_gc_control'] else None
        percent=100*(ratio-1) if ratio is not None else None
        def number(key): return f'{stage[key]:.3f}' if key in stage and stable else 'N/A'
        rows.append([mode['mode'],phase,number('mean_ms'),number('tokens_per_second'),f'{ratio:.3f}×' if ratio is not None else 'N/A',f'{percent:+.2f}%' if percent is not None else 'N/A',f"{stage['cv_percent']:.3f}" if stage else 'N/A',f"{stage['half_mean_drift_percent']:.3f}" if stage else 'N/A',status])
        flat.append({'mode':mode['mode'],'phase':phase,'status':status,'mean_ms':stage.get('mean_ms') if stable else None,'tokens_per_second':stage.get('tokens_per_second') if stable else None,'speedup_vs_OFF':ratio,'relative_performance_percent':percent,'cv_percent':stage.get('cv_percent'),'half_mean_drift_percent':stage.get('half_mean_drift_percent')})
widths=[max(len(h),*(len(row[i]) for row in rows)) for i,h in enumerate(headers)]
def line(row): return '| '+' | '.join(cell.ljust(w) for cell,w in zip(row,widths))+' |'
markdown='\n'.join([line(headers),line(['-'*w for w in widths]),*[line(row) for row in rows]])+'\n'
(root/'validated-comparison.md').write_text(markdown)
with (root/'validated-results.csv').open('w') as file:
    writer=csv.DictWriter(file,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
print(markdown)
print('All modes valid and stable:',all_valid)
raise SystemExit(0 if all_valid else 1)
