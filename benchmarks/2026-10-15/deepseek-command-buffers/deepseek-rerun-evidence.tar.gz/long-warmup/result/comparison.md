| Mode          | Prefill status | Prefill (ms) | Decode status | Decode (ms) | Decode (tokens/s) | Decode vs OFF | Decode vs ALWAYS_UPDATE |
| ------------- | -------------- | ------------ | ------------- | ----------- | ----------------- | ------------- | ----------------------- |
| OFF           | stable         | 836.633      | stable        | 95.902      | 41.709            | 1.000×        | —                       |
| ALWAYS_UPDATE | stable         | 974.854      | unstable      | —           | —                 | —             | —                       |
| SKIP_TEMP     | stable         | 927.650      | stable        | 119.762     | 33.400            | 0.801×        | —                       |
| SKIP_PROFILED | stable         | 963.774      | stable        | 99.681      | 40.128            | 0.962×        | —                       |
